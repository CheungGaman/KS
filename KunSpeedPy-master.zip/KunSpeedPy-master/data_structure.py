from z_bytes import *
from process_config import *
from collections import namedtuple
from HPSocket import TcpPush
import HPSocket
from HPSocket import helper
from HPSocket import pyhpsocket
from HPSocket.pyhpsocket import HP_Server_SetConnectionExtra
from HPSocket.HPSocketAPI import HP_Server_Disconnect

class ItemStatus:
    def __init__(self, ItemID:int, NewStatus:int):
        self.ItemID = ItemID
        self.NewStatus = NewStatus
    def __repr__(self):
        return f"{type(self).__name__}(ItemID={self.ItemID}, NewStatus={self.NewStatus})"
ItemInfo = namedtuple("ItemInfo", ["ItemID", "ItemNum", "AvailPeriod", "Status", "ObtainTime", "OtherAttribute", "ItemType"])

class ID_IDENTIFY:
    EMPTY=0
    QQLEVEL1=1
    QQLEVEL2=2
    QQLEVEL3=4
    SPEEDMEMBER=8 
    NETBARIP=16 
    PETMEMBER=32
    NETBARMATCHIP=64
    GOLDNETBARIP=128
    QQGAMEVIP=256
    HIDE_FRIEND_LOGIN_TIPS=512
    JUDGE=1024 
    INSPECTION=4096
    PRIMARY=8192
    SENOIR=16384
    MASTER=32768
    FORBIDDEN=65536
    NOLOGINING=131072
    KING=262144
    INFANTE=524288
    QQFLAG=1048576
    HAVEWORD=2097152
    FINISHQQFLAG=4194304
    INVISIBLEQQNUMFLAG=8388608 
    SHOWACHIEVEMENTFLAG=16777216
    KUBINETBARIP=33554432
    QQCLUB=67108864
    REFUSE_UNKNOWN_GAME_INVITE=134217728
    REFUSE_UNKNOWN_FRIEND_INVITE=268435456
    REFUSE_UNKNOWN_PRIVATE_CHAT=536870912
    HIDE_QQSPEED_BIRTHDAY=1073741824 

class CONST:
    MaxNickName = 17
    MaxQQNickName = 20
    MaxSignature = 64
    MAX_MUCH_SEATNUMINROOM = 20
    MAXNPCNUMINROOM = 20
    MaxRoomName = 22
    MaxRoomPassword = 16
    SIZE_OF_INT = 4
    MAX_SEAT_IN_ROOM = 6
    MAX_MUCH_SEATNUMINROOM = 20
    MAXNPCNUMINROOM = 20
    MAXAWORDSIZE = 64
    VipFlag = 0x207
    ROBOT_ID = 10001
    ROBOT_SEAT = MAX_SEAT_IN_ROOM-1
    MaxItems = 700
    CMD_PREFIX = "cmd "
    MaxChatRoomNum = 1
    MaxPlayerInOutdoor = 99
    MAX_NUM_IN_EACHCHAIR = 2
    MAX_CHAIR_NUM = 200
    MaxFuel = 1000
    

class FE:
    CLIENT=0
    PLAYER=1
    ROOM=2
    GAMELOGIC=3
    GAMESVRD=4
    DBSVRD=5
    LOGSVRD=6
    DIRSVRD=7
    SHOPSVRD=8
    TEAM=9
    CHATSVRD=10
    BORDERSVRD=11
    MATCHSVRD=12
    OUTDOORSVRD=13
    GUILDSVRD=18
    LUCKYMATCHROOM=38
    LOVEMATCHSVRD=59
    WIZARDDB=68
    LADDERMATCHSVRD=71
    WLGAMESVR=70
    PKLOGIC=92
class MsgType:
    Request=0
    Response=1
    Notify=2
    Ack=3
    Internal=4



class CSHEAD:
    size = 18
    def __init__(self, data:Z_BYTES):
        self.data = data
        self.TotalLength = data[0:4].to_int(byteorder="big", signed=False)
        self.Ver = data[4:6].to_int(byteorder="big", signed=True)
        self.DialogID = data[6:8].to_int(byteorder="big", signed=True)
        self.Seq = data[8:12].to_int(byteorder="big", signed=True)
        self.Uin = data[12:16].to_int(byteorder="big", signed=False)
        self.BodyFlag = data[16:17].to_int(byteorder="big", signed=True)
        self.OptLength = data[17:18].to_int(byteorder="big", signed=False)
        self.OptData = data[18:]
    def write_TotalLength(self, TotalLength:int):
        Set32(self.data.data, self.data.start+0, TotalLength)
    def write_Ver(self, Ver:int):
        Set16(self.data.data, self.data.start+4, Ver)
    def write_DialogID(self, DialogID:int):
        Set16(self.data.data, self.data.start+6, DialogID)
    def write_Seq(self, Seq:int):
        Set32(self.data.data, self.data.start+8, Seq)
    def write_Uin(self, Uin:int):
        Set32(self.data.data, self.data.start+12, Uin)
    def write_BodyFlag(self, BodyFlag:int):
        Set8(self.data.data, self.data.start+16, BodyFlag)
    def write_OptLength(self, OptLength:int):
        Set8(self.data.data, self.data.start+17, OptLength)
    def __repr__(self):
        return f"[CSHEAD|TotalLength={self.TotalLength}, Ver={self.Ver}, DialogID={self.DialogID}, BodyFlag={self.BodyFlag}, OptLength={self.OptLength}, Uin={self.Uin}]"
    
class MSGHEAD:
    size = 16
    def __init__(self, data:Z_BYTES):
        if len(data) < MSGHEAD.size:
            raise Exception
        self.data = data
        self.MsgID = data[0:2].to_int(byteorder="big", signed=False)
        self.MsgType = data[2:4].to_int(byteorder="big", signed=True)
        self.MsgSeq = data[4:8].to_int(byteorder="big", signed=True)
        self.SrcFE = data[8:9].to_int(byteorder="big", signed=True)
        self.DstFE = data[9:10].to_int(byteorder="big", signed=True)
        self.SrcID = data[10:12].to_int(byteorder="big", signed=True)
        self.DstID = data[12:14].to_int(byteorder="big", signed=True)
        self.BodyLen = data[14:16].to_int(byteorder="big", signed=False)
    def write_MsgID(self, MsgID:int):
        Set16(self.data.data, self.data.start+0, MsgID)
    def write_MsgType(self, MsgType):
        Set16(self.data.data, self.data.start+2, MsgType)
    def write_MsgSeq(self, MsgSeq):
        Set32(self.data.data, self.data.start+4, MsgSeq)
    def write_SrcFE(self, SrcFE):
        Set8(self.data.data, self.data.start+8, SrcFE)
    def write_DstFE(self, DstFE):
        Set8(self.data.data, self.data.start+9, DstFE)
    def write_SrcID(self, SrcID):
        Set16(self.data.data, self.data.start+10, SrcID)
    def write_DstID(self, DstID):
        Set16(self.data.data, self.data.start+12, DstID)
    def write_BodyLen(self, BodyLen):
        Set16(self.data.data, self.data.start+14, BodyLen)
        
    def __repr__(self):
        return f"[MSGHEAD|MsgID={self.MsgID}, MsgType={self.MsgType}, MsgSeq={self.MsgSeq}, SrcFE={self.SrcFE}, DstFE={self.DstFE}, SrcID={self.SrcID}, DstID={self.DstID}, BodyLen={self.BodyLen}]"

class ClientNode():
    def __init__(self):
        self.Server:TcpPush.HP_TcpPushServer = None
        self.Sender = None
        self.Buffer: Z_BYTES = None
        self.BufferSize = 0
        self.BufferOffset=0
        self.ConnID=0
        self.IsLogin:bool = False
        self.Uin = 0
        self.Key = 0 # ?
        self.ServerID=0
        self.KartID=0
        
        self.Room: 'RoomNode' = None
        self.SeatID = 0
        self.GameID=0
        self.ReadyState = 0
        self.TeamID = 0
        self.MapLoadOver:bool = False
        self.IsLoverProp = 0 # 0 竞速 1 道具

        self.MapID=0
        self.FinishTime=0
        self.TotalRound = 0
        self.Round = 0
        self.PassedCheckPoint = 0
        self.EndCheckPoint = 0
        self.Loop = 0
        self.MapCompatibilityMode = 0
        
        self.Scores = 0
        self.ChatRoom: 'ChatRoomNode' = None
        self.Nick = ""
        
        self.N2OCountRequiredForReborn = 0
        self.RoomName = ""
        self.NumPropsInHand = 0
        
        self.Fuel = 0 # 氮气条 1000为满
        self.CollectedN2O = 0 # 漂移收集的氮气数量 （不考虑宝石等） TODO：如果有大地宝石，会冲突吗？
    def StartGame(self):
        self.FinishTime = 0
        self.Round = 0
        self.PassedCheckPoint = 0
        self.NumPropsInHand = 0
        self.Fuel = 0
        self.CollectedN2O = 0
        self.N2OCountRequiredForReborn = 0
    @property
    def RoomID(self):
        if self.Room: return self.Room.ID
        if self.ChatRoom: return self.ChatRoom.ID
        raise Exception(f"Client {self.Nick} has no room")
    def YieldAllClientsInSameRoom(self):
        if self.Room:
            yield from self.Room.YieldAllClients()
        elif self.ChatRoom:
            yield from self.ChatRoom.YieldAllClients()
        else:
            pass
    def __repr__(self):
        return f"[ClientNode|Nick={self.Nick}, Uin={self.Uin}, ConnID={self.ConnID}]"
    
_RobotClient_ = ClientNode()
_RobotClient_.SeatID = CONST.ROBOT_SEAT
_RobotClient_.Uin = CONST.ROBOT_ID
_Clients_:dict[int, ClientNode] = {
    CONST.ROBOT_ID:_RobotClient_
}
def AddClient(Client:ClientNode):
    _Clients_[Client.Uin] = Client
def GetClient(Uin:int)->ClientNode:
    return _Clients_.get(Uin, None)
def RemoveClient(Client:ClientNode):
    if Client.Uin in _Clients_:
        del _Clients_[Client.Uin]

Rooms:dict[int, 'RoomNode'] = {}
_RoomID_ = 0
def GetRoomID()->int:
    global _RoomID_
    _RoomID_ += 1
    return _RoomID_
class RoomNode:
    def __init__(self):
        self.ID = GetRoomID()
        self.Name = ""
        self.RoomOwnerID = 0
        self.ServerID = 0
        self.BaseGameMode = 0
        self.SubGameMode = 0
        self.SeatNum = 0
        self.CurrentPlayerNum = 0
        self.Flag = 0 # 是否有密码
        self.Password = ""
        self.Player: list[ClientNode] = [None for i in range(CONST.MAX_SEAT_IN_ROOM)]
        self.Status = 0 # 是否开游戏了
        # self.MapID = 335 # 快算测结算地图
        self.MapID =  GetSelfDefinedConfig().DefaultMapID # 人气随机
        self.Weather = STDynamicInfo(0, 0, 0)
        self.SceneID = 0
        self.MusicID = 0
        self.GameCount = 0
        self.HasFirstFinished = False
        self.Props = []
        Rooms[self.ID] = self
    def StartGame(self):
        self.GameCount += 1
        self.Status = 0
        self.HasFirstFinished = False
        self.Props = [-1]
    def AddProp(self, PropID)->int: # Return PropIndex
        PropIndex = len(self.Props)
        self.Props.append(PropID)
        return PropIndex
    def YieldAllClients(self):
        for i in range(CONST.MAX_SEAT_IN_ROOM):
            if self.Player[i]:
                yield self.Player[i]
    def YieldTeammates(self, Client:ClientNode)->list[ClientNode]:
        for i in range(CONST.MAX_SEAT_IN_ROOM):
            if self.Player[i] and self.Player[i].TeamID == Client.TeamID and self.Player[i] != Client:
                yield self.Player[i]
    def YieldClientExcept(self, Client:ClientNode)->list[ClientNode]:
        for i in range(CONST.MAX_SEAT_IN_ROOM):
            if self.Player[i] and self.Player[i] != Client:
                yield self.Player[i]
    def __repr__(self):
        return f"[RoomNode|No.{self.ID}|{self.Name}]"
class STDynamicInfo:
    def __init__(self, Season, Timeslot, Weather):
        self.Season = Season
        self.Timeslot = Timeslot
        self.Weather = Weather
    def __repr__(self):
        return f"{type(self).__name__}(Season={self.Season}, Timeslot={self.Timeslot}, Weather={self.Weather})"
    

from collections import OrderedDict
ChatRooms: OrderedDict[int, 'ChatRoomNode'] = OrderedDict() # ChatRoomID -> ChatRoomNode
_ChatRoomID_ = 0
def GetChatRoomID() -> int:
    global _ChatRoomID_
    _ChatRoomID_ += 1
    return _ChatRoomID_
class ChatRoomNode:
    def __init__(self):
        self.ID = GetChatRoomID()
        self.Name = ""
        self.CurPlayerNum = 0
        self.MaxPlayerNum = 0
        self.RoomType = 0
        self.SceneID = 0
        self.x = 0
        self.y = 0
        self.z = 0
        self.Player:dict[int, ClientNode] = {} # Client.Uin -> Client
    def YieldClientExcept(self, Client:ClientNode)->list[ClientNode]:
        for i in self.Player:
            if self.Player[i] and self.Player[i] != Client:
                yield self.Player[i]
    def YieldAllClients(self)->list[ClientNode]:
        for i in self.Player:
            if self.Player[i]:
                yield self.Player[i]
    def __repr__(self):
        return f"[ChatRoomNode|No.{self.ID}|{self.Name}]"