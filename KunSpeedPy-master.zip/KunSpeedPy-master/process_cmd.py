from common import *
from basic_message import *

def deleteAccount(username:str):
    # 登录器登录的账号
    Uin = get_User().GetUin(username)
    if Uin == CONST.ROBOT_ID:
        logger.info(f"不能删除机器人账号: {username}")
        return False
    if Uin==0:
        logger.info(f"账号不存在: {username}")
    ret = get_Player().DeleteAccount(Uin)
    if not ret:
        logger.error(f"删除账号失败: {username}")
        return False
    ret = get_User().DeleteAccount(username)
    if not ret:
        logger.error(f"删除账号失败: {username}")
        return False

def clearAccounts():
    for username in get_User().GetAllUsernames():
        logger.info(f"删除账号: {username}")
        deleteAccount(username)
    return True

def lookup(username:str):
    Uin = get_User().GetUin(username)
    if Uin==0:
        logger.info(f"账号不存在: {username}")
    logger.info(f"user: {username} uin: {Uin}")

def enable_ob(Client:ClientNode):
    if Client and Client.Room:
        ResponseChangeOBState(Client, 1)
        for RoomClient in Client.Room.YieldAllClients():
            NotifyChangeOBState(RoomClient, Client.Uin, 1)

def add_item(uin:int, itemID:int):
    ret = get_Player().AddItem(uin, itemID, 1, -1, False)
    if ret:
        logger.info(f"添加物品成功: {itemID}")
    else:
        logger.warn(f"添加物品失败: {itemID}")
    

def change_map(Client:ClientNode, map_id:int):
    if Client and Client.Room:
        Client.Room.MapID = map_id
        # ResponseChangeMap(Client)
        for RoomClient in Client.Room.YieldAllClients():
            NotifyChangeMap(RoomClient, Client.Uin)
    
def process_cmd_from_client(cmd_s:str, Client:ClientNode)->str:
    try:
        cmd = cmd_s.split()
        if (cmd)==0:
            return "命令为空"
        elif cmd[0] == "enable_ob":
            enable_ob(Client)
        elif cmd[0] == "change_map":
            map_id = int(cmd[1])
            change_map(Client, map_id)
        elif cmd[0] == "add_item":
            item_id = int(cmd[1])
            add_item(Client.Uin, item_id)
        else:
            return f"未知命令{cmd_s}"
        return f"命令{cmd_s}执行成功"
    except:
        import traceback
        logger.warn(f"命令{cmd_s}执行失败\n{traceback.format_exc()}")
        return f"命令{cmd_s}执行失败"
            

def process_cmd(cmd_s:str):
    try:
        cmd = cmd_s.split()
        if len(cmd) == 0:
            return
        if cmd[0] == "update":
            update_all()
        elif cmd[0] == "deleteAccount":
            username = cmd[1]
            deleteAccount(username)
        elif cmd[0] == "clearAccounts":
            clearAccounts()
        elif cmd[0] == "lookup":
            username = cmd[1]
            lookup(username)
        elif cmd[0] == "add_item":
            uid = int(cmd[1])
            itemID = int(cmd[2])
            add_item(uid, itemID)
        elif cmd[0] == "enable_ob":
            uid = int(cmd[1])
            client = GetClient(uid)
            enable_ob(client)
        else:
            logger.error(f"未知命令【{cmd_s}】")
            return
        logger.info(f"命令【{cmd_s}】执行完毕")
    except:
        import traceback
        logger.info(f"命令【{cmd_s}】执行失败, error_msg: {traceback.format_exc()}")