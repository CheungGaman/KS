from common import *
from game import *


def ResponseStartShadowChallenge(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write32(p, 0) # ResultID
    SendToClient(Client, 1500, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)


def RequestStartShadowChallenge(Client: ClientNode, Data: Z_BYTES, BodyLen: int):
    Client.Room = None
    Client.GameID = 0
    ResponseStartShadowChallenge(Client)
    NotifyKartPhysParam(Client, [])
    NotifyOtherKartStoneInfo(Client)

    


def ResponseEndShadowChallenge(Client:ClientNode, ResultID:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, ResultID) # ResultID
    Write32(p, 0) # MoneyInc
    Write32(p, 0) # ExpInc
    Write32(p, 30) # MoneyTotal
    Write32(p, 1) # ExpTotal
    Write16(p, 0) # ItemNum
    for i in range(CONST.MAXAWORDSIZE):
        Write32(p, 0)
    SendToClient(Client, 1501, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)


def RequestEndShadowChallenge(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    Time = Read32(Body)
    value = 0 if Time != 0 else 3
    ResponseEndShadowChallenge(Client, value)
    

def ResponseReplayOperate(Client:ClientNode, Cmd:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin)
    Write16(p, 0) # ResultID
    Write8(p, Cmd) # Cmd
    Write32(p, 99) # Para0
    Write32(p, 0) # ReplayNum
    Write8(p, 0) # UrlTmplLen
    SendToClient(Client, 28421, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def RequestReplayOperate(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Cmd = Read8(Body)
    ResponseReplayOperate(Client, Cmd)