# 这是什么
使用**Python**语言重构的KunSpeed服务器框架，目前已经实现
- 多人竞速
    - 降低开局卡名次概率
    - 宝石发动信息可见
- 影子挑战
- 皮肤修复
    - 可装备
    - 房间中他人可见
    - 切换车辆时记住皮肤
- 宝石概率
    - 控制重生宝石概率与发动间隔
    - 仅竞速模式触发重生宝石
- 道具模式
    - 根据名次控制不同道具的概率
    - 道具可作用到自己与他人
    - 道具点提示
    - 最多吃两个道具
- 休闲区
    - 支持进入休闲区
    - 支持多人，互相可见
- 刷道具模式
    - 用于练习托道具
- 优化体验
    - 注册阶段即赠与几百辆满改+满宝石的车子，无需修改数据库
- 自定义配置
    - 所有配置信息均可在yml文件中修改，无需修改数据库
- 魔改功能
    - 房间中输入"cmd change_map 地图ID"可切换地图，包含客户端通过UI无法选择到的地图
    - 房间中输入"cmd enable_ob"可开启OB模式

# 为什么不用C++框架版本
- Python版的优势：
    - 快速开发测试迭代，无需编译
    - 快速查错，定位错误

- 关于Python版性能是否存在劣势：答案是**存在**，但是：
    - 已对性能瓶颈部分做针对性优化，例如数据库读写、网络收发等
    - 小规模测试下，暂时触碰不到性能瓶颈
    - C++版有个Bug，在网络差的情况下会触发CPU占用居高不下
    - 对于连接数非常多的情况，更重要的是用分布式而非一味提高单机性能


# 如何运行
更详细的参考ForeBeginner.md
```bash
# 切换至encrypt_tea目录
cd KunSpeedPy\build_encrypt_tea\encrypt_tea
# 编译TEA
python setup.py build
# 安装TEA
python setup.py install
# 切换至KunSpeedPy目录
cd ../..
# 修改DB目录
mv example_db db
# 部署项目依赖
pip install -r requirements.txt
# 运行服务端
python main.py
```


# 代码组织
- process_config.py: 处理yml配置
- database.py: 所有数据库处理均在这
- DirectoryServer.py: 目录服务器
- z_bytes.py: 处理bytes相关的工具函数
- data_structure.py: 基本的类型定义
- game.py: 处理游戏中的数据包收发逻辑，例如请求吃道具、使用道具等
- message.py: 处理大部分数据包收发
- basic_message.py: 处理小部分数据收发，这部分api可能被多个文件调用
- network.py: 处理网络收发
- player.py: 写用户的一些信息，例如用户的装备信息、用户的数据库信息、房间可见信息等
- process_cmd.py: 处理服务端下发命令，可以扩展成接收客户端指令
- room.py: 维护房间信息，包含房间有哪些用户等，用户在房间哪个位置等
- shadow_challenge.py: 处理影子挑战的数据包收发
- build_encrypt_tea: 编译C语言写的加密算法，用于python调用

# 数据组织
- db: 数据库信息，包含Player.db, User.db
- Kart: 车辆信息，包含性能、改装、氮气保护、落后补偿、宝石配置等。默认参数写在0.yml，如果存在对应车辆id的yml文件，则更新该文件中指定的参数。例如“六道魔尊”对应的ID为127441，则会先读取0.yml中的所有参数，再更新127441.yml中指定的参数：3个竞速宝石、50进气改装等。
- Map: 地图信息
    - Map.yml: 基本地图信息，包含地图ID，图名，圈数，是否套圈等
    - RandomMaps.yml: 指定随机地图池
- config: 自定义配置信息，由于在python中反复读取yml文件比较耗时，对大部分自定义配置做了缓存处理。如果需要更新配置信息，可以在服务端输入update指令，会清空缓存。
    - config.yml: 服务器监听ip与端口信息
    - Item.yml: 车辆信息
    - ShapeRefitCfg.yml: 车辆->皮肤对应信息
    - SingleSkillStoneCfg.yml: 宝石信息
    - DebugArgs.yml: 用于Debug的参数，每次用到都会读取文件，**不会被缓存**
    - TopListDesc-ZingSpeed.yml: 红人信息
    - SelfDefinedConfig.yml: 非常多的自定义配置，包含了注册即送的物品
    - PropMode: 道具模式不同名次对应的吃道具概率
    - DanceMusic.yml: 没用到
    - TimeChallenge*.yml: 没用到
    - TopListDesc-QQSpeed.yml: 没用到

# 一些小问题
- 注册时送的东西太多，切换性别/重登即可
- 十阶皮肤可以装备，但是特效不完整
- 多个线程共享一个buffer，会有潜在问题，但是目前还没触发，就没修。

# To Fix
- 道具模式细节
    - 香蕉皮自己踩需要清理
    - 香蕉皮、天使等作用成功提示
    - 当按下导弹/磁铁时，可以吃第三个道具
    - 组队模式
    - 道具概率
    - 激光攻击（二段激光）无效
- 组队模式
    - 无法看到队友道具
    - 情侣模式下导弹可以打到队友
- 轮滑模式
    - 在Map.yml中配置轮滑地图
    - 进入轮滑模式的时候需要切换轮滑鞋