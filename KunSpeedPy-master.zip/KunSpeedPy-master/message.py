from common import *
from DirectoryServer import *
from game import *
from shadow_challenge import *
from basic_message import *
from outdoor import *
from magic import *

def KickClient(Client:ClientNode):
    LeaveRoom(Client, 0)
    LeaveOutdoor(Client)
    
def NotifyKickFromServer(Client: ClientNode, SrcUin:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ReasonID
    Write32(p, SrcUin) # SrcUin
    Write8(p, 0) # ReasonLen
    Write8(p, 0) # AntiCheatMode
    Write8(p, 0) # KickType
    SendToClient(Client, 900, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifySkillStoneKartMoreInfo(Client: ClientNode, cars:list[int], HasMoreInfo:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin) # Uin
    Write32(p, len(cars))
    for car in cars:
        p = WriteKartStoneGrooveInfo(p, Client.Uin, car)
    Write8(p, HasMoreInfo)
    length = p - buf
    SendToClient(Client, 28416, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifySkillStoneKartInfo(Client: ClientNode, cars:list[int], HasMoreInfo:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin) # Uin
    Write32(p, len(cars))
    for car in cars:
        p = WriteKartStoneGrooveInfo(p, Client.Uin, car)
    Write8(p, HasMoreInfo)
    SendToClient(Client, 228, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)
    
def NotifyAllSkillStoneKartInfo(Client:ClientNode):
    cars = get_Player().GetCars(Client.Uin)
    if len(cars) <= CONST.MaxItems:
        NotifySkillStoneKartInfo(Client, cars, 0)
    else:
        NotifySkillStoneKartInfo(Client, cars[:CONST.MaxItems], 1)
        cars = cars[CONST.MaxItems:]
        while len(cars) > CONST.MaxItems:
            if len(cars) <= CONST.MaxItems:
                NotifySkillStoneKartMoreInfo(Client, cars, 0)
                cars = []
            else:
                NotifySkillStoneKartMoreInfo(Client, cars[:CONST.MaxItems], 1)
                cars = cars[CONST.MaxItems:]

        

def NotifySvrConfig3(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    p = WriteKartPhysParam(p, 0, 0) # NPCKartPhysPara
    MAX_NPC_AI_LEVEL_NUM = 12
    for i in range(MAX_NPC_AI_LEVEL_NUM): # NPCKartAIPhysPara
        pNPCKartAIPhysPara = p.detach()
        Write16(pNPCKartAIPhysPara, 0) # length
        Write32(pNPCKartAIPhysPara, 0) # NpcN2OIntervalTime
        Write32(pNPCKartAIPhysPara, 0) # NpcTriggerN2ORate
        Write32(pNPCKartAIPhysPara, 0) # NpcRestCheckTime
        Write32(pNPCKartAIPhysPara, 0) # NpcFixVelocity
        Write32(pNPCKartAIPhysPara, 0) # NpcFixVelocityRate
        Write32(pNPCKartAIPhysPara, 0) # NpcRunDisHulanThreshold
        Write32(pNPCKartAIPhysPara, 0) # NpcSJetRate
        Write32(pNPCKartAIPhysPara, 0) # NpcTurnAjustDisHulanRate
        Write8(pNPCKartAIPhysPara, 0) # ForwardAccelNum
        Write8(pNPCKartAIPhysPara, 0) # BackwardAccelNum
        Write32(pNPCKartAIPhysPara, 0) # StraightLenThreshold
        Write32(pNPCKartAIPhysPara, 0) # NpcDriftRate
        Write8(pNPCKartAIPhysPara, 0) # CompensateParamCount
        length = pNPCKartAIPhysPara - p
        Write16(p, length)
        p = pNPCKartAIPhysPara

    p = WriteKartPhysParam(p, 0, 0) # NPCKartPhysPara_NpcPlayer
    

    Write8(p, 12) # LevelNum
    for i in range(12): # NPCKartAIPhysPara_NpcPlayer
        pNPCKartAIPhysPara_NpcPlayer = p.detach()
        Write16(pNPCKartAIPhysPara_NpcPlayer, 0) # length
        if True: # Param
            pParam = pNPCKartAIPhysPara_NpcPlayer.detach()
            Write16(pParam, 0) # length
            Write32(pParam, 0) # NpcN2OIntervalTime
            Write32(pParam, 0) # NpcTriggerN2ORate
            Write32(pParam, 0) # NpcRestCheckTime
            Write32(pParam, 0) # NpcFixVelocity
            Write32(pParam, 0) # NpcFixVelocityRate
            Write32(pParam, 0) # NpcRunDisHulanThreshold
            Write32(pParam, 0) # NpcSJetRate
            Write32(pParam, 0) # NpcTurnAjustDisHulanRate
            Write8(pParam, 0) # ForwardAccelNum
            Write8(pParam, 0) # BackwardAccelNum
            Write32(pParam, 0) # StraightLenThreshold
            Write32(pParam, 0) # NpcDriftRate
            Write8(pParam, 0) # CompensateParamCount
            length = pParam - pNPCKartAIPhysPara_NpcPlayer
            Write16(pNPCKartAIPhysPara_NpcPlayer, length)
            pNPCKartAIPhysPara_NpcPlayer = pParam

        Write32(pNPCKartAIPhysPara_NpcPlayer, 0) # N2OStartTime
        Write32(pNPCKartAIPhysPara_NpcPlayer, 0) # NpcN2OMaxCount
        Write32(pNPCKartAIPhysPara_NpcPlayer, 0) # Dis2FirstPlay
        Write32(pNPCKartAIPhysPara_NpcPlayer, 0) # LostControlTime
        Write32(pNPCKartAIPhysPara_NpcPlayer, 0) # LostInterval
        Write32(pNPCKartAIPhysPara_NpcPlayer, 0) # LostControlCount

        length = pNPCKartAIPhysPara_NpcPlayer - p
        Write16(p, length)
        p = pNPCKartAIPhysPara_NpcPlayer

    p = WriteKartPhysParam(p, 0, 0) # NPCKartPhysPara_RankedMatch

    Write8(p, 12) # NPCLevelNum_RankedMatch
    for i in range(12): # NPCKartAIPhysPara_RankedMatch
        pNPCKartAIPhysPara_RankedMatch = p.detach()
        Write16(pNPCKartAIPhysPara_RankedMatch, 0) # length
        if True: # Param
            pParam = pNPCKartAIPhysPara_RankedMatch.detach()
            Write16(pParam, 0) # length
            Write32(pParam, 0) # NpcN2OIntervalTime
            Write32(pParam, 0) # NpcTriggerN2ORate
            Write32(pParam, 0) # NpcRestCheckTime
            Write32(pParam, 0) # NpcFixVelocity
            Write32(pParam, 0) # NpcFixVelocityRate
            Write32(pParam, 0) # NpcRunDisHulanThreshold
            Write32(pParam, 0) # NpcSJetRate
            Write32(pParam, 0) # NpcTurnAjustDisHulanRate
            Write8(pParam, 0) # ForwardAccelNum
            Write8(pParam, 0) # BackwardAccelNum
            Write32(pParam, 0) # StraightLenThreshold
            Write32(pParam, 0) # NpcDriftRate
            Write8(pParam, 0) # CompensateParamCount
            length = pParam - pNPCKartAIPhysPara_RankedMatch
            Write16(pNPCKartAIPhysPara_RankedMatch, length)
            pNPCKartAIPhysPara_RankedMatch = pParam
        Write32(pNPCKartAIPhysPara_RankedMatch, 0) # N2OStartTime
        Write32(pNPCKartAIPhysPara_RankedMatch, 0) # NpcN2OMaxCount
        Write32(pNPCKartAIPhysPara_RankedMatch, 0) # Dis2FirstPlay
        Write32(pNPCKartAIPhysPara_RankedMatch, 0) # LostControlTime
        Write32(pNPCKartAIPhysPara_RankedMatch, 0) # LostInterval
        Write32(pNPCKartAIPhysPara_RankedMatch, 0) # LostControlCount

        length = pNPCKartAIPhysPara_RankedMatch - p
        Write16(p, length)
        p = pNPCKartAIPhysPara_RankedMatch

    Write32(p, 0x0003BC27) # SwitchFlag1
    Write16(p, 60) # MaxQuickLerpThrehold
    Write16(p, 10) # QuickLerpStepCnts
    Write16(p, 12) # LerpSynccpFrequence
    Write16(p, 0) # ClientItemOpenTypeNum
    Write8(p, 1) # OtherNum
    for i in range(1): # CollisionPowerOtherInfo
        pCollisionPowerOtherInfo = p.detach()
        Write16(pCollisionPowerOtherInfo, 0) # length
        Write32(pCollisionPowerOtherInfo, 0) # Power
        Write32(pCollisionPowerOtherInfo, 100) # Ratio
        Write32(pCollisionPowerOtherInfo, 0) # Add
        length = pCollisionPowerOtherInfo - p
        Write16(p, length)
        p = pCollisionPowerOtherInfo

    Write32(p, 400) # CollisionMinPower
    Write32(p, 2900) # ItemExtendLimit
    Write32(p, 50) # ChattingTalkLevelLimit
    Write32(p, 0) # ChattingSpecialOp
    Write8(p, 0) # ForbidMapNum
    Write32(p, 20000) # MaxBuySpeedNum
    Write8(p, 0) # ClientItemIconNum
    Write8(p, 0) # TDCBlackCarNum
    # Write32(p, 0) # TDCBlackCar[]
    Write8(p, 0) # TDCBlackCarTypeNum
    # Write32(p, 0) # TDCBlackCarType[]
    Write8(p, 0) # TDCBlackCarType2ndNum
    # Write32(p, 0) # TDCBlackCarType2nd[]
    if True: # ClientFrameRateCfg
        pClientFrameRateCfg = p.detach()
        Write16(pClientFrameRateCfg, 0) # length
        Write32(pClientFrameRateCfg, 30000) # MinFrameRate
        Write32(pClientFrameRateCfg, 40000) # MaxFrameRate
        Write32(pClientFrameRateCfg, 10) # FrameStep
        Write32(pClientFrameRateCfg, 0) # CurrentFrameRate
        length = pClientFrameRateCfg - p
        Write16(p, length)
        p = pClientFrameRateCfg

    Write8(p, 16) # ReportFrameRateValue
    Write16(p, 10) # FrameOpSpan
    Write8(p, 0) # VideoSwitch
    Write8(p, 0) # KartRefitCardTypeNum
    length = p - buf
    SendToClient(Client, 25066, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifyTopUIItemInfo(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()

    Write32(p, Client.Uin) # Uin

    Write16(p, 2) # Num
    for i in range(2): # TopUIItemInfo
        pTopUIItemInfo = p.detach()
        Write16(pTopUIItemInfo, 0) # length
        Write8(pTopUIItemInfo, 0) # Type
        Write16(pTopUIItemInfo, 43) # ID
        Write16(pTopUIItemInfo, 0) # Tag
        Write16(pTopUIItemInfo, 0) # NameLen
        Write16(pTopUIItemInfo, 0) # PrompLen
        length = pTopUIItemInfo - p
        Write16(p, length)
        p = pTopUIItemInfo

    if True: # RecommendModeInfo
        pRecommendModeInfo = p.detach()
        Write16(pRecommendModeInfo, 0) # length
        Write16(pRecommendModeInfo, 0) # ModeNum
        length = pRecommendModeInfo - p
        Write16(p, length)
        p = pRecommendModeInfo
    Write8(p, 0) # Count
    Write8(p, 0) # SetNum
    Write8(p, 0) # MouseOverNum
    length = p - buf
    SendToClient(Client, 25116, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifyRedPointInfo(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin) # Uin
    Write8(p, 0) # RedPointNum
    Write8(p, 1) # All
    Write8(p, 0) # IsNeedPlayVideoGuid
    length = p - buf
    SendToClient(Client, 25114, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def MyResponseGetUin(Client: ClientNode, Uin: int, ResultID:int):
    logger.debug(f"Uin={Uin}")
    buf = get_buf()
    p = buf.detach()
    p.Write16(ResultID)
    p.Write32(Uin)
    length = p - buf
    SendToClient(Client, 1, buf, length, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Response)

def MyRequestGetUin(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    length = Body.Read8()
    UserName = Body[:length].get_value().decode()
    Uin = get_User().GetUin(UserName)
    MyResponseGetUin(Client, Uin, 0)

def MyResponseRegister(Client:ClientNode, Result:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, Result)
    SendToClient(Client, 2, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Response)
    
def MyRequestRegister(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    length = Read8(Body)
    UserName = ReadStringWithFixedLength(Body, length)
    length = Read8(Body)
    Password = ReadStringWithFixedLength(Body, length)
    Result = get_User().Register(UserName, Password)
    logger.info(f"[MyRequestRegister] 新用户注册，用户名：{UserName}，密码：{Password}, 结果：{Result}")
    
    Result = 1-int(Result)
    MyResponseRegister(Client, Result)


def RequestGetWorldInfo(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Body.Read32()
    Time = Body.Read32()
    ClientVersion = Body.Read32()
    MasterVersion = Body.Read32()
    SlaveVersion = Body.Read32()
    ResponseGetWorldInfo(Client, ClientVersion, MasterVersion, SlaveVersion)
    return 
    WorldId = Body.Read8()

    Body = Body[32:]

    ClientCnt = Body.Read8()
    IsSimplifyVersion = Body.Read8()
    PlayerFlag = Body.Read32()
    FileNum = Body.Read8()
    Body = Body[FileNum*4:] # 4 is sizeof(
    
def ResponseLogin(Client:ClientNode, ClientVersion:int, LoginType:int, Items:list[tuple[int,int,int,int,int,int]], HasMoreInfo:int, ResultID:int=0):
    buf = get_buf()
    p = buf.detach()
    Reason = ""
    Identity = ID_IDENTIFY.QQLEVEL1 | ID_IDENTIFY.QQLEVEL2 | ID_IDENTIFY.QQLEVEL3 | ID_IDENTIFY.QQFLAG | ID_IDENTIFY.HAVEWORD | ID_IDENTIFY.FINISHQQFLAG
    IsInTopList = 0
    if not Client.IsLogin:
        ResultID = 1
        Reason = "Incorrect password"
    else:
        VIPInfo = get_Player().GetVIPInfo(Client.Uin)
        if VIPInfo:
            Identity |= ID_IDENTIFY.SPEEDMEMBER
            IsInTopList = VIPInfo[1]
        else:
            ResultID = 1 # 未注册
    p.Write16(ResultID)
    WriteStringWithLength(p, Client.Key, bits_of_len=8)
    p.Write32(Client.Uin)
    p.Write32(Identity)
    p.Write16(Client.ConnID)
    p.Write32(LoginType)
    p.Write32(4)
    
    p = WritePlayerDBBaseInfo(p, Client.Uin)
    Write16(p, len(Items))
    for item in Items:
        pItemInfo = p.detach()
        ItemID,ItemNum,AvailPeriod,Status,ObtainTime,OtherAttribute=item
        ItemType = 0
        Write16(pItemInfo, 0) # length
        Write32(pItemInfo, ItemID)
        Write32(pItemInfo, ItemNum)
        Write32Int(pItemInfo, AvailPeriod) # 值可能为-1
        Write8(pItemInfo, Status)
        Write32(pItemInfo, ObtainTime)
        Write32(pItemInfo, OtherAttribute)
        Write16(pItemInfo, ItemType) # ItemType
        Write16(p, pItemInfo - p)
        p = pItemInfo
    Write16(p, 0) # TaskNum
    Write8(p, 0) # RecomCountry
    Write32(p, int(time.time()))
    # WriteStringWithLength(p, Reason, bits_of_len=8, encoding='gbk')
    Write8(p, 0)
    
    # PlayerRelationInfo
    pPlayerRelationInfo = p.detach()
    Write16(pPlayerRelationInfo, 0) # length
    Write32(pPlayerRelationInfo, Client.Uin) # SrcUin
    Write32(pPlayerRelationInfo, 0) # RelationFlag
    Write32(pPlayerRelationInfo, 0) # RelationUin
    WriteStringWithFixedLength(pPlayerRelationInfo, "", CONST.MaxNickName, encoding='gbk') # RelationNickName
    Write32(pPlayerRelationInfo, 0) # EngageTime
    Write32(pPlayerRelationInfo, 0) # NextCanBookingTimeLimit
    Write32(pPlayerRelationInfo, 0) # BeginHoneyMoonTime
    Write32(pPlayerRelationInfo, 0) # EndHoneyMoonTime
    Write8(pPlayerRelationInfo, 0) # EngageFlag
    Write16(p, pPlayerRelationInfo-p)
    p = pPlayerRelationInfo
    
    MapInfos = get_Player().GetMapInfo(Client.Uin)
    Write16(p, len(MapInfos))
    for mapInfo in MapInfos:
        MapID, Record = mapInfo
        pRecord = p.detach()
        Write32(pRecord, MapID)
        Write32(pRecord, Record)
        Write16(p, pRecord-p)
        p = pRecord
    
    Write16(p, 0) # PetNum
    
    Write8(p, IsInTopList) # IsInTopList
    Write32(p, 0) # LastLoginTime
    Write32(p, 0) # MasterPoint
    Write8(p, 0) # LoginRealNameFlag

    # ExRightFlag[]
    ClearLen = 24 if ClientVersion > 18457 else 16
    SetBytes(p.data, p.start, bytes(ClearLen), 0, ClearLen)
    p = p[ClearLen:]
    


    Write8(p, 0) # OverdueItemNum

    Write32(p, 0) # StoneKartNum
    Write32(p, 0) # LockedMapID
    Write32(p, 0) # TotalGuildProsperity
    Write32(p, 0) # ClientStatusContex
    Write8(p, 0) # IsHoneyMoon
    Write8(p, HasMoreInfo) # HasMoreInfo
    Write16(p, 0) # CurSvrID

    # NobleInfo
    pNobleInfo = p.detach()
    Write16(pNobleInfo, 0) # length

    Write32(pNobleInfo, Client.Uin) # NobleID
    Write8(pNobleInfo, 6) # NobleLevel
    Write32(pNobleInfo, 1) # NoblePoint
    Write32(pNobleInfo, 30) # NobleLeftDays

    length = pNobleInfo - p
    Write16(p, length)
    p = pNobleInfo

    Write16(p, 9998) # ExtendItemNum
    Write8(p, 60) # UpdateOnlineInfoInterval

    # GuildVipBaseInfo
    pGuildVipBaseInfo = p.detach()
    Write16(pGuildVipBaseInfo, 0) # length

    Write8(pGuildVipBaseInfo, 0) # GuildVipLevel
    Write32(pGuildVipBaseInfo, 0) # GuildVipPoint

    length = pGuildVipBaseInfo - p
    Write16(p, length)
    p = pGuildVipBaseInfo

    # GuildVipOtherInfo
    pGuildVipOtherInfo = p.detach()
    Write16(pGuildVipOtherInfo, 0) # length

    Write32(pGuildVipOtherInfo, 0) # GuildVipLeftDays
    Write8(pGuildVipOtherInfo, 0) # CanReceiveGift

    length = pGuildVipOtherInfo - p
    Write16(p, length)
    p = pGuildVipOtherInfo

    Write8(p, 0) # HasLDMInfo

    Write32(p, 0x7FFFFFFF) # ForbiddenModeFreeTime
    Write32(p, 0x7FFFFFFF) # ForbiddenModeBitSet

    # LoverVipBaseInfo
    pLoverVipBaseInfo = p.detach()
    Write16(pLoverVipBaseInfo, 0) # length

    Write8(pLoverVipBaseInfo, 0) # LoverVipLevel
    Write32(pLoverVipBaseInfo, 0) # LoverVipPoint
    Write8(pLoverVipBaseInfo, 0) # GrowRate

    length = pLoverVipBaseInfo - p
    Write16(p, length)
    p = pLoverVipBaseInfo
    
    # LoverVipOtherInfo
    pLoverVipOtherInfo = p.detach()
    Write16(pLoverVipOtherInfo, 0) # length

    Write32(pLoverVipOtherInfo, 0) # LoverVipLeftDays
    Write8(pLoverVipOtherInfo, 1) # CanReceiveGift
    Write8(pLoverVipOtherInfo, 0) # ShowExpireTips

    length = pLoverVipOtherInfo - p
    Write16(p, length)
    Write16(p, length)
    p = pLoverVipOtherInfo
    
    
    Write8(p, 3) # SkateTaskLevel 解锁地图
    Write32(p, 0) # SkateCoin
    Write8(p, 0) # SkateExpSkillLevel
    Write16(p, 0) # SkateCoinCountDaily
    Write32(p, 0) # SkateCoinHistoryTotal
    Write32(p, 0) # MaxDayPveScore
    Write32(p, 0) # MaxHistoryPveScore

    Write32(p, 0) # LoveValue

    Write8(p, 0) # HasCheerAddition

    # PersonalGardenBaseInfo
    pPersonalGardenBaseInfo = p.detach()
    Write16(pPersonalGardenBaseInfo, 0) # length

    Write8(pPersonalGardenBaseInfo, 0) # GardenLevel
    Write32(pPersonalGardenBaseInfo, 0) # GardenPoint
    Write8(pPersonalGardenBaseInfo, 0) # GrowRate
    Write32(pPersonalGardenBaseInfo, 0) # GardenExpireTime
    
    # SimpleInfo
    if True:
        pSimpleInfo = pPersonalGardenBaseInfo.detach()
        Write16(pSimpleInfo, 0) # length

        Write32(pSimpleInfo, 0) # WeekPopularity
        Write32(pSimpleInfo, 0) # TotalPopularity
        Write32(pSimpleInfo, 0) # LastUpdatePopularityTime
        Write8(pSimpleInfo, 0) # PrivateType

        length = pSimpleInfo - pPersonalGardenBaseInfo
        Write16(pPersonalGardenBaseInfo, length)
        pPersonalGardenBaseInfo = pSimpleInfo
    

    length = pPersonalGardenBaseInfo - p
    Write16(p, length)
    p = pPersonalGardenBaseInfo
    

    # ConsumeVipInfo
    pConsumeVipInfo = p.detach()
    Write16(pConsumeVipInfo, 0) # length

    Write32(pConsumeVipInfo, 0) # VipLevel
    Write32(pConsumeVipInfo, 0) # CharmValueOfMonth
    Write32(pConsumeVipInfo, 0) # SearchTreasureNums
    Write32(pConsumeVipInfo, 0) # GetTreasureNums

    length = pConsumeVipInfo - p
    Write16(p, length)
    p = pConsumeVipInfo
    

    # EmperorInfo
    pEmperorInfo = p.detach()
    Write16(pEmperorInfo, 0) # length

    Write8(pEmperorInfo, 0) # EmperorLevel
    Write32(pEmperorInfo, 0) # EmperorPoint
    Write32(pEmperorInfo, 0) # EmperorLeftDays
    Write8(pEmperorInfo, 0) # EmperorGrowRate

    length = pEmperorInfo - p
    Write16(p, length)
    p = pEmperorInfo
    
    # EmperorOtherInfo
    pEmperorOtherInfo = p.detach()
    Write16(pEmperorOtherInfo, 0) # length

    Write32(pEmperorOtherInfo, 0) # ExpiredTime
    Write8(pEmperorOtherInfo, 0) # ShowExpireTips

    length = pEmperorOtherInfo - p
    Write16(p, length)
    p = pEmperorOtherInfo
    

    Write32(p, 0) # ShuttleScoreWeek


    # ActivityInfo
    pActivityInfo = p.detach()
    Write16(pActivityInfo, 0) # length

    Write32(pActivityInfo, 0) # TotalActivity
    Write32(pActivityInfo, 0) # ActivityLevel

    length = pActivityInfo - p
    Write16(p, length)
    p = pActivityInfo
    

    # GansterScoreInfo
    pGansterScoreInfo = p.detach()
    Write16(pGansterScoreInfo, 0) # length

    Write32(pGansterScoreInfo, 0) # GansterSeasonID
    Write32(pGansterScoreInfo, 0) # GansterScore
    Write32(pGansterScoreInfo, 0) # PoliceScore
    Write32(pGansterScoreInfo, 0) # TotalGansterScore

    length = pGansterScoreInfo - p
    Write16(p, length)
    p = pGansterScoreInfo

    Write32(p, 0) # OlympicId
    Write32(p, 0) # NPCEliminateWinTimes

    # BorderInfo
    pBorderInfo = p.detach()
    Write16(pBorderInfo, 0) # length

    Write32(pBorderInfo, 0) # SeasonID
    Write32(pBorderInfo, 0) # Zhanxun
    Write32(pBorderInfo, 0) # SeasonZhanxun

    length = pBorderInfo - p
    Write16(p, length)
    p = pBorderInfo

    Write32(p, 0) # ReduceReturnRate
    Write32(p, 0) # ReduceReturnAvailPeriod
    Write8(p, 0) # SpecialActivityStatus
    Write32(p, 0) # ThemeHouseDressDegreeValue

    Write8(p, 0) # 3DRoomEnabled
    Write8(p, 0) # 3DRoomEnabled_OB
    Write8(p, 0) # BuyZizuanPopupOpen

    Write32(p, 0) # BuyZizuanPopupLimit
    Write8(p, 0) # EnableReconnectOpt

    Write8(p, 0) # HasRankedMatchInfo

    Write8(p, 0) # HasHuanLingChangeInfo

    Write8(p, 0) # EquipSealType
    Write8(p, 0) # hCreditStarFlag
    Write8(p, 0) # PersonalPanelSelectRankedMatchFrameTag
    Write8(p, 0) # VersionURLLen
    Write8(p, 0) # PrivacyURLLen
    Write8(p, 0) # PersonalRankedMatchLevelShowTag
    Write16(p, 0) # LeftDeletingRoleDays
    Write8(p, 0) # OnlyRspEquippedItem
    Write32(p, 0) # LoginSwitchFlag1
    Write16(p, 0) # LeftUploadPLogNum

    length = p - buf
    MsgID = GetServerType(Client.ServerID)
    if MsgID == ServerType.Relax:
        MsgID = 98
    elif MsgID == ServerType.Dance:
        MsgID = 95
    else: # Game
        MsgID = 100
    
    SendToClient(Client, MsgID, buf, length, Client.ConnID, FE.GAMESVRD, Client.ConnID, MsgType.Response)

def ResponseAndNotifyLoginAllInfo(Client:ClientNode, ClientVersion:int, LoginType:int):
    Items = get_Player().GetItems(Client.Uin)
    logger.debug(f"[ResponseAndNotifyLoginAllInfo] Items.size={len(Items)}")
    if len(Items) <= CONST.MaxItems:
        ResponseLogin(Client, ClientVersion, LoginType, Items, 0)
    else:
        ResponseLogin(Client, ClientVersion, LoginType, Items[:CONST.MaxItems], 1)
        Items = Items[CONST.MaxItems:]
        while len(Items) > 0:
            if len(Items) <= CONST.MaxItems:
                NotifyLoginMoreInfo(Client, Items, 0)
                Items = []
            else:
                NotifyLoginMoreInfo(Client, Items[:CONST.MaxItems], 1)
                Items = Items[CONST.MaxItems:]
        
def NotifyClientVipFlag(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    
    Write32(p, Client.Uin) # Uin
    Write16(p, CONST.VipFlag) # VipFlag
    Write16(p, 0) # MsgLen
    Write16(p, 0) # VipGrowRate
    
    length = p-buf
    SendToClient(Client, 948, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifyMsgBox(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()


    Write8(p, 0) # MsgType
    if True: # MsgBox
        pMsgBox = p.detach()
        Write16(pMsgBox, 0) # length

        if True: # OnlineTaskMsg
            pOnlineTaskMsg = pMsgBox.detach()
            Write16(pOnlineTaskMsg, 0) # length

            Write8(pOnlineTaskMsg, 0) # MsgType
            Write32(pOnlineTaskMsg, 0) # OpenDate
            Write32(pOnlineTaskMsg, 0) # OpenTime
            Write32(pOnlineTaskMsg, 0) # CloseDate
            Write32(pOnlineTaskMsg, 0) # CloseTime
            Write8(pOnlineTaskMsg, 0) # IsToday
            Write8(pOnlineTaskMsg, 0) # URLLen
            Write8(pOnlineTaskMsg, 0) # WeekLimit

            length = pOnlineTaskMsg - pMsgBox
            Write16(pMsgBox, length)
            pMsgBox = pOnlineTaskMsg
        if True: # VipPages
            pVipPages = pMsgBox.detach()
            Write16(pVipPages, 0) # length

            Write8(pVipPages, 0) # URLLen1
            Write8(pVipPages, 0) # URLLen2
            Write8(pVipPages, 0) # URLLen3

            length = pVipPages - pMsgBox
            Write16(pMsgBox, length)
            pMsgBox = pVipPages
        if True: # ActivitiesAd
            pActivitiesAd = pMsgBox.detach()
            Write16(pActivitiesAd, 0) # length

            Write8(pActivitiesAd, 0) # URLLen

            length = pActivitiesAd - pMsgBox
            Write16(pMsgBox, length)
            pMsgBox = pActivitiesAd
        if True: # MatchSchedule
            pMatchSchedule = pMsgBox.detach()
            Write16(pMatchSchedule, 0) # length

            Write8(pMatchSchedule, 0) # URLLen

            length = pMatchSchedule - pMsgBox
            Write16(pMsgBox, length)
            pMsgBox = pMatchSchedule
        if True: # LoadingAd
            pLoadingAd = pMsgBox.detach()
            Write16(pLoadingAd, 0) # length

            Write8(pLoadingAd, 0) # Ver
            Write8(pLoadingAd, 0) # URLLen

            length = pLoadingAd - pMsgBox
            Write16(pMsgBox, length)
            pMsgBox = pLoadingAd
        if True: # TaskAdvAd
            pTaskAdvAd = pMsgBox.detach()
            Write16(pTaskAdvAd, 0) # length

            Write8(pTaskAdvAd, 0) # URLLen

            length = pTaskAdvAd - pMsgBox
            Write16(pMsgBox, length)
            pMsgBox = pTaskAdvAd
        if True: # LoginAd
            pLoginAd = pMsgBox.detach()
            Write16(pLoginAd, 0) # length

            Write8(pLoginAd, 0) # URLLen

            length = pLoginAd - pMsgBox
            Write16(pMsgBox, length)
            pMsgBox = pLoginAd
        if True: # T3Ad
            pT3Ad = pMsgBox.detach()
            Write16(pT3Ad, 0) # length

            Write8(pT3Ad, 0) # URLLen1
            Write8(pT3Ad, 0) # URLLen2
            Write8(pT3Ad, 0) # URLLen3
            Write8(pT3Ad, 0) # URLLen4

            length = pT3Ad - pMsgBox
            Write16(pMsgBox, length)
            pMsgBox = pT3Ad

        length = pMsgBox - p
        Write16(p, length)
        p = pMsgBox

    length = p - buf
    SendToClient(Client, 596, buf, length, Client.ServerID, FE.GAMESVRD, Client.ConnID, MsgType.Notify)



def NotifyRandRoomNameList(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    RandomRoomNameList = ["RandRoomName A", "RandomRoomName B", "RandomRoom C"]

    Write8(p, len(RandomRoomNameList))
    for RandomRoomName in RandomRoomNameList:
        pRoomNames = p.detach()
        Write16(pRoomNames, 0) #length
        WriteStringWithLength(p, RandomRoomName, bits_of_len=8)
        for i in range(20):
            Write8(pRoomNames, 0)
        Write16(p, pRoomNames-p)
        p = pRoomNames

    length = p - buf
    SendToClient(Client, 760, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)


def NotifyTopListDesc(Client: ClientNode): # 红人
    buf = get_buf()
    p = buf.detach()
    topListDesc = getTopListDesc()
    Write16(p, len(topListDesc))
    for d in topListDesc:
        pDescs = p.detach()
        Write16(pDescs, 0) #length
        Write16(pDescs, d.ID)
        Name:str = d.Name+"\0"
        ValueDesc:str = d.ValueDesc+"\0"
        TitleName:str = d.TitleName+"\0"
        IsEnableSelfRank:int = int(d.IsEnableSelfRank)
        EncodedName = Name.encode('gbk')
        EncodedValueDesc = ValueDesc.encode('gbk')
        EncodedTitleName = TitleName.encode('gbk')
        SetBytes(pDescs.data, pDescs.start, EncodedName, 0, len(EncodedName))
        pDescs = pDescs[CONST.MaxNickName:]
        SetBytes(pDescs.data, pDescs.start, EncodedValueDesc, 0, len(EncodedValueDesc))
        pDescs = pDescs[CONST.MaxNickName:]
        SetBytes(pDescs.data, pDescs.start, EncodedTitleName, 0, len(EncodedTitleName))
        pDescs = pDescs[CONST.MaxNickName:]
        
        Write8(pDescs, 0) # HasOtherInfo

        Write8(pDescs, IsEnableSelfRank)
        Write16(p, pDescs-p)
        p = pDescs
    
    length = p - buf
    SendToClient(Client, 701, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifySpeed2Cfg(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p,0)
    Write8(p, 0)
    Write8(p, 127)
    SendToClient(Client, 11358, buf, p-buf, Client.ServerID, FE.GAMESVRD, Client.ConnID, MsgType.Notify)


def NotifySvrConfig(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()

    Write32(p, 5000) # GuildScoreThreshold

    if True: # LuckyMatchCfg
        pLuckyMatchCfg = p.detach()
        Write16(pLuckyMatchCfg, 0) # length

        WriteStringWithFixedLength(pLuckyMatchCfg, "", 50) # Time
        WriteStringWithFixedLength(pLuckyMatchCfg, "", 50) # Award
        WriteStringWithFixedLength(pLuckyMatchCfg, "", 50) # StartCondition
        Write32(pLuckyMatchCfg, 0) # LuckyMoney
        WriteStringWithFixedLength(pLuckyMatchCfg, "", 50) # MatchTitle

        length = pLuckyMatchCfg - p
        Write16(p, length)
        p = pLuckyMatchCfg

    if True: # MsgStoneSysCfg
        pMsgStoneSysCfg = p.detach()
        Write16(pMsgStoneSysCfg, 0) # length
        Write8(pMsgStoneSysCfg, 1) # StoneSkillTakeEffect

        if True: # SkillStoneCfg
            pSkillStoneCfg = pMsgStoneSysCfg.detach()
            Write16(pSkillStoneCfg, 0) # length

            pSkillStoneNum = pSkillStoneCfg.detach()
            singleStoneSkills = getSingleStoneSkillStoneCfg()
            Write32(pSkillStoneCfg, len(singleStoneSkills)) # SkillStoneNum
            for singleStoneSkill in singleStoneSkills:
                pSingleSkillStoneCfg = pSkillStoneCfg.detach()
                Write16(pSingleSkillStoneCfg, 0) # length
                Write32(pSingleSkillStoneCfg, singleStoneSkill.StoneID)
                Write32(pSingleSkillStoneCfg, singleStoneSkill.ActiveCondVal1)
                Write32(pSingleSkillStoneCfg, singleStoneSkill.UseCountUpperlimit)
                Write32(pSingleSkillStoneCfg, singleStoneSkill.ActiveSuccessProb)
                Write32(pSingleSkillStoneCfg, singleStoneSkill.CoolTime)
                Write32(pSingleSkillStoneCfg, singleStoneSkill.GenResultVal1)
                length = pSingleSkillStoneCfg - pSkillStoneCfg
                Write16(pSkillStoneCfg, length)
                pSkillStoneCfg = pSingleSkillStoneCfg
            length = pSkillStoneCfg - pMsgStoneSysCfg
            Write16(pMsgStoneSysCfg, length)
            pMsgStoneSysCfg = pSkillStoneCfg

        Write32(pMsgStoneSysCfg, 0) # Kart2StoneGrooveNum
        length = pMsgStoneSysCfg - p
        Write16(p, length)
        p = pMsgStoneSysCfg

    if True: # UITitleDispInfo
        pUITitleDispInfo = p.detach()
        Write16(pUITitleDispInfo, 0) # length

        DisplayBitMap = bytes([0b10111111])
        SetBytes(pUITitleDispInfo.data, pUITitleDispInfo.start, DisplayBitMap, 0, len(DisplayBitMap))
        pUITitleDispInfo = pUITitleDispInfo[len(DisplayBitMap):]
        

        if True: # ADText
            pADText = pUITitleDispInfo.detach()
            Write16(pADText, 0) # length

            WriteStringWithLength(pADText, getServerInfo()["Server"]["UITitleDispInfo_ADText"], 8, encoding='gbk')

            length = pADText - pUITitleDispInfo
            Write16(pUITitleDispInfo, length)
            pUITitleDispInfo = pADText

        length = pUITitleDispInfo - p
        Write16(p, length)
        p = pUITitleDispInfo

    if True: # LoaderTipInfo
        pLoaderTipInfo = p.detach()
        Write16(pLoaderTipInfo, 0) # length
        Write32(pLoaderTipInfo, 0) # Version
        Write8(pLoaderTipInfo, 0) # TipsNum
        # m_stLoaderTipInfo.m_astLoaderTipText[].m_u8TextLen
        length = pLoaderTipInfo - p
        Write16(p, length)
        p = pLoaderTipInfo

    if True: # MailSysAD
        pMailSysAD = p.detach()
        Write16(pMailSysAD, 0) # length
        ADText = "MailSysAD"
        WriteStringWithLength(pMailSysAD, ADText, 16, encoding='gbk')
        length = pMailSysAD - p
        Write16(p, length)
        p = pMailSysAD

    if True: # CheatReportCfg
        pCheatReportCfg = p.detach()
        Write16(pCheatReportCfg, 0) # length
        Write8(pCheatReportCfg, 1) # ReplayDayNum
        Write8(pCheatReportCfg, 1) # IsReportCheatEnable
        length = pCheatReportCfg - p
        Write16(p, length)
        p = pCheatReportCfg

    Write8(p, 0) # MaintainableKartNum
    Write32(p, 0) # CommonBitSwitch
    Write8(p, 0) # QQKart2ButtonLen

    if True: # GuildEnlistCfg
        pGuildEnlistCfg = p.detach()
        Write16(pGuildEnlistCfg, 0) # length
        Write8(pGuildEnlistCfg, 0) # MinUnloginDay
        Write8(pGuildEnlistCfg, 0) # CdDay
        Write8(pGuildEnlistCfg, 0) # MaxAwardTimeOneDay
        length = pGuildEnlistCfg - p
        Write16(p, length)
        p = pGuildEnlistCfg

    Write8(p, 1) # CloseQT
    Write32(p, 0) # QTCommonRoomID
    Write8(p, 0) # WlFetionDayLimit
    Write8(p, 0) # ShowShopIcon
    Write32(p, 0) # TiroRecommendMapNum
    # m_aiTiroRecommendMapIdList[]
    Write16(p, 0) # BoxMutiOpenLimit
    Write8(p, 0) # HallButtonShow
    Write8(p, 0) # HallButtonShowUrlLen
    Write32(p, 0) # EndlessModeBaseScorePerLevel
    Write32(p, 0) # GetShopNonSaleInfoInterval
    if True: # ShuttleRandMap
        pShuttleRandMap = p.detach()
        Write16(pShuttleRandMap, 0) # length
        Write16(pShuttleRandMap, 0) # BeginNum
        Write16(pShuttleRandMap, 0) # MidNum
        Write16(pShuttleRandMap, 0) # EndNum
        length = pShuttleRandMap - p
        Write16(p, length)
        p = pShuttleRandMap
    Write8(p, 0) # HasWeeklyRecommendModeClientInfo
    Write32(p, 0) # ReportWeeklyRecommendModeTriggerInfoInterval
    Write32(p, 0) # MaxEnergy
    Write32(p, 0) # N2ORatio
    Write32(p, 0) # PlayerNumRatio[]
    Write32(p, 0) # IsOpenBuf
    Write8(p, 0) # CouponTreasureGameButtonShow
    Write8(p, 0) # NewYearFinancingShow
    Write32(p, 0) # GuildTeamSignatureReportNumsLimit
    Write32(p, 0) # GetRelationItemMaxTimeout
    Write32(p, 0) # ClientWaitGameBeginTimeout
    length = p - buf
    SendToClient(Client, 800, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifySvrConfig2(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()

    Write8(p, 0) # HaveTopMapRecord
    Write8(p, 0) # HaveKartRoomPushInfo
    if True: # ClickStreamCfg
        pClickStreamCfg = p.detach()
        Write16(pClickStreamCfg, 0) # length
        Write8(pClickStreamCfg, 2) # ReportMode
        Write8(pClickStreamCfg, 3) # ContextNum
        Write8(pClickStreamCfg, 1)
        Write8(pClickStreamCfg, 2)
        Write8(pClickStreamCfg, 3)
        Write32(pClickStreamCfg, 100) # MaxNum
        length = pClickStreamCfg - p
        Write16(p, length)
        p = pClickStreamCfg
    Write8(p, 1) # IsGuildPKOpen
    Write8(p, 1) # IsEightYearsOpen
    Write8(p, 0) # HaveSkatePropGameLogicCfg
    Write16(p, 0) # SkatePropShoeNum
    # Write32(p, 0) # SkatePropShoeList[]
    Write16(p, 0) # SkatePropShoeNumForMultiGame
    # Write32(p, 0) # SkatePropShoeListForMultiGame[]
    Write32(p, 1) # AddAngleTime

    EMBM_MAX = 47
    for i in range(EMBM_MAX):
        pClassicMapInfo = p.detach()
        Write16(pClassicMapInfo, 0) # length
        Write32(pClassicMapInfo, 0) # MapNums
        length = pClassicMapInfo - p
        Write16(p, length)
        p = pClassicMapInfo
    
    Write8(p, 0) # OpenPopAds
    Write8(p, 0) # IsCloseSaveKeyTransInfo
    Write8(p, 0) # IsCloseSuperMoneySecondPsw
    Write32(p, 0) # NewMapNum

    for i in range(16):
        Write8(p, 0) # ClientSwitch[]

    Write8(p, 0) # OpenPwdRedEnvelop
    Write8(p, 0) # IsUseTCLS
    Write8(p, 0) # IsPropTeamMatchShow

    Write32(p, 0) # CfgNums
    Write8(p, 0) # IsShowBoardAllareaBubble
    Write8(p, 0) # RemindClearSuperMoneyLeftDays
    Write8(p, 0) # RemindClearSuperMoneyLeftHours
    Write32(p, 0) # RemindClearSuperMoneyThreshold
    Write16(p, 0) # RemindClearSuperMoneyInterval
    Write32(p, 0) # HPJMaxAccFuel
    Write32(p, 0) # HPJWildStatusAccelParam
    Write8(p, 0) # SwitchNum
    Write8(p, 1) # UseSign3
    Write8(p, 0) # OpenRankedMatchSpeedKing
    Write8(p, 0) # OpenLimitMapCollect
    Write8(p, 0) # HasMoreInfo

    length = p - buf
    SendToClient(Client, 822, buf, length, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)
    
def NotifyLoginMoreInfo(Client:ClientNode, Items:list[tuple[int,int,int,int,int,int]], HasMoreInfo:int):
    logger.debug(f"[NotifyLoginMoreInfo] Items.size={len(Items)}, HasMoreInfo={HasMoreInfo}")
    buf = get_buf()
    p = buf.detach()
    Write16(p, len(Items))
    for item in Items:
        pItemInfo = p.detach()
        ItemID,ItemNum,AvailPeriod,Status,ObtainTime,OtherAttribute=item
        ItemType = 0
        Write16(pItemInfo, 0) # length
        Write32(pItemInfo, ItemID)
        Write32(pItemInfo, ItemNum)
        Write32Int(pItemInfo, AvailPeriod) # 值可能为-1
        Write8(pItemInfo, Status)
        Write32(pItemInfo, ObtainTime)
        Write32(pItemInfo, OtherAttribute)
        Write16(pItemInfo, ItemType) # ItemType
        UpdateLen16(p, pItemInfo)
    Write16(p, 0) # TaskNum
    Write16(p, 0) # PetNum
    Write16(p, 0) # MapNum
    Write16(p, 0) # OverdueItemNum
    Write16(p, 0) # StoneKartNum
    Write8(p, HasMoreInfo)
    SendToClient(Client, 223, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def RequestLogin(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Body.Read32()
    Time = Body.Read32()
    ClientVersion = Body.Read32()
    Body = Body[CONST.MaxQQNickName+2:] # QQNickName + Gender + IconID
    
    AttachIdentify = Body.Read32()
    LoginType = Body.Read32()
    LoaderTipVersion = Body.Read32()
    ClientStatusContex = Body.Read32()
    IsSimplifyVersion = Body.Read8()
    CurTopMapRecordVersion = Body.Read32()
    CurKartRoomPushInfoVersion = Body.Read32()
    
    Client.Uin = Uin
    PreviousClient = GetClient(Uin)
    if PreviousClient:
        KickClient(PreviousClient)
        NotifyKickFromServer(PreviousClient, PreviousClient.Uin)
    AddClient(Client)
    NickName = get_Player().GetNick(Uin)
    Client.Nick = NickName
    Client.KartID = get_Player().GetEquippedCar(Uin)
    Suit = get_Player().GetConvertedSuit(Uin, Client.KartID)
    logger.info(f"[Login] NickName={NickName}")
    
    ResponseAndNotifyLoginAllInfo(Client, ClientVersion, LoginType)

    NotifyClientVipFlag(Client)
    NotifyMsgBox(Client)
    NotifyRandRoomNameList(Client)
    NotifyTopListDesc(Client)
    NotifySpeed2Cfg(Client)
    NotifySvrConfig(Client)
    NotifySvrConfig2(Client)
    NotifySvrConfig3(Client)
    NotifyTopUIItemInfo(Client)
    NotifyRedPointInfo(Client)
    NotifyAllSkillStoneKartInfo(Client)
    if Suit!=Client.KartID:
        ResponseSaveShapeRefit(Client, Client.KartID, 4, [0,0,0,0], Suit)
    

def ResponsetGetItemTimeLimtCfg(Client:ClientNode, UpdateTime:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin)
    Write16(p, 0)
    Write32(p, 0)
    Write32(p, UpdateTime)
    SendToClient(Client, 24201, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def RequestGetItemTimeLimtCfg(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    UpdateTime = Read32(Body)
    ResponsetGetItemTimeLimtCfg(Client, UpdateTime)
  
def ResponseNewGetFriendList(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    Write32(p, Client.Uin)
    Write16(p, 0)
    Write16(p, 0)
    Write16(p, 0)
    Write8(p, 0)
    SendToClient(Client, 163, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
  
def RequestNewGetFriendList(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseNewGetFriendList(Client)
    
def ResponseGetSystemTaskList(Client:ClientNode, TaskVersion):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    Write32(p, Client.Uin)
    Write32(p, TaskVersion)
    Write32(p, 0)
    Write32(p, 0)
    SendToClient(Client, 152, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
  
def RequestGetSystemTaskList(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    TaskVersion = Read32(Body)
    ResponseGetSystemTaskList(Client, TaskVersion)

def ResponseC2SGetKartAltasConfig(Client: ClientNode, CfgVersion:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin)
    Write32(p, CfgVersion)
    Write8(p, 0)
    Write16(p, 0)
    SendToClient(Client, 13710, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestC2SGetKartAltasConfig(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Read32(Body)
    Read32(Body)
    CfgVersion = Read32(Body)
    ResponseC2SGetKartAltasConfig(Client, CfgVersion)
def ResponseFishLogin(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # Result
    Write32(p, Client.Uin) # Uin
    if True:
        pBaseFishInfo = p.detach()
        Write16(pBaseFishInfo, 0) # len
        Write32(pBaseFishInfo, 0) # Experience
        Write32(pBaseFishInfo, 0) # Money
        Write8(pBaseFishInfo, 0) # FishStockNum
        Write8(pBaseFishInfo, 0) # RubbishCount
        Write16(p, pBaseFishInfo - p)
        p = pBaseFishInfo
    if True: # TodayInfo
        pTodayInfo = p.detach()
        Write16(pTodayInfo, 0) # len
        Write8(pTodayInfo, 0) # RestStealCount
        Write8(pTodayInfo, 0) # RestVisitStrangerCount
        Write8(pTodayInfo, 0) # RestClearRubbishCount
        Write16(p, pTodayInfo-p)
        p = pTodayInfo
    Write8(p, 0) # FishStockNum
    Write8(p, 0) # ReasonLen
    SendToClient(Client, 10501, buf, p-buf, 0, 32, Client.ConnID, MsgType.Response)

def RequestFishLogin(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseFishLogin(Client)
    
def RequestIgnore(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    return
# def RequestToImplement(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
#     return

def ResponseKartRefitInfoMoreInfo(Client:ClientNode, cars:list[int], HasMoreInfo:int):
    logger.info(f"[ResponseKartRefitInfoMoreInfo] cars.size={len(cars)}, HasMoreInfo={HasMoreInfo}]")
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin) # Uin
    Write16(p, len(cars))
    for kartID in cars:
        p = WriteKartRefitInfo(p, Client.Uin, kartID)
    Write8(p, HasMoreInfo)
    SendToClient(Client, 318, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    

def ResponseKartRefitInfo(Client: ClientNode, cars:list[int], HasMoreInfo:int): # 车辆改装信息
    logger.info(f"[ResponseKartRefitInfo] cars.size={len(cars)}, HasMoreInfo={HasMoreInfo}]")
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write32(p, Client.Uin)
    Write16(p, len(cars))
    for kartID in cars:
        p = WriteKartRefitInfo(p, Client.Uin, kartID)
    Write32(p, 0) # MaxLuckyWeight
    Write32(p, 0) # LuckyValue
    Write32(p, 0) # MaxLuckyValue
    Write8(p, 0) # LevelNum
    Write8(p, HasMoreInfo) # HasMoreInfo
    SendToClient(Client, 271, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
        
def RequestKartRefitInfo(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    cars = get_Player().GetCars(Client.Uin)
    if len(cars) <= CONST.MaxItems:
        ResponseKartRefitInfo(Client, cars, 0)
    else:
        ResponseKartRefitInfo(Client, cars[:CONST.MaxItems], 1)
        cars = cars[CONST.MaxItems:]
        while len(cars) > 0:
            if len(cars) <= CONST.MaxItems:
                ResponseKartRefitInfoMoreInfo(Client, cars, 0)
                cars = []
            else:
                ResponseKartRefitInfoMoreInfo(Client, cars[:CONST.MaxItems], 1)
                cars = cars[CONST.MaxItems:]
    
def ResponseFizzInfo(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    if True: # FizzBaseInfo
        pFizzBaseInfo = p.detach()
        Write16(pFizzBaseInfo, 0) # length
        Write16(pFizzBaseInfo, 0)
        Write16(pFizzBaseInfo, 0)
        Write32(pFizzBaseInfo, 0)
        Write8(pFizzBaseInfo, 0)
        Write16(p, pFizzBaseInfo-p)
        p = pFizzBaseInfo
    Write8(p, 0) # FizzTaskNum
    Write8(p, 0) # FizzLotteryNum
    SendToClient(Client, 944, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestFizzInfo(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseFizzInfo(Client)
    
def ResponseGetActivityCenterInfo(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin)
    Write32(p, 0) # TotalActivity
    Write32(p, 0) # CurrentWeekActivity
    Write32(p, 0) # LastWeekActivity
    Write32(p, 0) # CurrentDayActivity
    Write32(p, 0) # ActivityAppellcation
    Write32(p, 0) # ActivityLevel
    Write32(p, 0) # NextLevelActivity
    if True: # DailyActivityBox
        pDailyActivityBox = p.detach()
        Write16(pDailyActivityBox, 0) # length
        Write32(pDailyActivityBox, 0)
        Write32(pDailyActivityBox, 0)
        Write16(p, pDailyActivityBox-p)
        p = pDailyActivityBox
    if True: #ActivityTaskCfg
        pActivityTaskCfg = p.detach()
        Write16(pActivityTaskCfg, 0) # length
        Write32(pActivityTaskCfg, 0)
        Write16(p, pActivityTaskCfg-p)
        p = pActivityTaskCfg
    Write8(p, 0)
    Write32(p, 0)
    if True: # MultipleTimeCfg
        pMultipleTimeCfg = p.detach()
        Write16(pMultipleTimeCfg, 0) # length
        Write32(pMultipleTimeCfg, 0)
        Write32(pMultipleTimeCfg, 0)
        Write16(pMultipleTimeCfg, 0)
        Write16(p, pMultipleTimeCfg-p)
        p = pMultipleTimeCfg
    Write32(p,0) 
    Write8(p, 0)
    SendToClient(Client, 24029, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
        
        
def RequestGetActivityCenterInfo(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseGetActivityCenterInfo(Client)
    
def ResponseC2GSign3Operate(Client: ClientNode, OperateType:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin)
    Write16(p, 0)
    Write8(p, 0)
    Write8(p, OperateType)
    Write8(p, 0)
    Write8(p, 0)
    Write8(p, 0)
    Write8(p, 0)
    SendToClient(Client, 1401, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestC2GSign3Operate(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    OperateType = Read8(Body)
    ResponseC2GSign3Operate(Client, OperateType)

def ResponseGetLicenseInfo(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    Write32(p, Client.Uin)
    Write16(p, 0)
    Write8(p, 0)
    SendToClient(Client, 145, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestGetLicenseInfo(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseGetLicenseInfo(Client)
    
def ResponseGetTaskList(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    Write32(p, Client.Uin)
    Write16(p, 0) # TaskNum
    Write8(p, 0) # ReasonLen
    Write16(p, 0) # RecommendLen
    Write32(p, 0) # SpecialTaskID
    Write8(p, 0) # RecomTaskPackNum
    Write16(p, 0) # BlackListNum
    SendToClient(Client, 135, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def RequestGetTaskList(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseGetTaskList(Client)
    
def ResponseHello(Client: ClientNode, Uin: int, Time: int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, 0) # ReasonLen
    Write32(p, Time) # Time
    Write32(p, Uin) # Uin
    Write32(p, int(time.time())) # ServerTime
    Write32(p, 0) # ServerMicroSecond
    SendToClient(Client, 112, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def RequestHello(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    ResponseHello(Client, Uin, Time)

def ResponseLogout(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, 0) # ReasonLen
    
    SendToClient(Client, 101, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestLogout(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    logger.info(f"[Logout] 用户【{get_Player().GetNick(Client.Uin)}】退出登录")
    KickClient(Client)
    ResponseLogout(Client)
    HP_Server_Disconnect(Client.Sender, Client.ConnID, True)

def ResponseGetRandomTask(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    Write32(p, Client.Uin)
    Write32(p, 0) # TaskPackNum
    Write32(p, 0) # TaskNum
    Write16(p, 0) # TaskNum
    Write16(p, 0) # TaskDescNum
    SendToClient(Client, 187, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def RequestGetRandomTask(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseGetRandomTask(Client)

def ResponseGetMaster(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write32(p, Client.Uin) # Uin
    Write8(p, 0) # AccStatus
    Write32(p, 0) # MasterUin
    Write32(p, 0) # AccTime
    Write32(p, 0) # GraduateTime
    Write16(p, 0) # RecentPMAwardNum
    Write8(p, 0) # ReasonLen
    SendToClient(Client, 363, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestGetMaster(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseGetMaster(Client)
    
    
def ResponseGetAchieveList(Client: ClientNode, DstUin: int):
    buf = get_buf()
    p = buf.detach()

    Write32(p, Client.Uin) # Uin
    Write32(p, DstUin) # DstUin
    Write16(p, 0) # Result
    Write16(p, 1) # AchieveNum
    for i in range(1):
        pAchieves = p.detach()
        Write16(pAchieves, 0) # len
        Write16(pAchieves, 7937) # ID
        Write8(pAchieves, 0) # ShowType
        Write8(pAchieves, 0) # LogicType
        Write8(pAchieves, 0) # Status
        Write16(pAchieves, 0) # Progress
        Write16(pAchieves, 0) # TotalProgress
        Write32(pAchieves, 0) # FinTime
        Write16(pAchieves, 0) # AchieveValue
        Write32(pAchieves, 0) # AchieveFlagType
        UpdateLen16(p, pAchieves)
        
    SendToClient(Client, 373, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestGetAchieveList(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    DstUin = Read32(Body)
    ResponseGetAchieveList(Client, DstUin)

def ResponseSSCOpenStatus(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, 0) # Status
    Write8(p, 0) # TipsLen
    SendToClient(Client, 24721, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def RequestSSCOpenStatus(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseSSCOpenStatus(Client)
    
def ResponseSwitchInterface(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write32(p, 0) # Uin
    SendToClient(Client, 151, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestSwitchInterface(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseSwitchInterface(Client)
    
def ResponseGetShapeRefitCfg(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()

    Write16(p, 0) # ResultID
    Write16(p, 0) # KartShapeRefitSuitNum
    shapeRefits = getShapeRefitLegend()
    Write16(p, len(shapeRefits)) # KartShapeRefitLegendNum
    
    for d in shapeRefits:
        pShapeRefitLegend = p.detach()
        Write16(pShapeRefitLegend, 0) # len
        Write32(pShapeRefitLegend, d.KartID) # KartID
        Write8(pShapeRefitLegend, 0) # KarNameLen
        Write16(pShapeRefitLegend, 0) # Grade
        Write8(pShapeRefitLegend, 0) # GradeResourceLen
        Write8(pShapeRefitLegend, 0) # LevelNum
        Write32(pShapeRefitLegend, d.ShapeSuitID) # ShapeSuitID
        if True: # MaxConsumInfo
            pMaxConsumInfo = pShapeRefitLegend.detach()
            Write16(pMaxConsumInfo, 0) # len
            Write32(pMaxConsumInfo, 0) # ItemID
            Write32(pMaxConsumInfo, 0) # ItemNum
            Write32(pMaxConsumInfo, 0) # ItemPeriod
            UpdateLen16(pShapeRefitLegend, pMaxConsumInfo)
        Write8(pShapeRefitLegend, 0) # LegendSkinType
        UpdateLen16(p, pShapeRefitLegend)
    SendToClient(Client, 317, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestGetShapeRefitCfg(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseGetShapeRefitCfg(Client)

def ResponseGetPlayerEventCfg(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write32(p, 0) # GetFriendsEventInterval
    Write32(p, 0) # GetOtherEventInterval
    Write32(p, 0) # FilterTimeLimit
    SendToClient(Client, 11451, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestGetPlayerEventCfg(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseGetPlayerEventCfg(Client)

def ResponseSecondGetKartRefitLimitCfg(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    
    Write16(p, 0) # ResultID
    Write32(p, Client.Uin) # Uin
    if True: # KartRefitLimitCfg
        pKartRefitLimitCfg = p.detach()
        Write16(pKartRefitLimitCfg, 0) # len
        Write16(pKartRefitLimitCfg, 0) # OpenKartTypeNum
        # Write32(pKartRefitLimitCfg, 0) # OpenKartTypeList[]
        Write32(pKartRefitLimitCfg, 0) # MinFormerRefitTime
        Write16(pKartRefitLimitCfg, 0) # ExcludeKartTypeNum
        # Write32(pKartRefitLimitCfg, 0) # ExcludeKartTypeList[]
        Write16(pKartRefitLimitCfg, 0) # ForbidListNum
        # Write32(pKartRefitLimitCfg, 0) # ForbidRefitKartID[]
        UpdateLen16(p, pKartRefitLimitCfg)

    if True: # RefitItemWeightTypeCfg
        pRefitItemWeightTypeCfg = p.detach()
        Write16(pRefitItemWeightTypeCfg, 0) # len
        Write8(pRefitItemWeightTypeCfg, 0) # TypeNum
        UpdateLen16(p, pRefitItemWeightTypeCfg)

    if True: # RefitItemCfg
        pRefitItemCfg = p.detach()
        Write16(pRefitItemCfg, 0) # len
        Write16(pRefitItemCfg, 0) # ItemNum
        UpdateLen16(p, pRefitItemCfg)
    
    SendToClient(Client, 21111, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

    
def RequestSecondGetKartRefitLimitCfg(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseSecondGetKartRefitLimitCfg(Client)
    
def ResponseGetPrivilegeIntroInfo(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write32(p, 0) # Uin
    Write32(p, 0) # CharmValueOfMonth
    Write32(p, 0) # VipLevel
    Write16(p, 0) # PrivilegeInfoNums
    SendToClient(Client, 16055, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestGetPrivilegeIntroInfo(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseGetPrivilegeIntroInfo(Client)

def ResponseWeRelayCommonCfg(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    
    Write16(p, 0) # ResultID
    Write32(p, 0) # Uin
    if True: # SeasonCfg
        pSeasonCfg = p.detach()
        Write16(pSeasonCfg, 0) # len

        Write32(pSeasonCfg, 0) # SeasonId
        Write32(pSeasonCfg, 0) # OpenDate
        Write32(pSeasonCfg, 0) # CloseDate
        Write32(pSeasonCfg, 0) # OpenDayNum
        Write32(pSeasonCfg, 0) # BroadCastContentLen
        Write32(pSeasonCfg, 0) # OpenTimeTipsLen

        MAX_SPEEDRALLY_OPEN_DAY_NUM = 1
        for i in range(MAX_SPEEDRALLY_OPEN_DAY_NUM):
            ptDayOpenCfg = pSeasonCfg.detach()
            Write16(ptDayOpenCfg, 0) # len
            Write32(ptDayOpenCfg, 0) # DayID
            Write32(ptDayOpenCfg, 0) # OpenTimeNum
            UpdateLen16(pSeasonCfg, ptDayOpenCfg)
        Write32(pSeasonCfg, 0) # LuckyBoxIndex
        Write32(pSeasonCfg, 0) # LuckyBoxPriority
        Write32(pSeasonCfg, 0) # LuckyBoxDayLimit
        UpdateLen16(p, pSeasonCfg)
    Write32(p, 0) # RankNum
    Write32(p, 0) # ActiveAwardNum
    Write32(p, 0) # CarTypeNum
    Write32(p, 0) # TiyanCarTypeNum
    
    if True: # LuckyAwardToClient
        pLuckyAwardToClient = p.detach()
        Write16(pLuckyAwardToClient, 0) # len
        Write32(pLuckyAwardToClient, 0) # LuckBoxGet
        if True: # Award
            pAward = pLuckyAwardToClient.detach()
            Write16(pAward, 0) # len
            Write32(pAward, 0) # Exp
            Write32(pAward, 0) # Money
            Write32(pAward, 0) # SuperMoney
            Write16(pAward, 0) # ItemNum
            Write32(pAward, 0) # Coupons
            Write32(pAward, 0) # GuildPoint
            Write32(pAward, 0) # LuckMoney
            Write8(pAward, 0) # ExtendInfoNum
            Write32(pAward, 0) # SpeedCoin
            UpdateLen16(pLuckyAwardToClient, pAward)
        UpdateLen16(p, pLuckyAwardToClient)
    SendToClient(Client, 24391, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)


def RequestWeRelayCommonCfg(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    ResponseWeRelayCommonCfg(Client)
    

    
def RequestDoBagItemShowOperate(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    OptType = Read16(Body)
    ShowType = Read16(Body)
    TabType = Read16
    ItemID = Read32(Body)
    ItemNum = Read32(Body)
    if getItem().GetItemType(ItemID) == ItemType.EAIT_CAR:
        logger.error(f"[RequestDoBagItemShowOperate] Uin={Uin}, OptType={OptType}, ShowType={ShowType}, TabType={TabType}, ItemID={ItemID}, ItemNum={ItemNum}")
        raise Exception
    pass

def ResponsePreGetCommonBoxAward(Client: ClientNode, Type:int):
    buf = get_buf()
    p = buf.detach()
    
    
    Write32(p, Client.Uin) # Uin
    Write16(p, 0) # ResultID
    Write16(p, Type) # Type
    if True: # AwardCfgArray
        pAwardCfgArray = p.detach()
        Write16(pAwardCfgArray, 0) # len
        Write8(pAwardCfgArray, 1) # ScoreAwardNum
        for i in range(1): # ScoreAwardCfg
            pScoreAwardCfg = pAwardCfgArray.detach()
            Write16(pScoreAwardCfg, 0) # len
            Write8(pScoreAwardCfg, 1) # Type
            Write32(pScoreAwardCfg, 0) # StartScore
            if True: # AwardInfo
                pAwardInfo = pScoreAwardCfg.detach()
                Write16(pAwardInfo, 0) # len
                Write32(pAwardInfo, 0) # Exp
                Write32(pAwardInfo, 0) # Money
                Write32(pAwardInfo, 0) # SuperMoney
                Write16(pAwardInfo, 0) # ItemNum
                Write32(pAwardInfo, 0) # Coupons
                Write32(pAwardInfo, 0) # GuildPoint
                Write32(pAwardInfo, 0) # LuckMoney
                Write8(pAwardInfo, 0) # ExtendInfoNum
                Write32(pAwardInfo, 0) # SpeedCoin
                UpdateLen16(pScoreAwardCfg, pAwardInfo)

            Write8(pScoreAwardCfg, 0) # Status
            Write16(pScoreAwardCfg, 0) # ResultID
            Write16(pScoreAwardCfg, 0) # HasMoreInfo
            Write32(pScoreAwardCfg, 0) # PosKey
            Write8(pScoreAwardCfg, 0) # AwardIdx
            Write8(pScoreAwardCfg, 0) # LabelStatus
            Write8(pScoreAwardCfg, 0) # ExtraAwardNum
            UpdateLen16(pAwardCfgArray, pScoreAwardCfg)
        UpdateLen16(p, pAwardCfgArray)
    Write32(p, 0) # AwardID
    Write32(p, 0) # NextClearLeftTime
    Write8(p, 0) # HasMoreInfo
    Write32(p, 0) # Score
    Write16(p, 0) # LeftGetAwardNum
    Write8(p, 0) # Status
    Write8(p, 0) # EnableMergeSameItem
    Write32(p, 0) # TimeStart
    Write32(p, 0) # TimeEnd
    Write32(p, 0) # SCPara
    Write8(p, 0) # IsShowAllAward
    Write16(p, 0) # ValueNum
    # Write32(p, 0) # Values[]
    Write32(p, 0) # EchoClient
    SendToClient(Client, 24465, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)


def RequestPreGetCommonBoxAward(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    Type = Read16(Body)
    ResponsePreGetCommonBoxAward(Client, Type)
    
    
def RequestGetPetSkillList(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    pass

def ResponseGetPlayerEvent(Client: ClientNode, TargetType:int, TimeType:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, TargetType) # 
    Write8(p, TimeType) # 
    Write16(p, 0) # Num
    SendToClient(Client, 11452, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

    
    
def RequestGetPlayerEvent(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    TargetType = Read8(Body)
    TimeType = Read8(Body)
    ResponseGetPlayerEvent(Client, TargetType, TimeType)
    
def ChangeItemStatus(Client:ClientNode, aItemStatus:list[ItemStatus]):
    for v in aItemStatus:
        if v.NewStatus and isCar(v.ItemID):
            Client.KartID = v.ItemID
        logger.info(f"[ChangeItemStatus] 用户【{get_Player().GetNick(Client.Uin)}】修改物品【{v.ItemID}】状态为【{v.NewStatus}】")
        get_Player().UpdateItemStatus(Client.Uin, v.ItemID, v.NewStatus)
    
def ResponseChangeItemStatus(Client:ClientNode, aItemStatus:list[ItemStatus]):
    buf = get_buf()
    p = buf.detach()
    
    Write16(p, 0) # ResultID
    Write16(p, len(aItemStatus))
    for v in aItemStatus:
        pItemStatus = p.detach()
        Write16(pItemStatus, 0) # len
        Write32(pItemStatus, v.ItemID)
        Write8(pItemStatus, v.NewStatus)
        UpdateLen16(p, pItemStatus)
    Write8(p, 0) # ReasonLen
    Write8(p, 0) # SpecFlag
    Write8(p, 0) # ChangeType
    SendToClient(Client, 130, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def NotifyChangeItemStatus(Client:ClientNode, Uin:int, aItemStatus:list[ItemStatus]):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Uin)
    Write16(p, len(aItemStatus))
    for v in aItemStatus:
        pItemStatus = p.detach()
        Write16(pItemStatus, 0) # len
        if isCar(v.ItemID) and v.NewStatus:
            suitID = get_Player().GetConvertedSuit(Uin, v.ItemID)
            Write32(pItemStatus, suitID)
        else:
            Write32(pItemStatus, v.ItemID)
        Write32(pItemStatus, 1) # ItemNum
        Write32Int(pItemStatus, -1) # AvailPeriod
        Write8(pItemStatus, v.NewStatus) # Status
        Write32(pItemStatus, 1) # ObtainTime
        Write32(pItemStatus, 0) # OtherAttribute
        Write16(pItemStatus, 0) # ItemType
        UpdateLen16(p, pItemStatus)
    Write8(p, 0) # SpecFlag
    Write16(p, 0) # KartNum
    Write8(p, 0) # ChangeType
    Write8(p, 0) # EquipNiChangItemNum
    logger.info(f"[NotifyChangeItemStatus] 被通知的用户为{get_Player().GetNick(Client.Uin)}, 用户ID为{Client.Uin}, 通知的修改物品个数为{len(aItemStatus)}")
    SendToClient(Client, 527, buf, p-buf, Client.Room.ID, FE.ROOM, Client.ConnID, MsgType.Notify)
    
def RequestChangeItemStatus(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    ItemNum = Read16(Body)
    if ItemNum == 0: return
    aItemStatus:list[ItemStatus] = [ItemStatus(-1,-1) for i in range(ItemNum)]
    for i in range(ItemNum):
        pItemStatus = Body.detach()
        length = Read16(pItemStatus)
        aItemStatus[i].ItemID = Read32(pItemStatus)
        aItemStatus[i].NewStatus = Read8(pItemStatus)
        if isCar(aItemStatus[i].ItemID):
            SuitID = get_Player().GetConvertedSuit(Client.Uin, aItemStatus[i].ItemID)
            if SuitID != aItemStatus[i].ItemID:
                ResponseSaveShapeRefit(Client, aItemStatus[i].ItemID, 4, [0,0,0,0], SuitID)
        Body = Body[length:]
    ChangeItemStatus(Client, aItemStatus)
    ResponseChangeItemStatus(Client, aItemStatus)
    for otherClient in YieldOtherClientsInRoom(Client):
        NotifyChangeItemStatus(otherClient, Client.Uin, aItemStatus)

def ResponseLeaveRoom(Client:ClientNode, LeaveType:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, 0) # ReasonLen
    Write16(p, LeaveType) # LeaveType
    Write16(p, 0) # BaseGameMode
    Write16(p, 0) # SubGameMode
    Write8(p, 0) # IsLeaveGVoice
    SendToClient(Client, 105, buf, p-buf, Client.Room.ID, FE.ROOM, Client.ConnID, MsgType.Response)
def NotifyLeaveRoom(Client:ClientNode, Uin:int, SeatID:int, IsChangeRoomOwner:bool, NewRoomOwnerID:int, LeaveType:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, Client.Room.ID) # RoomID
    Write32(p, Uin) # Uin
    Write8(p, SeatID) # SeatID
    Write8(p, IsChangeRoomOwner) # IsChangeRoomOwner
    Write16(p, NewRoomOwnerID) # NewRoomOwnerID
    Write16(p, 0) # Flag
    Write8(p, 0) # HasFBInfo
    SendToClient(Client, 501, buf, p-buf, Client.Room.ID, FE.ROOM, Client.ConnID, MsgType.Notify)

def LeaveRoom(Client:ClientNode, LeaveType:int):
    Room = Client.Room
    if not Room: return
    ResponseLeaveRoom(Client, LeaveType)
    IsRoomOwner = Room.RoomOwnerID==Client.ConnID
    PlayerLeaveRoom(Client, Room)
    NewRoomOwnerID = Room.RoomOwnerID
    if Room.CurrentPlayerNum > 0:
        for i in range(CONST.MAX_SEAT_IN_ROOM):
            RoomClient = Room.Player[i]
            if RoomClient:
                NotifyLeaveRoom(RoomClient, Client.Uin, RoomClient.SeatID, IsRoomOwner, NewRoomOwnerID, LeaveType)
    else:
        # remove room
        DeleteRoom(Room)
    

            
            
    

def ResponseEnterRoom(Client: ClientNode, Room:RoomNode, IsAccept:bool):
    buf = get_buf()
    p = buf.detach()
        
    Write16(p, int(not IsAccept)) # ResultID
    Write16(p, Room.ID) # RoomID
    Write16(p, Room.BaseGameMode) # BaseGameMode
    Write16(p, Room.SubGameMode) # SubGameMode
    WriteStringWithFixedLength(p, Room.Name, CONST.MaxRoomName)
    Write8(p, Room.SeatNum) # SeatNum
    Write16(p, Room.Flag) # Flag
    Write8(p, Client.SeatID) # SeatID
    Write8(p, Client.TeamID) # TeamID
    Write32(p, Room.MapID) # MapID
    Write16(p, Room.RoomOwnerID) # RoomOwnerID
    
    for i in range(CONST.MAX_SEAT_IN_ROOM):
        Write8(p, 2)

    pPlayerCount = p.detach()
    Write8(p, 0)
    PlayerCount = 0
    # for RoomClient in Room.YieldAllClients():
    #     PlayerCount+=1
    #     p = WriteVisibleInfo(p, RoomClient.Uin, RoomClient.SeatID, RoomClient.ConnID) # PlayerRoomVisibleInfo
    Write8(pPlayerCount, PlayerCount)

    Write8(p, 0) # ReasonLen
    Write8(p, 0) # PlayerCount2
    Write16(p, 0) # KartNum
    Write8(p, Client.IsLoverProp) # LoverRaceOrPro
    if True: # STDynamicInfo
        pSTDynamicInfo = p.detach()
        Write16(pSTDynamicInfo, 0) # len
        Write8(pSTDynamicInfo, Room.Weather.Season)
        Write8(pSTDynamicInfo, Room.Weather.Timeslot)
        Write8(pSTDynamicInfo, Room.Weather.Weather)
        UpdateLen16(p, pSTDynamicInfo)

    Write32(p, 0) # PreKnowMapID
    Write8(p, 0) # HasMoreInfo
    Write32(p, 0) # MapSubID
    Write8(p, 0) # HasFBInfo
    Write32(p, 0) # GuildScoreInNextGame
    Write16(p, 0) # GuildScoreAlreadyAward
    Write16(p, 0) # GuildScoreTotalAward
    SendToClient(Client, 104, buf, p-buf, Room.ID, FE.ROOM, Client.ConnID, MsgType.Response)

def NotifyEnterRoom(Client:ClientNode, Room:RoomNode, EnterClient:ClientNode):
    buf = get_buf()
    p = buf.detach()
    
    Write16(p, Room.ID) # RoomID

    p = WriteRoomVisibleInfo(p, EnterClient) # NewPlayerInfo

    if True: # PlayerRelationInfo
        pPlayerRelationInfo = p.detach()
        Write16(pPlayerRelationInfo, 0) # len
        Write32(pPlayerRelationInfo, EnterClient.Uin) # SrcUin
        Write32(pPlayerRelationInfo, 0) # RelationFlag
        Write32(pPlayerRelationInfo, 0) # RelationUin
        WriteStringWithFixedLength(pPlayerRelationInfo, "", CONST.MaxNickName)
        Write32(pPlayerRelationInfo, 0) # EngageTime
        Write32(pPlayerRelationInfo, 0) # NextCanBookingTimeLimit
        Write32(pPlayerRelationInfo, 0) # BeginHoneyMoonTime
        Write32(pPlayerRelationInfo, 0) # EndHoneyMoonTime
        Write8(pPlayerRelationInfo, 0) # EngageFlag
        UpdateLen16(p, pPlayerRelationInfo)

    Write16(p, 0) # KartNum
    Write8(p, 0) # SpeFlag
    Write8(p, 0) # MapNum
    Write32(p, 0) # RoomNo
    Write16(p, 0) # SvrId
    Write16(p, 0) # RaceCardNums
    Write16(p, 0) # CreateRoomType
    Write16(p, 0) # ServerMatchType
    Write16(p, 0) # TeamMatchType
    Write16(p, 0) # MatchedRoomType
    Write8(p, 0) # InviteType
    Write8(p, 0) # HasWeRelayRoomInfo
    Write8(p, 0) # RoomFlag
    Write8(p, 0) # MaxOBNum
    Write8(p, 0) # AllowAutoStart
    Write8(p, 0) # HasLMInfo
    Write8(p, 0) # TalkRoomBGID
    Write16(p, 0) # Role
    Write8(p, 0) # ParaNum
    if True: # RoomInfoChange
        pRoomInfoChange = p.detach()
        Write16(pRoomInfoChange, 0) # len
        Write32(pRoomInfoChange, 0) # TeamJumpLevel
        Write32(pRoomInfoChange, 0) # RoomBGID
        UpdateLen16(p, pRoomInfoChange)
    Write32(p, 0) # PlayerEquipKartID
    Write32(p, 0) # RankedMatchTestDriveKartID
    Write8(p, 0) # FirstlyTipMap
    Write8(p, 0) # GVoiceRoomNameLen
    Write8(p, 0) # GVoiceReasonLen
    Write8(p, 0) # TDCExcluItemNum
    Write32(p, 0) # TDCExclusiveItemID[]
    Write8(p, 0) # TestKartGameType
    Write32(p, 0) # GameTestKartID
    Write8(p, 0) # HasStarsFightingInfo
    Write8(p, 0) # HasYuLeJiaNianHuaInfo
    SendToClient(Client, 500, buf, p-buf, Room.ID, FE.ROOM, Client.ConnID, MsgType.Notify)

        
def RequestEnterRoom(Client: ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    RoomID = Read16(Body)
    Password = ReadStringWithFixedLength(Body, CONST.MaxRoomPassword)
    InviteType = Read8(Body)
    InviterUin = Read32(Body)
    Room = GetRoom(RoomID)
    if not Room: return
    LeaveRoom(Client, 0)
    if (Room.Flag and Room.Password != Password):
        ResponseEnterRoom(Client, Room, False)
        return

    for i in range(CONST.MAX_SEAT_IN_ROOM):
        if Room.Player[i] == None:
            PlayerEnterRoom(Client, Room, i)
            logger.info(f"[RequestEnterRoom] Client {Client} Enter Room {Room}, SeatID = {i}")
            break
    ResponseEnterRoom(Client, Room, True)
    for RoomClient in YieldOtherClientsInRoom(Client):
        logger.info(f"[RequestEnterRoom] RoomClient {RoomClient} Enter Room {Room}, SeatID = {RoomClient.SeatID}")
        NotifyEnterRoom(RoomClient, Room, Client)
        NotifyEnterRoom(Client, Room, RoomClient)
    OnEnterRoom(Client)

def ResponseCreateRoom(Client:ClientNode, Room:RoomNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write16(p, Room.ID) # RoomID
    Write16(p, Room.BaseGameMode) # BaseGameMode
    Write16(p, Room.SubGameMode) # SubGameMode
    Write16(p, Room.Flag) # Flag
    WriteStringWithFixedLength(p, Room.Name, CONST.MaxRoomName)
    Write8(p, Room.SeatNum) # SeatNum
    Write8(p, 0) # SeatID
    Write8(p, 0) # TeamID
    Write8(p, 0) # ReasonLen
    Write8(p, Client.IsLoverProp) # LoverRaceOrPro
    Write32(p, Room.MapID) # MapID
    Write8(p, 0) # DebutOrX5
    Write32(p, int(time.time())) # ServerTime
    Write32(p, 0) # PreKnowMapID
    Write32(p, 0) # PreKnownMusicID
    Write8(p, 0) # HasFBInfo
    Write32(p, 0) # HasFBInfoGuildScoreInNextGame
    Write8(p, 0) # HasFBInfoContex
    Write16(p, 0) # GuildScoreAlreadyAward
    Write16(p, 0) # GuildScoreTotalAward
    Write8(p, 0) # HasFBInfoSpeFlag
    Write32(p, Room.ID) # RoomNo
    Write8(p, 0) # MoreInfoNum
    Write16(p, 0) # RaceCardNums
    Write16(p, 0) # CreateRoomType
    Write16(p, 0) # ServerMatchType
    Write16(p, 0) # TeamMatchType
    Write8(p, 0) # ChatRoomType
    Write16(p, 0) # SceneID
    Write8(p, 0) # PresetOBNum
    Write8(p, 0) # AllowAutoStart
    Write8(p, 0) # TalkRoomBGID
    Write16(p, 0) # Role
    Write8(p, 0) # ParaNum
    # ParaList[]
    Write8(p, 0) # ValueNum
    # EnterRoomValue[]
    Write32(p, 0) # PlayerEquipKartID
    Write32(p, 0) # RankedMatchTestDriveKartID
    Write8(p, 0) # GVoiceRoomNameLen
    Write8(p, 0) # GVoiceReasonLen
    Write8(p, 0) # TDCExcluItemNum
    # TDCExclusiveItemID[]
    Write8(p, 0) # TestKartGameType
    Write32(p, 0) # GameTestKartID
    Write8(p, 0) # HasStarsFightingInfo
    Write8(p, 0) # HasYuLeJiaNianHuaInfo
    SendToClient(Client, 103, buf, p-buf, Client.ServerID, FE.GAMESVRD, Client.ConnID, MsgType.Response)
        
def RequestCreateRoom(Client: ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    BaseGameMode = Read16(Body)
    SubGameMode = Read16(Body)
    Flag = Read16(Body)
    RoomName = ReadStringWithFixedLength(Body, CONST.MaxRoomName).strip("\x00")
    logger.info(f"[RequestCreateRoom] Uin={Uin}, Time={Time}, BaseGameMode={BaseGameMode}, SubGameMode={SubGameMode}, Flag={Flag}, RoomName={RoomName} lengthOfRoomName={len(RoomName)}")
    if not RoomName:
        RoomName = Client.RoomName
    SeatNum = Read8(Body)
    Password = ReadStringWithFixedLength(Body, CONST.MaxRoomPassword)

    Room = RoomNode()
    Room.BaseGameMode = BaseGameMode
    Room.SubGameMode = SubGameMode
    Room.Name = RoomName
    Room.ServerID = Client.ServerID
    Room.SeatNum = SeatNum
    Room.CurrentPlayerNum = 0
    Room.Flag = Flag
    Room.Password = Password
    Room.Status = 1
    PlayerEnterRoom(Client, Room, 0)
    ResponseCreateRoom(Client, Room)
    OnCreateRoom(Client)
    
def RequestLeaveRoom(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    LeaveType = Read16(Body)
    LeaveRoom(Client, LeaveType)

def ResponseGetRoomList(Client: ClientNode, BaseGameMode:int, SubGameMode:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    AllRooms = GetAllRooms()
    Write16(p, len(AllRooms)) # RoomNum
    Write16(p, 0) # StartIdx
    pRoomNum = p.detach()
    Write16(p, 0)
    RoomCount = 0
    for Room in AllRooms.values():
        # if Room.BaseGameMode == BaseGameMode and Room.SubGameMode == SubGameMode:
        if Client.ServerID==Room.ServerID: #根据频道查询房间
            RoomCount+=1
            pRooms = p.detach()
            Write16(pRooms, 0) # len
            Write16(pRooms, Room.ID) # RoomID
            Write16(pRooms, Room.BaseGameMode) # BaseGameMode
            Write16(pRooms, Room.SubGameMode) # SubGameMode
            Write8(pRooms, Room.CurrentPlayerNum) # CurrentPlayerNum
            Write8(pRooms, Room.SeatNum) # TotalSeatNum
            Write8(pRooms, Room.Status) # Status
            Write32(pRooms, Room.MapID) # MapID
            Write16(pRooms, Room.Flag) # Flag
            WriteStringWithFixedLength(pRooms, Room.Name, CONST.MaxRoomName)
            Write8(pRooms, 0) # HasFBInfo
            UpdateLen16(p, pRooms)
    Write16(pRoomNum, RoomCount)
    logger.debug(f"[ResponseGetRoomList] RoomCount={RoomCount}")
    Write8(p, 0) # ReasonLen
    Write16(p, BaseGameMode) # BaseGameMode
    Write16(p, SubGameMode) # SubGameMode
    Write8(p, 0) # FBAvailableLev
    Write8(p, 0) # FBLev
    Write8(p, 0) # FBSeason
    Write16(p, 0) # ChannelStatus
    Write8(p, 0) # RoomFlag
    SendToClient(Client, 102, buf, p-buf, Client.ServerID, FE.GAMESVRD, Client.ConnID, MsgType.Response)

def RequestGetRoomList(Client: ClientNode, Body:Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    StartRoomIdx = Read16(Body)
    GetRoomNum = Read16(Body)
    BaseGameMode = Read16(Body)
    SubGameMode = Read16(Body)
    ResponseGetRoomList(Client, BaseGameMode, SubGameMode)


def ResponseFindPlayerByQQ(Client:ClientNode, DstUin:int):
    buf = get_buf()
    p = buf.detach()

    Write16(p, 0) # ResultID
    if True: # PlayerInfo
        pPlayerInfo = p.detach()
        Write16(pPlayerInfo, 0) # len
        Write32(pPlayerInfo, DstUin) # Uin
        Write32(pPlayerInfo, 0) # Identity
        Write16(pPlayerInfo, 0) # PlayerID
        pPlayerInfo = WritePlayerDBBaseInfo(pPlayerInfo, DstUin)
        pPlayerInfo = WritePlayerGuildInfo(pPlayerInfo, DstUin)
        pPlayerInfo = WriteEquipedItem(pPlayerInfo, DstUin)
        Write32(pPlayerInfo, 0) # MasterPoint
        Write32(pPlayerInfo, 0) # TotalGuildProsperity
        Write16(pPlayerInfo, 0x0106) # VipFlag
        Write16(pPlayerInfo, 0) # VipGrowRate
        Write8(pPlayerInfo, 0) # AppellationNum
        if True: # NobleInfo
            pNobleInfo = pPlayerInfo.detach()
            Write16(pNobleInfo, 0) # len
            Write32(pNobleInfo, DstUin) # NobleID
            Write8(pNobleInfo, 6) # NobleLevel
            Write32(pNobleInfo, 0) # NoblePoint
            Write32(pNobleInfo, 0) # NobleLeftDays
            UpdateLen16(pPlayerInfo, pNobleInfo)
        Write8(pPlayerInfo, 0) # HasCarryWizard

        if True: # GuildVipBaseInfo
            pGuildVipBaseInfo = pPlayerInfo.detach()
            Write16(pGuildVipBaseInfo, 0) # len
            Write8(pGuildVipBaseInfo, 0) # GuildVipLevel
            Write32(pGuildVipBaseInfo, 0) # GuildVipPoint
            UpdateLen16(pPlayerInfo, pGuildVipBaseInfo)
        Write8(pPlayerInfo, 0) # HasLDMInfo
        Write8(pPlayerInfo, 0) # HasLoverVip
        Write8(pPlayerInfo, 0) # IsShowMounts
        Write8(pPlayerInfo, 0) # HasGarden
        Write8(pPlayerInfo, 0) # isConsumeVip
        Write32(pPlayerInfo, 0) # ConsumeVipLevel
        Write32(pPlayerInfo, 0) # SearchTreasureNums
        Write32(pPlayerInfo, 0) # GetTreasureNums
        Write32(pPlayerInfo, 0) # ConsumeVipCharmVlaueOfMonth
        if True: # EmperorInfo
            pEmperorInfo = pPlayerInfo.detach()
            Write16(pEmperorInfo, 0) # len
            Write8(pEmperorInfo, 0) # EmperorLevel
            Write32(pEmperorInfo, 0) # EmperorPoint
            Write32(pEmperorInfo, 0) # EmperorLeftDays
            Write8(pEmperorInfo, 0) # EmperorGrowRate
            UpdateLen16(pPlayerInfo, pEmperorInfo)
        if True: # EmperorOtherInfo
            pEmperorOtherInfo = pPlayerInfo.detach()
            Write16(pEmperorOtherInfo, 0) # len
            Write32(pEmperorOtherInfo, 0) # ExpiredTime
            Write8(pEmperorOtherInfo, 0) # ShowExpireTips
            UpdateLen16(pPlayerInfo, pEmperorOtherInfo)
        if True: # ActivityInfo
            pActivityInfo = pPlayerInfo.detach()
            Write16(pActivityInfo, 0) # len
            Write32(pActivityInfo, 0) # TotalActivity
            Write32(pActivityInfo, 0) # ActivityLevel
            UpdateLen16(pPlayerInfo, pActivityInfo)
        Write8(pPlayerInfo, 0) # HaveWakedKartAttributeAddInfo
        Write8(pPlayerInfo, 0) # HaveLoverBabyInfo
        if True: # GansterScoreInfo
            pGansterScoreInfo = pPlayerInfo.detach()
            Write16(pGansterScoreInfo, 0) # len
            Write32(pGansterScoreInfo, 0) # GansterSeasonID
            Write32(pGansterScoreInfo, 0) # GansterScore
            Write32(pGansterScoreInfo, 0) # PoliceScore
            Write32(pGansterScoreInfo, 0) # TotalGansterScore
            UpdateLen16(pPlayerInfo, pGansterScoreInfo)
        Write32(pPlayerInfo, 0) # OlympicId
        Write32(pPlayerInfo, 0) # LastOlympicUpdateTime
        Write32(pPlayerInfo, 0) # NPCEliminateWinTimes
        if True: # BorderInfo
            pBorderInfo = pPlayerInfo.detach()
            Write16(pBorderInfo, 0) # len
            Write32(pBorderInfo, 0) # SeasonID
            Write32(pBorderInfo, 0) # Zhanxun
            Write32(pBorderInfo, 0) # SeasonZhanxun
            UpdateLen16(pPlayerInfo, pBorderInfo)
        Write8(pPlayerInfo, 0) # SpecialActivityID
        Write32(pPlayerInfo, 0) # ThemeHouseCollectValue
        Write8(pPlayerInfo, 0) # HaveSecondLoverBabyInfo
        if True: # SecondLoverBabyInfo
            pSecondLoverBabyInfo = pPlayerInfo.detach()
            Write16(pSecondLoverBabyInfo, 0) # len
            Write32(pSecondLoverBabyInfo, 0) # BabyStatus
            Write32(pSecondLoverBabyInfo, 0) # LoverBabyItemID
            Write32(pSecondLoverBabyInfo, 0) # LoverBabyID
            Write32(pSecondLoverBabyInfo, 0) # BabyGrowLevel
            Write32(pSecondLoverBabyInfo, 0) # BabyStrengthLevel
            Write16(pSecondLoverBabyInfo, 0) # LoverBabyStat
            Write16(pSecondLoverBabyInfo, 0) # LoverBabyEquipStat
            Write16(pSecondLoverBabyInfo, 0) # LoverBabyTransferdStatus
            UpdateLen16(pPlayerInfo, pSecondLoverBabyInfo)
        Write8(pPlayerInfo, 0) # EquipBaby
        Write8(pPlayerInfo, 0) # ActiveStatus
        Write32(pPlayerInfo, 0) # HelperLev
        Write8(pPlayerInfo, 0) # HasRankedMatchInfo
        Write16(pPlayerInfo, 0) # PlayerSeasonInfoNums
        Write8(pPlayerInfo, 0) # IsHelperAppOnline
        Write32(pPlayerInfo, 0) # RankedMatchSpeedGodNums
        Write8(pPlayerInfo, 0) # EquipSealType
        Write8(pPlayerInfo, 0) # HasHuanLingChangeInfo
        Write8(pPlayerInfo, 0) # SpecialActivityIDNum
        Write8(pPlayerInfo, 0) # PersonalPanelSelectRankedMatchFrameTag
        Write8(pPlayerInfo, 0) # SpecialActivityInfoNum
        Write8(pPlayerInfo, 0) # PersonalRankedMatchLevelShowTag
        Write8(pPlayerInfo, 0) # ItemNum
        Write8(pPlayerInfo, 0) # ExRightFlagLen
        Write8(pPlayerInfo, 0) # EquipNiChangItemNum
        UpdateLen16(p, pPlayerInfo)
    Write8(p, 1) # IsOnLine
    if True: # PositionInfo
        pPositionInfo = p.detach()
        Write16(pPositionInfo, 0) # len
        Write8(pPositionInfo, 0) # ServerType
        Write16(pPositionInfo, 0) # Status
        Write32(pPositionInfo, 0) # ServerID
        if True: # RoomInfo
            pRoomInfo = pPositionInfo.detach()
            Write16(pRoomInfo, 0) # len
            Write16(pRoomInfo, 0) # RoomID
            Write16(pRoomInfo, 0) # BaseGameMode
            Write16(pRoomInfo, 0) # SubGameMode
            Write8(pRoomInfo, 0) # CurrentPlayerNum
            Write8(pRoomInfo, 0) # TotalSeatNum
            Write8(pRoomInfo, 0) # Status
            Write32(pRoomInfo, 0) # MapID
            Write8(pRoomInfo, 0) # Flag
            WriteStringWithFixedLength(pRoomInfo, "", CONST.MaxRoomName)
            Write8(pRoomInfo, 0) # HasFBInfo
            Write8(pRoomInfo, 0) # SpeFlag
            Write32(pRoomInfo, 0) # RoomNo
            Write16(pRoomInfo, 0) # SvrId
            Write16(pRoomInfo, 0) # SceneID
            Write8(pRoomInfo, 0) # CurrentOBNum
            Write8(pRoomInfo, 0) # TotalOBNum
            Write8(pRoomInfo, 0) # SpecialActivityStatus
            Write8(pRoomInfo, 0) # AllowAutoStart
            Write32(pRoomInfo, 0) # Gender
            Write32(pRoomInfo, 0) # LocaleCode
            Write8(pRoomInfo, 0) # TalkRoomBGID
            Write8(pRoomInfo, 0) # SpecialActivityIDNum
            Write8(pRoomInfo, 0) # SpecialActivityInfoNum
            Write8(pRoomInfo, 0) # ValueNum
            # Write32(pRoomInfo, 0) # EnterRoomValue[]
            Write8(pRoomInfo, 0) # ParaNum
            # Write32(pRoomInfo, 0) # ParaList[]
            Write32(pRoomInfo, 0) # GSvrRoomNo
            # OwnerName[]
            WriteStringWithFixedLength(pRoomInfo, "", CONST.MaxNickName)
            UpdateLen16(pPositionInfo, pRoomInfo)
        Write8(pPositionInfo, 0) # StatusLen
        Write8(pPositionInfo, 0) # CanJoin
        UpdateLen16(p, pPositionInfo)
    Write8(p, 0) # ReasonLen
    if True: # PlayerRelationInfo
        pPlayerRelationInfo = p.detach()
        Write16(pPlayerRelationInfo, 0) # len
        Write32(pPlayerRelationInfo, 0) # SrcUin
        Write32(pPlayerRelationInfo, 0) # RelationFlag
        Write32(pPlayerRelationInfo, 0) # RelationUin
        # RelationNickName[]
        WriteStringWithFixedLength(pPlayerRelationInfo, "", CONST.MaxNickName)
        Write32(pPlayerRelationInfo, 0) # EngageTime
        Write32(pPlayerRelationInfo, 0) # NextCanBookingTimeLimit
        Write32(pPlayerRelationInfo, 0) # BeginHoneyMoonTime
        Write32(pPlayerRelationInfo, 0) # EndHoneyMoonTime
        Write8(pPlayerRelationInfo, 0) # EngageFlag
        UpdateLen16(p, pPlayerRelationInfo)
    KartItemId = get_Player().GetEquippedSuit(DstUin) # ZTODO
    logger.info(f"[ResponseFindPlayerByQQ] KartItemId={KartItemId}")
    if True: # CurKartAttr
        pCurKartAttr = p.detach()
        Write16(pCurKartAttr, 0) # len
        cfg = get_Karts().GetKart(KartItemId)
        

        Write32(pCurKartAttr, DstUin) # Uin
        Write32(pCurKartAttr, KartItemId) # KartId
        Write32(pCurKartAttr, cfg.RefitCout) # RefitCout
        Write16(pCurKartAttr, cfg.MaxFlags) # MaxFlags
        Write16(pCurKartAttr, cfg.WWeight) # WWeight
        Write16(pCurKartAttr, cfg.SpeedWeight) # SpeedWeight
        Write16(pCurKartAttr, cfg.JetWeight) # JetWeight
        Write16(pCurKartAttr, cfg.SJetWeight) # SJetWeight
        Write16(pCurKartAttr, cfg.AccuWeight) # AccuWeight
        Write32(pCurKartAttr, cfg.ShapeRefitCount) # ShapeRefitCount
        Write32(pCurKartAttr, cfg.KartHeadRefitItemID) # KartHeadRefitItemID
        Write32(pCurKartAttr, cfg.KartTailRefitItemID) # KartTailRefitItemID
        Write32(pCurKartAttr, cfg.KartFlankRefitItemID) # KartFlankRefitItemID
        Write32(pCurKartAttr, cfg.KartTireRefitItemID) # KartTireRefitItemID
        if True: # KartRefitExInfo
            pKartRefitExInfo = pCurKartAttr.detach()
            Write16(pKartRefitExInfo, 0) # len
            Write8(pKartRefitExInfo, 0) # SpeedRefitStar
            Write8(pKartRefitExInfo, 0) # JetRefitStar
            Write8(pKartRefitExInfo, 0) # SJetRefitStar
            Write8(pKartRefitExInfo, 0) # AccuRefitStar
            Write8(pKartRefitExInfo, 0) # SpeedAddRatio
            Write8(pKartRefitExInfo, 0) # JetAddRatio
            Write8(pKartRefitExInfo, 0) # SJetAddRatio
            Write8(pKartRefitExInfo, 0) # AccuAddRatio
            UpdateLen16(pCurKartAttr, pKartRefitExInfo)
        Write32(pCurKartAttr, 0) # SecondRefitCount
        Write16(pCurKartAttr, 0) # Speed2Weight
        Write16(pCurKartAttr, 0) # DriftVecWeight
        Write16(pCurKartAttr, 0) # AdditionalZSpeedWeight
        Write16(pCurKartAttr, 0) # AntiCollisionWeight
        Write16(pCurKartAttr, 0) # LuckyValue
        Write16(pCurKartAttr, 0) # RefitLuckyValueMaxWeight
        Write32(pCurKartAttr, 0) # ShapeSuitID
        Write8(pCurKartAttr, 0) # LegendSuitLevel
        Write32(pCurKartAttr, 0) # LegendSuitLevelChoice
        Write32(pCurKartAttr, 0) # ShapeLegendSuitID
        UpdateLen16(p, pCurKartAttr)
    Write16(p, 0) # PetNum
    Write8(p, 1) # IsInTopList
    if True: # KartStoneGrooveInfo
        p = WriteKartStoneGrooveInfo(p, Client.Uin, KartItemId)
    Write8(p, 0) # Contex
    if True: # PlayerWlVisibleInfo
        pPlayerWlVisibleInfo = p.detach()
        Write16(pPlayerWlVisibleInfo, 0) # len
        Write32(pPlayerWlVisibleInfo, 0) # WonderLandID
        # WonderLandName[]
        WriteStringWithFixedLength(pPlayerWlVisibleInfo, "", CONST.MaxNickName)
        Write16(pPlayerWlVisibleInfo, 0) # WonderLandDuty
        Write8(pPlayerWlVisibleInfo, 0) # SubType
        Write8(pPlayerWlVisibleInfo, 0) # GuildGrade
        UpdateLen16(p, pPlayerWlVisibleInfo)
    Write32(p, 0) # SkateCoin
    Write32(p, 0) # MaxDayPveScore
    Write32(p, 0) # MaxHistoryPveScore
    if True: # EquipedCarBattleModeSkillInfoList
        pEquipedCarBattleModeSkillInfoList = p.detach()
        Write16(pEquipedCarBattleModeSkillInfoList, 0) # len
        Write8(pEquipedCarBattleModeSkillInfoList, 0) # SkillNum
        UpdateLen16(p, pEquipedCarBattleModeSkillInfoList)
    Write8(p, 0) # HasCCVisibleInfo
    Write8(p, 0) # HasCheerAddition
    Write32(p, 0) # LoveValue
    Write16(p, 0) # CanEnterChannelFalg[]
    Write8(p, 0) # SpecialActivityID
    Write32(p, 0) # ThemeHouseDressDegreeValue
    Write8(p, 0) # AreaIdDst
    Write8(p, 0) # SpecialActivityIDNum
    Write8(p, 0) # SimpleInfo
    SendToClient(Client, 122, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

    
def RequestFindPlayerByQQ(Client:ClientNode, Body:Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    Body = Body[CONST.MaxNickName:]
    DstUin = Read32(Body)
    ResponseFindPlayerByQQ(Client, DstUin)

def ResponseSaveShapeRefit(Client:ClientNode, KartID:int, RefitItemNum:int, RefitItemID:list[int], ShapeSuitID:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, 0) # ReasonLen
    Write32(p, KartID) # KartItemID
    if True: # KartRefitExInfo
        pKartRefitExInfo = p.detach()
        Write16(pKartRefitExInfo, 0) # len
        Write8(pKartRefitExInfo, 0) # SpeedRefitStar
        Write8(pKartRefitExInfo, 0) # JetRefitStar
        Write8(pKartRefitExInfo, 0) # SJetRefitStar
        Write8(pKartRefitExInfo, 5) # AccuRefitStar
        Write8(pKartRefitExInfo, 0) # SpeedAddRatio
        Write8(pKartRefitExInfo, 0) # JetAddRatio
        Write8(pKartRefitExInfo, 0) # SJetAddRatio
        Write8(pKartRefitExInfo, 0) # AccuAddRatio
        UpdateLen16(p, pKartRefitExInfo)
    Write8(p, RefitItemNum) # RefitItemNum
    Write32(p, RefitItemID[0]) # RefitItemID[]
    Write32(p, RefitItemID[1]) # RefitItemID[]
    Write32(p, RefitItemID[2]) # RefitItemID[]
    Write32(p, RefitItemID[3]) # RefitItemID[]
    Write32(p, ShapeSuitID) # ShapeSuitID
    if True: # RefitClientInfo
        pRefitClientInfo = p.detach()
        Write16(pRefitClientInfo, 0) # len
        Write32(pRefitClientInfo, Client.Uin) # Uin
        Write32(pRefitClientInfo, KartID) # KartId
        Write32(pRefitClientInfo, 0) # RefitCout
        Write16(pRefitClientInfo, 0) # MaxFlags
        Write16(pRefitClientInfo, 0) # WWeight
        Write16(pRefitClientInfo, 0) # SpeedWeight
        Write16(pRefitClientInfo, 0) # JetWeight
        Write16(pRefitClientInfo, 0) # SJetWeight
        Write16(pRefitClientInfo, 0) # AccuWeight
        Write32(pRefitClientInfo, 0) # ShapeRefitCount
        Write32(pRefitClientInfo, RefitItemID[0]) # KartHeadRefitItemID
        Write32(pRefitClientInfo, RefitItemID[1]) # KartTailRefitItemID
        Write32(pRefitClientInfo, RefitItemID[2]) # KartFlankRefitItemID
        Write32(pRefitClientInfo, RefitItemID[3]) # KartTireRefitItemID
        if True: # KartRefitExInfo
            pKartRefitExInfo = pRefitClientInfo.detach()
            Write16(pKartRefitExInfo, 0) # len
            Write8(pKartRefitExInfo, 0) # SpeedRefitStar
            Write8(pKartRefitExInfo, 0) # JetRefitStar
            Write8(pKartRefitExInfo, 0) # SJetRefitStar
            Write8(pKartRefitExInfo, 0) # AccuRefitStar
            Write8(pKartRefitExInfo, 6) # SpeedAddRatio
            Write8(pKartRefitExInfo, 0) # JetAddRatio
            Write8(pKartRefitExInfo, 0) # SJetAddRatio
            Write8(pKartRefitExInfo, 0) # AccuAddRatio
            UpdateLen16(pRefitClientInfo, pKartRefitExInfo)
        Write32(pRefitClientInfo, 0) # SecondRefitCount
        Write16(pRefitClientInfo, 0) # Speed2Weight
        Write16(pRefitClientInfo, 0) # DriftVecWeight
        Write16(pRefitClientInfo, 0) # AdditionalZSpeedWeight
        Write16(pRefitClientInfo, 0) # AntiCollisionWeight
        Write16(pRefitClientInfo, 0) # LuckyValue
        Write16(pRefitClientInfo, 0) # RefitLuckyValueMaxWeight
        suitid = 0
        if ShapeSuitID == 127359: # 雷诺·幻夜
            suitid = 126537
        elif ShapeSuitID == 127360: # 众神·乾坤
            suitid = 127365
        elif ShapeSuitID == 120246: # 爆天-曜影
            suitid = 118729
        elif ShapeSuitID == 126355: # 源极-大河守卫
            suitid = 127437
        elif ShapeSuitID == 123513: # 悟空-齐天大圣
            suitid = 123238
        else:
            suitid = ShapeSuitID
        get_Player().UpdateEquippedSuit(Client.Uin, KartID, suitid)
        Write32(pRefitClientInfo, suitid) # ShapeSuitID
        Write8(pRefitClientInfo, 7) # LegendSuitLevel
        Write32(pRefitClientInfo, 8) # LegendSuitLevelChoice
        Write32(pRefitClientInfo, ShapeSuitID) # ShapeLegendSuitID
        UpdateLen16(p, pRefitClientInfo)
    SendToClient(Client, 316, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)


def RequestSaveShapeRefit(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    KartItemID = Read32(Body)
    RefitItemNum = Read8(Body)
    KartHeadRefitItemID = Read32(Body)
    KartTailRefitItemID = Read32(Body)
    KartFlankRefitItemID = Read32(Body)
    KartTireRefitItemID = Read32(Body)
    ShapeSuitID = Read32(Body)
    # TODO: save refit to db
    RefitItemID = [KartHeadRefitItemID, KartTailRefitItemID, KartFlankRefitItemID, KartTireRefitItemID]
    logger.info(f"[RequestSaveShapeRefit] KartItemID={KartItemID}, RefitItemNum={RefitItemNum}, RefitItemID={RefitItemID}, ShapeSuitID={ShapeSuitID}")
    ResponseSaveShapeRefit(Client, KartItemID, RefitItemNum, RefitItemID, ShapeSuitID)
    


def ResponseRegister(Client:ClientNode, NickName:str, Gender:int, Country:int, Items:list[tuple[int,int,int,int,int,int]]):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write32(p, Client.Uin)
    WriteStringWithFixedLength(p, NickName, CONST.MaxNickName)
    Write8(p, Gender)
    Write8(p, Country)
    Write16(p, len(Items))
    for item in Items:
        pItemInfo = p.detach()
        ItemID,ItemNum,AvailPeriod,Status,ObtainTime,OtherAttribute=item
        ItemType = 0
        Write16(pItemInfo, 0) # length
        Write32(pItemInfo, ItemID)
        Write32(pItemInfo, ItemNum)
        Write32Int(pItemInfo, AvailPeriod) # 值可能为-1
        Write8(pItemInfo, Status)
        Write32(pItemInfo, ObtainTime)
        Write32(pItemInfo, OtherAttribute)
        Write16(pItemInfo, ItemType) # ItemType
        UpdateLen16(p, pItemInfo)
    Write16(p, 0) # AddTaskNum
    Write8(p, 0) # ReasonLen
    SendToClient(Client, 129, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def ResponseSkipFreshTask(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    Write32(p, Client.Uin)
    SendToClient(Client, 183, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def RequestRegister2(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    ret = get_Player().Register_Player(Uin, CONST.VipFlag, 1)
    if not ret:
        logger.info(f"[RequestRegister2] Register_Player failed")
        return
    NickName = ReadStringWithFixedLength(Body, CONST.MaxNickName).strip("\x00")
    logger.info(f"[RequestRegister2] Uin={Uin}, NickName={NickName}, NickName.len={len(NickName)}")
    Gender = Read8(Body)
    Country = Read8(Body)
    if not get_Player().Register_BaseInfo(Uin, NickName, Gender, Country):
        logger.error(f"[RequestRegister2] Register_BaseInfo failed, Uin={Uin}, NickName={NickName}")
        return False
    RoleID = Read32(Body)
    HairID = Read32(Body)
    FaceID = Read32(Body)
    CoatID = Read32(Body)
    GloveID = Read32(Body)
    TrousersID = Read32(Body)
    KartID = Read32(Body)
    ColorID = Read32(Body)
    
    get_Player().AddItem(Uin, RoleID, 1, -1, True)
    get_Player().AddItem(Uin, HairID, 1, -1, True)
    get_Player().AddItem(Uin, FaceID, 1, -1, True)
    get_Player().AddItem(Uin, CoatID, 1, -1, True)
    get_Player().AddItem(Uin, GloveID, 1, -1, True)
    get_Player().AddItem(Uin, TrousersID, 1, -1, True)
    get_Player().AddItem(Uin, KartID, 1, -1, True)
    get_Player().AddItem(Uin, ColorID, 1, -1, True)
    # 3D 男装
    get_Player().AddItem(Uin, 27178, 1, -1, True)
    get_Player().AddItem(Uin, 27179, 1, -1, True)
    get_Player().AddItem(Uin, 27180, 1, -1, True)
    get_Player().AddItem(Uin, 27181, 1, -1, True)
    get_Player().AddItem(Uin, 27182, 1, -1, True)
    # 3D 女装
    get_Player().AddItem(Uin, 27190, 1, -1, True)
    get_Player().AddItem(Uin, 27191, 1, -1, True)
    get_Player().AddItem(Uin, 27192, 1, -1, True)
    get_Player().AddItem(Uin, 27193, 1, -1, True)
    get_Player().AddItem(Uin, 27194, 1, -1, True)
    Items = get_Player().GetItems(Uin)
    ResponseRegister(Client, NickName, Gender, Country, Items)
    ResponseSkipFreshTask(Client)
    get_Player().AddItems(Uin, [(gift.ItemID, gift.ItemNum, gift.AvailPeriod, False) for gift in GetSelfDefinedConfig().GiftForRegister])

def ResponseChangeGender(Client:ClientNode, NewGender:int, UseType:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    Write8(p, NewGender)
    Write8(p, 0)
    Write8(p, UseType)
    SendToClient(Client, 162, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def ResponseChangeReadyState(Client:ClientNode, ReadyState:bool):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, ReadyState)
    Write8(p, 0) # ReasonLen
    SendToClient(Client, 109, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def NotifyChangeReadyState(Client:ClientNode, Uin:int, ReadyState:bool):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Uin)
    Write8(p, ReadyState)
    SendToClient(Client, 504, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def RequestChangeReadyState(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    ReadyState = Read8(Body)
    Client.ReadyState = ReadyState
    ResponseChangeReadyState(Client, ReadyState)
    if Client.Room:
        for RoomClient in Client.Room.YieldClientExcept(Client):
            NotifyChangeReadyState(RoomClient, Uin, ReadyState)

def ResponseChangeTeam(Client:ClientNode, NewTeamID:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, NewTeamID)
    Write8(p, 0) # ReasonLen
    Write8(p, 0) # LoverRaceOrPro
    SendToClient(Client, 128, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

def NotifyChangeTeam(Client:ClientNode, Uin:int, NewTeamID:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Uin)
    Write8(p, NewTeamID)
    Write8(p, 0) # LoverRaceOrPro
    SendToClient(Client, 523, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def RequestChangeTeam(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    NewTeamID = Read8(Body)
    Client.TeamID = NewTeamID
    ResponseChangeTeam(Client, NewTeamID)
    if Client.Room:
        for RoomClient in Client.Room.YieldClientExcept(Client):
            NotifyChangeTeam(RoomClient, Uin, NewTeamID)



def ResponseTalk(Client: ClientNode, Type:int, ClientUseFlag:int, DestPlayerUin:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, Type) 
    Write8(p, ClientUseFlag)
    Write32(p, DestPlayerUin)
    Write8(p, 0) # ReasonLen
    Write8(p, 0) # BugletType
    Write8(p, 0) # ReserveFlag
    Write8(p, 0) # ReserveData
    Write8(p, 0) # TalkSpecialType
    Write32(p, 0) # Seq
    SendToClient(Client, 111, buf, p-buf, Client.RoomID, FE.ROOM, Client.ConnID, MsgType.Response)
    
    
    
def RequestExchangeLoverMode(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    # Mode: 0 道具 1 竞速
    Uin = Read32(Body)
    Time = Read32(Body)
    SrcTeam = Read8(Body)
    DstMode = Read8(Body)
    DstUin = Read32(Body)
    SrcMode = 1 - DstMode
    Client.IsLoverProp = (DstMode==0)
    logger.info(f"[RequestExchangeLoverMode] Client={Client}, Uin={Uin}, SrcTeam={SrcTeam}, SrcMode={SrcMode}, DstUin={DstUin}, DstMode={DstMode}")
    
    # ResponseExchangeLoverMode
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write32(p, Uin) # SrcUin
    Write8(p, SrcTeam) # SrcTeam
    Write8(p, SrcMode) # SrcMode
    SendToClient(Client, 303, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)

    # NotifyExchangeLoverMode
    buf = get_buf()
    p = buf.detach()
    Write8(p, SrcTeam) # Team
    Write32(p, Uin) # SrcUin
    Write8(p, SrcMode) # SrcMode
    Write32(p, DstUin) # DstUin
    Write8(p, DstMode) # DstMode
    for RoomClient in Client.Room.YieldAllClients():
        SendToClient(RoomClient, 304, buf, p-buf, RoomClient.ConnID, FE.PLAYER, RoomClient.ConnID, MsgType.Notify)

def NotifyTalk(Client:ClientNode, Uin:int, NickName:str, Type:int, ClientUseFlag:int, DestPlayerUin:int, Content:str):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Uin)
    WriteStringWithFixedLength(p, NickName, CONST.MaxNickName)
    Write8(p, 0) # Gender
    Write8(p, Type)
    Write8(p, ClientUseFlag)
    Write32(p, DestPlayerUin)
    WriteStringWithLength(p, Content, bits_of_len=16)
    Write8(p, 0) # BugletType
    Write16(p, 0) # Identify
    Write16(p, 0) # VipFlag
    Write8(p, 0) # CanReport
    if True: # TalkerInfo
        pTalkerInfo = p.detach()
        Write16(pTalkerInfo, 0) # len
        Write32(pTalkerInfo, 0) # Exp
        if True: # NobleInfo
            pNobleInfo = pTalkerInfo.detach()
            Write16(pNobleInfo, 0) # len
            Write32(pNobleInfo, Client.Uin) # NobleID
            Write8(pNobleInfo, 6) # NobleLevel
            Write32(pNobleInfo, 1) # NoblePoint
            Write32(pNobleInfo, 30) # NobleLeftDays
            UpdateLen16(pTalkerInfo, pNobleInfo)
        if True: # GuildVipBaseInfo
            pGuildVipBaseInfo = pTalkerInfo.detach()
            Write16(pGuildVipBaseInfo, 0) # len
            Write8(pGuildVipBaseInfo, 6) # GuildVipLevel
            Write32(pGuildVipBaseInfo, 1) # GuildVipPoint
            UpdateLen16(pTalkerInfo, pGuildVipBaseInfo)
        Write32(pTalkerInfo, 0) # GuildId
        Write8(pTalkerInfo, 0) # HasLoverVip
        Write8(pTalkerInfo, 0) # GardenLevel
        Write8(pTalkerInfo, 0) # ConsumeVipLevel
        if True: # EmperorInfo
            pEmperorInfo = pTalkerInfo.detach()
            Write16(pEmperorInfo, 0) # len
            Write8(pEmperorInfo, 0) # EmperorLevel
            Write32(pEmperorInfo, 0) # EmperorPoint
            Write32(pEmperorInfo, 0) # EmperorLeftDays
            Write8(pEmperorInfo, 0) # EmperorGrowRate
            UpdateLen16(pTalkerInfo, pEmperorInfo)
        Write32(pTalkerInfo, 0) # HelperLev
        UpdateLen16(p, pTalkerInfo)
    Write8(p, 0) # ReserveFlag
    Write32(p, 0) # ReserveData
    SetBytes(p.data, p.start, bytes(18), 0, 18)
    p.start += 18
    Write8(p, 0) # transBufType
    Write16(p, 0) # transBufLen
    Write8(p, 0) # MsgSource
    Write16(p, 0) # DstNickNameLength
    Write32(p, 0) # Seq
    SendToClient(Client, 505, buf, p-buf, Client.RoomID, FE.ROOM, Client.ConnID, MsgType.Notify)
    
from process_cmd import process_cmd_from_client

def RequestTalk(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    Type = Read8(Body)
    ClientUseFlag = Read8(Body)
    DestPlayerUin = Read32(Body)
    ContentLength = Read16(Body)
    Content = ReadStringWithFixedLength(Body, ContentLength)
    if Content.startswith("SOS-"):
        item = Content[4:]
        if item == "泡泡":
            ResponseGetProp(Client, 2, 0)
        elif item == "导弹":
            ResponseGetProp(Client, 3, 0)
        elif item == "乌龟":
            ResponseGetProp(Client, 4, 0)
        elif item == "恶魔":
            ResponseGetProp(Client, 6, 0)
        elif item == "墨汁":
            ResponseGetProp(Client, 44, 0)
        return
    if Content.startswith(CONST.CMD_PREFIX):
        cmd = Content[len(CONST.CMD_PREFIX):]
        ret = process_cmd_from_client(cmd, Client)
        logger.info(f"[RequestTalk] cmd={cmd}, ret={ret}]")
        NotifyTalk(Client, 10000, "系统消息", Type, ClientUseFlag, 0, ret)

    BugletType = Read8(Body)
    ReserveFlag = Read8(Body)
    ResponseTalk(Client, Type, ClientUseFlag, DestPlayerUin)
    
    # NotifyTalk
    for RoomClient in Client.YieldAllClientsInSameRoom():
        NotifyTalk(RoomClient, Client.Uin, Client.Nick, Type, ClientUseFlag, DestPlayerUin, Content)

    

def RequestChangeGender(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    NewGender = Read8(Body)
    if get_Player().SetGender(Client.Uin, NewGender):
        ResponseChangeGender(Client, NewGender, 0)
     
def RequestToImplement(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    return

MsgID2Func:dict = {
    1: MyRequestGetUin,
    2: MyRequestRegister,
    90: RequestGetWorldInfo,
    91: RequestGetChatRoomList,
    100: RequestLogin, 
    101: RequestLogout, 
    102: RequestGetRoomList,
    103: RequestCreateRoom,
    104: RequestEnterRoom,
    105: RequestLeaveRoom,
    107: RequestToImplement, # RequestChangeSeatState
    109: RequestChangeReadyState, # RequestChangeReadyState
    110: RequestStartGame,
    111: RequestTalk, # RequestTalk
    112: RequestHello, 
    119: RequestReportDrift,
    120: RequestPrepareReady,
    121: RequestChangeMap,
    122: RequestFindPlayerByQQ,
    123: RequestReportCurrentInfo,
    124: RequestGetProp,
    126: RequestPropEffectResult,  
    127: RequestChangeAimState, 
    128: RequestChangeTeam, 
    130: RequestChangeItemStatus,
    135: RequestGetTaskList, 
    145: RequestGetLicenseInfo, 
    151: RequestSwitchInterface, 
    152: RequestGetSystemTaskList,
    153: RequestTransferByTCP,
    162: RequestChangeGender,
    163: RequestNewGetFriendList,
    165: RequestUseProp2,
    169: RequestToImplement, # RequestOutDoorEggInfo
    187: RequestGetRandomTask, 
    271: RequestKartRefitInfo,
    301: RequestExchangeLoverMode,
    316: RequestSaveShapeRefit,
    350: RequestToImplement, # RequestHeroPos
    351: RequestHeroMove,
    352: RequestEnterOutdoor,
    353: RequestLeaveOutdoor,
    355: RequestToImplement, # ResponseHeroDoAction
    357: RequestRegister2,
    363: RequestGetMaster, 
    373: RequestGetAchieveList, 
    317: RequestGetShapeRefitCfg, 
    424: RequestLeaveGame,
    431: RequestToImplement, # RequestGetPkableNPCInfo
    440: RequestGetPetSkillList, 
    909: RequestReportSkillStoneTakeEffect,
    944: RequestFizzInfo,
    1401: RequestC2GSign3Operate, 
    1500: RequestStartShadowChallenge, # RequestStartShadowChallenge
    1501: RequestEndShadowChallenge,
    10501: RequestFishLogin,
    11342: RequestToImplement, # RequestC2LMOverSuperJet
    11451: RequestGetPlayerEventCfg, 
    11452: RequestGetPlayerEvent, 
    13710: RequestC2SGetKartAltasConfig,
    16055: RequestGetPrivilegeIntroInfo, # RequestGetPrivilegeIntroInfo
    21111: RequestSecondGetKartRefitLimitCfg, # RequestSecondGetKartRefitLimitCfg
    24029: RequestGetActivityCenterInfo, 
    24201: RequestGetItemTimeLimtCfg,
    24391: RequestWeRelayCommonCfg, 
    24465: RequestPreGetCommonBoxAward, 
    24721: RequestSSCOpenStatus, 
    28412: RequestDoBagItemShowOperate, 
    28421: RequestReplayOperate,
}

IgnoredMsgID:set[int]={10, 11, 12, 13, 
                       106, # RequestQuickEnterRoom
                       131, # RequestChangeIdentity
                       179, # RequestChangeUdpState
                       231, # ResponseC2GGetSpecialTaskData
                       233, # ResponseC2GGetSignInfo
                       241, # RequestReportClickStream
                       275, # RequestChangeRecommandStatus
                       319, # RequestShapeLegendOperate
                       362, # RequestGetSpecialBroadcasts
                       414, # RequestChangeMailSomeFlag
                       415, # RequestGetFavoriteTask
                       420, # RequestGetWareHouseStatus
                       452, # RequestGetShoppingCarItemList
                       462, # RequestTransferMapInfo
                       538, # AckAntiBot
                       562, # AckDpData
                       636, # RequestGameLogicCommonReport
                       911, # RequestReportSkillStoneTakeEffectForStatistic
                       934, # RequestReportFeedBack
                       1400, # RequestWorldOnlineInfo
                       1702, # RequestGetGameBaseRecordList
                       10510, # RequestFishGetStorageInfo
                       10929, # RequestGetBattleModeCarSkillInfoList
                       10933, # RequestC2GGetBattleModeConfig
                       11216, # RequestC2GGetMapOwner
                       11356, # ResponseGetShortCutSet
                       11411, # RequestGetAuctionCfg
                       11591, # RequestC2GGetPlayerFizzStarBaseInfo
                       11596, # RequestC2GGetFizzStarActivityInfo
                       15399, # RequestReportClientAntibotData
                       20002, # RequestGetCfgFile
                       20007, # RequestGetPurchaseBroadcast
                       20031, # RequestClientReportDataMinintLog
                       20042, # RequestC2SGetTimesExperienceInfo
                       20051, # RequestReduceCouponseInfo
                       20052, # RequestCashCouponseInfo
                       20076, # RequestCanGetRecommendItemList
                       20077, # RequestPayRebateCfg
                       20086, # RequestGetMapMedalCfg
                       20097, # RequestReportCommonAction
                       21100, # RequestPurchaseLimitCfg
                       21133, # RequestGetPKPetInfo
                       21140, # RequestGetPKPetCfg
                       21143,
                       24028, # RequestReportCommonEvent [Ignore it]
                       24053, # RequestC2GGetPlayerStatus
                       24095, # RequestCarLottoryGetInfo
                       24251, # RequestQuickRPC
                       24265, # ResponseGetChattingBlackUinList
                       24426, # RequestGetPetShowInfo
                       24470, # ResponseGetMagicHouseInfo
                       24630, # RequestStealPigOpenTime
                       24501, # ResponseGetThemeHouseShowInfo
                       24766, # ResponseGetZhangFeiBoxList
                       26114, # RequestReportAntiCollisionDataBuff
                       28413, # RequestDressInfoOperate
                       28342, # ???
                       28379, # RequestGetQuickRaceTimeRandMap
                       28419, # RequestQsLabCommittalTaskInfo
                       }

def OnRecvFromClient(Client:ClientNode, MsgID:int, Body:Z_BYTES, 
BodyLen:int):
    if not Client.IsLogin:
        if MsgID > 100:
            return
    if MsgID in MsgID2Func:
        # # if MsgID == 123:
        func = MsgID2Func[MsgID]
        if True:
            if MsgID not in [153, 112, 123]:
                logger.debug(f"[OnRecvFromClient] MsgID={MsgID}, func.name=[{func.__name__}]")
        func(Client, Body, BodyLen)
    else:
        if not MsgID in IgnoredMsgID:
            logger.warn(f"[OnRecvFromClient] MsgID={MsgID} not implemented")
        pass
