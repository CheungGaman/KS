import HPSocket
from HPSocket import TcpPush
from HPSocket import helper
from HPSocket import pyhpsocket
from HPSocket.pyhpsocket import HP_Server_SetConnectionExtra
from HPSocket.HPSocketAPI import HP_Server_Disconnect
import time
import socket
from z_bytes import Z_BYTES
import encrypt_tea

from common import *
from DirectoryServer import InitDirServer
from network import IP2INT
import message
from outdoor import *
import traceback


def OnFullReceive(client:ClientNode, Data:Z_BYTES, Length):
    ProtocalHead = CSHEAD(Data)
    HeadLen = CSHEAD.size + ProtocalHead.OptLength
    if Length < HeadLen:
        HP_Server_Disconnect(client.Server, client.ConnID, True)
        raise Exception
    if ProtocalHead.OptLength:
        Body = ProtocalHead.OptData
        if ProtocalHead.Uin == CONST.ROBOT_ID:
            client.IsLogin = False
        else:
            # verify password
            client.IsLogin = True
    
    BodyLen = Length - HeadLen
    if BodyLen >= MSGHEAD.size:
        MsgHead = Data[HeadLen:]
        if ProtocalHead.BodyFlag:
            Body = bytes([0]*BodyLen)
            OutLen = encrypt_tea.decrypt(MsgHead.data, MsgHead.start, getServerInfo()["Server"]["Key"], Body, BodyLen)
            if OutLen < 0:
                logger.error(f"decrypt fail, OutLen={OutLen}")
                return
        else:
            Body = bytes(BodyLen)
            SetBytes(Body, 0, MsgHead.data, MsgHead.start, BodyLen)
            OutLen = BodyLen
        
        Body = Z_BYTES(Body)
        MsgHead = MSGHEAD(Body)
        Body = Body[MSGHEAD.size:]
        BodyLen = OutLen - MSGHEAD.size
        
        if ProtocalHead.OptLength:
            client.ServerID = MsgHead.DstID
        
        if BodyLen < 0:
            logger.error(f"BodyLen={BodyLen}, Length={Length}, MsgHead={MsgHead}, Body={Body}")
        message.OnRecvFromClient(client, MsgHead.MsgID, Body, BodyLen)
        
        

class Server(TcpPush.HP_TcpPushServer):
    EventDescription = TcpPush.HP_TcpPushServer.EventDescription
    
    @EventDescription
    def OnAccept(self, Sender:TcpPush.HP_TcpPushServer, ConnID, soClient):
        # logger.debug(f"[OnAccept] Sender={Sender}")
        ip, port = pyhpsocket.HP_Server_GetRemoteAddress(Sender=Sender, ConnID=ConnID)
        Client = ClientNode()
        Client.Server = self
        Client.Sender = Sender
        Client.ConnID = ConnID
        Client.Key = getServerInfo()["Server"]["Key"]
        Client.KartID = 10020
        
        HP_Server_SetConnectionExtra(Sender, ConnID, Client)
        return pyhpsocket.EnHandleResult.HR_OK
    
    @EventDescription
    def OnReceive(self, Sender, ConnID, Data:bytes, Length):
        # logger.debug(f"[OnReceive] Sender={Sender}")
        Client:ClientNode = pyhpsocket.HP_Server_GetConnectionExtra(Sender, ConnID, type=None)
        Data:Z_BYTES = Z_BYTES(Data)

        if Client.Buffer:
            if Client.BufferOffset < CONST.SIZE_OF_INT:
                left = min(Length, CONST.SIZE_OF_INT - Client.BufferOffset)
                SetBytes(Client.Buffer.data, Client.Buffer.start+Client.BufferOffset, Data.data, Data.start, left)
                Client.BufferOffset += left
                if Client.BufferOffset < CONST.SIZE_OF_INT:
                    logger.warn("Client.BufferOffset < CONST.SIZE_OF_INT")
                    return pyhpsocket.EnHandleResult.HR_OK
                Data = Data[left:]
                Length -= left
            need = Client.Buffer[:4].to_int(byteorder="big", signed=False)
            left = need - Client.BufferOffset
            if need > Client.BufferSize:
                if need > 65535: # 直接丢弃
                    logger.warn(f"need > 65535, disconnect the client, need={need}")
                    HP_Server_Disconnect(Client.Sender, Client.ConnID, True)
                    return pyhpsocket.EnHandleResult.HR_OK
                Client.BufferSize = need
                NewBuffer = Z_BYTES(bytes(need))
                SetBytes(Client.Buffer.data, 0, NewBuffer.data, 0, Client.BufferSize)
                Client.Buffer = NewBuffer
            if left >= 0:
                left = min(Length, left)
                SetBytes(Client.Buffer.data, Client.Buffer.start+Client.BufferOffset, Data.data, Data.start, left)
                Client.BufferOffset += left
                if Client.BufferOffset < need:
                    # logger.warn(f"Client.BufferOffset {Client.BufferOffset} < need {need}") # 正常现象，不用warning
                    return pyhpsocket.EnHandleResult.HR_OK
                Data = Data[left:]
                Length -= left
            Client.Buffer = None
            Client.BufferOffset = 0

        while Length>0:
            if Length < CONST.SIZE_OF_INT:
                need = CONST.SIZE_OF_INT
            else:
                need = Data[:4].to_int(byteorder="big", signed=False)
            if need > Length:
                # Client.Buffer = Data
                # Client.BufferOffset = Length
                Client.Buffer = Z_BYTES(bytes(need))
                Client.BufferOffset = Length
                Client.BufferSize = need
                SetBytes(Client.Buffer.data, Client.Buffer.start, Data.data, Data.start, Length)
                return pyhpsocket.EnHandleResult.HR_OK
            else:
                OnFullReceive(Client, Data, need)
                Data = Data[need:]
                Length -= need
                
        return pyhpsocket.EnHandleResult.HR_OK
        
        
    @EventDescription
    def OnHandShake(self, Sender, ConnID):
        return pyhpsocket.EnHandleResult.HR_IGNORE
    
    @EventDescription
    def OnSend(self, Sender, ConnID, Data, Length):
        return pyhpsocket.EnHandleResult.HR_OK

    @EventDescription
    def OnClose(self, Sender, ConnID, Operation, ErrorCode):
        # to implement
        return pyhpsocket.EnHandleResult.HR_OK

    @EventDescription
    def OnShutdown(self, Sender):
        # to implement
        return pyhpsocket.EnHandleResult.HR_OK
    

# def ClearAllRooms():
#     Rs = [room for room in Rooms.values()]
#     for room in Rs:
#         for Client in room.YieldAllClients():
#             if room.Status == 0:
#                 message.LeaveRoom(Client, 1)
#             else:
#                 message.LeaveRoom(Client, 0)
#     logger.info(f"[ClearAllRooms] 剩下{len(Rooms)}间房")
    
if __name__ == '__main__':
    try:
        InitChatRoom()
        InitDirServer(Name=getServerInfo()["Server"]["Name"], IP=IP2INT(getServerInfo()["Server"]["IP"]), TcpPort=getServerInfo()["Server"]["TcpPort"], UdpPort=getServerInfo()["Server"]["UdpPort"])
        server = Server()
        if server.Start(host=getServerInfo()["Server"]["Bind"]["IP"], port=getServerInfo()["Server"]["Bind"]["TcpPort"]):
            logger.info("server started")
            while True:
                cmd = input(">>>").strip()
                from process_cmd import *
                process_cmd(cmd)
    except:
        logger.error(traceback.format_exc())
        with open("output.log", "a") as f:
            f.write(traceback.format_exc())