import encrypt_tea
from my_logger import *
def Set8(data:bytes, offset:int, v:int):
    try:
        encrypt_tea.Set8(data, offset, v)
    except:
        logger.error(f"offset={offset}, v={v}")
        raise Exception
def Set16(data:bytes, offset:int, v:int):
    try:
        encrypt_tea.Set16(data, offset, v)
    except:
        logger.error(f"offset={offset}, v={v}")
        raise Exception
def Set32(data:bytes, offset:int, v:int):
    try:
        encrypt_tea.Set32(data, offset, v)
    except:
        logger.error(f"offset={offset}, v={v}")
        raise Exception
def Get8(data:bytes, offset:int)->int:
    return encrypt_tea.Get8(data, offset)
def Get16(data:bytes, offset:int)->int:
    return encrypt_tea.Get16(data, offset)
def Get32(data:bytes, offset:int)->int:
    return encrypt_tea.Get32(data, offset)
def SetBytes(dst:bytes, dst_offset:int, src:bytes, src_offset:int, length:int):
    return encrypt_tea.SetBytes(dst, dst_offset, src, src_offset, length)
def encrypt_len(original_len:int)->int:
    return encrypt_tea.encrypt_len(original_len)
def encrypt(MsgHead:bytes, MsgHeadOffset:int, MsgLen:int, Key:str, Output:bytes, OutputOffset:int)->int:
    return encrypt_tea.encrypt(MsgHead, MsgHeadOffset, MsgLen, Key, Output, OutputOffset)


class Z_BYTES:
    def __init__(self, data:bytes, start=None, stop=None):
        if not isinstance(data, bytes):
            raise TypeError
        self.data = data
        self.start = 0 if start is None else start
        self.stop = len(data) if stop is None else stop
    def __getitem__(self, index):
        length = self.stop - self.start
        if isinstance(index, int):
            if index < 0:
                index = length + index
            if index >= length:
                raise IndexError
            return self.data[index]
        elif isinstance(index, slice):
            start = index.start
            stop = index.stop
            step = index.step
            if start is None:
                start = 0
            if stop is None:
                stop = length
            if step is None:
                step = 1
            if step != 1: # 不支持步长不为1的切片
                raise TypeError
            if start < 0:
                start = length + start
            if stop < 0:
                stop = length + stop
            if start > length:
                logger.error(f"self.start={self.start}, self.stop={self.stop}, start={start}, stop={stop}")
                raise IndexError
            if stop > length:
                raise IndexError
            if start > stop:
                raise IndexError
            return Z_BYTES(self.data, start+self.start, stop+self.start)
        else:
            raise TypeError
    def __len__(self):
        return self.stop - self.start
    def __repr__(self):
        return f"{type(self).__name__}({'|'.join(str(i) for i in self.data[self.start:self.stop])}, len={self.__len__()})"
    def key_info(self):
        return f"start={self.start}, stop={self.stop}, len={self.__len__()}"

    def to_int(self, byteorder="big", signed=False)->int:
        if byteorder == "big":
            power = (self.__len__()-1)*8
            step = -1
        elif byteorder == "little":
            power = 0
            step = 1
        else:
            raise ValueError("byteorder must be either 'little' or 'big'")
        result = 0
        for index in range(self.start, self.stop):
            result += self.data[index] * (2**power)
            power += step*8
        if signed and self.data[self.start if step==-1 else self.stop-1]&0x80:
            result -= 2**(self.__len__()*8)
        return result
    
    def get_value(self)->bytes:
        return self.data[self.start:self.stop]
    
    def detach(self)->'Z_BYTES':
        return Z_BYTES(self.data, self.start, self.stop)
    
    def Read8(self)->int:
        result = Get8(self.data, self.start)
        self.start += 1
        return result
    def Read16(self)->int:
        result = Get16(self.data, self.start)
        self.start += 2
        return result
    def Read32(self)->int:
        result = Get32(self.data, self.start)
        self.start += 4
        return result
    def Write8(self, v:int):
        Set8(self.data, self.start, v)
        self.start += 1
    def Write16(self, v:int):
        Set16(self.data, self.start, v)
        self.start += 2
    def Write32(self, v:int):
        Set32(self.data, self.start, v)
        self.start += 4
        
    def __sub__(self, other):
        if isinstance(other, Z_BYTES):
            if self.data is other.data:
                return self.start - other.start
            else:
                raise NotImplementedError
        elif isinstance(other, int):
            return Z_BYTES(self.data, self.start-other, self.stop)
        else:
            raise NotImplementedError
    def __add__(self, other:int)->'Z_BYTES':
        if isinstance(other, int):
            return Z_BYTES(self.data, self.start+other, self.stop)
        else:
            raise NotImplementedError
    def __iadd__(self, other)->'Z_BYTES':
        if isinstance(other, int):
            self.start += other
            return self
        else:
            raise NotImplementedError
    def __isub__(self, other)->'Z_BYTES':
        if isinstance(other, int):
            self.start -= other
            return self
        else:
            raise NotImplementedError
        
    
        
def Write8(p:Z_BYTES, v:int):
    p.Write8(v)
def Write16(p:Z_BYTES, v:int):
    p.Write16(v)
def Write32(p:Z_BYTES, v:int):
    p.Write32(v)
def Read8(p:Z_BYTES)->int:
    return p.Read8()
def Read16(p:Z_BYTES)->int:
    return p.Read16()
def Read32(p:Z_BYTES)->int:
    return p.Read32()
def Write8Int(p:Z_BYTES, v:int):
    if v<0: v+=2**8
    p.Write8(v)
def Write16Int(p:Z_BYTES, v:int):
    if v<0: v+=2**16
    p.Write16(v)
def Write32Int(p:Z_BYTES, v:int):
    if v<0: v+=2**32
    p.Write32(v)
def Read8Int(p:Z_BYTES)->int:
    ans = p.Read8()
    if ans & 0x80: ans -= 2**8
    return ans
def Read16Int(p:Z_BYTES)->int:
    ans = p.Read16()
    if ans & 0x8000: ans -= 2**16
    return ans
def Read32Int(p:Z_BYTES)->int:
    ans = p.Read32()
    if ans & 0x80000000: ans -= 2**32
    return ans
    
def WriteStringWithLength(p:Z_BYTES, s:str, bits_of_len=16, encoding='gbk'):
    encoded_s = s.encode(encoding=encoding)
    length = len(encoded_s)
    if bits_of_len == 8:
        Write8(p, length)
    elif bits_of_len == 16:
        Write16(p, length)
    elif bits_of_len == 32:
        Write32(p, length)
    elif bits_of_len == 0:
        pass
    else:
        raise Exception
    SetBytes(p.data, p.start, encoded_s, 0, length)
    p.start += length
    
def WriteStringWithFixedLength(p:Z_BYTES, s:str, length:int, encoding='gbk')->Z_BYTES:
    encoded_s = (s+"\0").encode(encoding=encoding)
    if len(encoded_s) > length:
        encoded_s = encoded_s[:length]
    SetBytes(p.data, p.start, encoded_s, 0, len(encoded_s))
    p.start += length
    return p

def ReadStringWithFixedLength(p:Z_BYTES, length:int, encoding='gbk')->str:
    b:bytes = p.data[p.start:p.start+length]
    p.start += length
    return b.decode(encoding=encoding)
    
def UpdateLen16(MainBuf: Z_BYTES, RunBuf: Z_BYTES)->Z_BYTES:
    # assert MainBuf.data == RunBuf.data
    Write16(MainBuf, RunBuf - MainBuf)
    MainBuf.start = RunBuf.start
    MainBuf.stop = RunBuf.stop
    return MainBuf
    
    
    
STATIC_BUF = bytes(819200)

def get_buf():
    return Z_BYTES(STATIC_BUF)

if __name__ == '__main__':
    b = b'\x88t'
    zb = Z_BYTES(b)
    print(zb)
    print(int.from_bytes(b, "big", signed=True))
    print(int.from_bytes(b, "little", signed=True))
    print(zb.to_int("big", signed=True))
    print(zb.to_int("little", signed=True))