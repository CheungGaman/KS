from magic import *
from common import *

def NotifyRaceShow(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write32(p, 0) # RaceShowTime
    Write8(p, 0) # HasFBInfo
    Write8(p, 0) # WinTeamID
    Write32(p, 0) # EventID
    Write32(p, 0) # ParaNum
    SendToClient(Client, 515, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Notify)


def NotifyRaceOver(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write8(p, 1) # CurrentPlayerNum
    if True: # RaceScore
        pRaceScore = p.detach()
        Write16(pRaceScore, 0) # len
        Write32(pRaceScore, Client.Uin) # Uin
        Write32(pRaceScore, Client.FinishTime) # FinTime
        Write32(pRaceScore, 0) # TP
        Write32(pRaceScore, 0) # MoneyInc
        Write32(pRaceScore, 30) # TotalMoney
        Write32(pRaceScore, 0) # ExpInc
        Write32(pRaceScore, 1) # TotalExp
        Write8(pRaceScore, 0) # AwardNum
        # m_iSpecialAward[]
        Write32(pRaceScore, 0) # TeamWorkExpInc
        Write32(pRaceScore, 0) # PropPoint
        Write32(pRaceScore, 0) # PropPointAddExp
        Write32(pRaceScore, 0) # LuckyMatchPointInc
        Write32(pRaceScore, 0) # LuckyMatchPointTotal
        Write32(pRaceScore, 0) # LuckyMatchScoreInc
        Write32(pRaceScore, 0) # LuckyMatchScoreTotal
        Write32(pRaceScore, 0) # LuckMoneyInc
        Write32(pRaceScore, 0) # LuckMoneyTotal
        Write32(pRaceScore, 0) # GuildScoreInc
        Write8(pRaceScore, 0) # CrazyPropAchieveNum
        # m_aiCrazyPropAchieve[]
        Write32(pRaceScore, 0) # IncWlMatchScore
        Write32(pRaceScore, 0) # IncWlDegree
        Write8(pRaceScore, 0) # IncItemNumByWl
        Write32(pRaceScore, 0) # WlMutiplyCard
        Write32(pRaceScore, 0) # SkateCoinInc
        Write32(pRaceScore, 0) # SkateCoinTotal
        Write32(pRaceScore, 0) # SkateCoinHistoryTotal
        Write32(pRaceScore, 0) # TotalCoupons
        Write8(pRaceScore, 0) # ChallengeCheer
        Write32(pRaceScore, 0) # LoveValue
        Write32(pRaceScore, 0) # SkateCoinEmperorBonus
        Write32(pRaceScore, 0) # DetailRecordID
        Write8(pRaceScore, 0) # HasGangsterResult
        if True: # EquippedActiveKartInfo
            pEquippedActiveKartInfo = pRaceScore.detach()
            Write16(pEquippedActiveKartInfo, 0) # len
            Write8(pEquippedActiveKartInfo, 0) # HaveActiveInfo
            Write32(pEquippedActiveKartInfo, 0) # KartID
            Write32(pEquippedActiveKartInfo, 0) # ActiveLevel
            UpdateLen16(pRaceScore, pEquippedActiveKartInfo)
        Write8(pRaceScore, 0) # HasWeRelayRaceOverInfo
        Write8(pRaceScore, 0) # HaveSkatePropRaceInfo
        Write8(pRaceScore, 0) # IsNewBox
        Write8(pRaceScore, 0) # HaveArrestScoreInfo
        Write8(pRaceScore, 0) # HasRankedMatchInfo
        Write8(pRaceScore, 0) # HaveCrazyChaseScoreInfo
        Write8(pRaceScore, 0) # TeamID
        Write8(pRaceScore, 0) # HasRankedMatchArenaInfo
        Write32(pRaceScore, 0) # DistanceToEnd
        Write8(pRaceScore, 0) # ShortDistancWinPoint
        Write8(pRaceScore, 0) # Status
        Write8(pRaceScore, 0) # HaveRankedMatchSpeedKingInfo
        Write8(pRaceScore, 0) # ProfessionLicenseAwardNum
        if True: # RaceResult
            pRaceResult = pRaceScore.detach()
            Write16(pRaceResult, 0) # len
            Write8(pRaceResult, 0) # PLExpPowerValid
            Write8(pRaceResult, 0) # PLHonorPowerValid
            Write8(pRaceResult, 0) # ExpMultiNum
            Write8(pRaceResult, 0) # HonorMultiNum
            UpdateLen16(pRaceScore, pRaceResult)
        Write8(pRaceScore, 0) # HaveRankedMatchExtraInfo
        Write8(pRaceScore, 0) # HasYuLeJiaNianHuaComputeData
        UpdateLen16(p, pRaceScore)
    Write8(p, 0) # WinTeamID
    Write32(p, 0) # WinType
    Write32(p, 0) # AwardTime
    Write8(p, 0) # LuckyMatchResult
    Write8(p, 0) # LuckyMatchType
    Write8(p, 1) # PlayerNumber
    if True: # HideTaskResult
        pHideTaskResult = p.detach()
        Write16(pHideTaskResult, 0) # len
        Write32(pHideTaskResult, Client.Uin) # Uin
        Write32(pHideTaskResult, 0) # TaskId
        Write8(pHideTaskResult, 0) # HideTaskFinishResult
        UpdateLen16(p, pHideTaskResult)
    Write8(p, 0) # HasLadderMatchResult
    Write8(p, 0) # NeedFreshTutor
    Write8(p, 0) # hasMedalGameInfo
    # m_medalGameInfo[].m_curMedal
    Write8(p, 0) # KickOffPlayerNumber
    Write8(p, 0) # EliminatedRacerNum
    Write8(p, 0) # TeamNum
    Write8(p, 0) # NPCRacerNum
    Write8(p, 0) # hasGameFrameInfo
    Write8(p, 0) # hasDesperateEscapeTrophyInfo
    Write8(p, 0) # HasGameStageInfo
    SendToClient(Client, 513, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Notify)

def NotifyGameOver(Client:ClientNode, LeaveGameType:int, ParaList:list[int]):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, 0) # StageIndex
    Write8(p, 0) # ReturnHall
    Write8(p, 0) # WaitEnterRoom
    Write16(p, LeaveGameType) # LeaveGameType
    ParaNum = len(ParaList)
    Write8(p, ParaNum) # ParaNum
    for i in range(ParaNum):
        # m_aiParaList[]
        Write32(p, ParaList[i])
    if not Client.Room:
        logger.warn(f"[NotifyGameOver] Client.Room is None")
        return
    if Client.Room.RoomOwnerID == Client.ConnID:
        Client.Room.Status = 1
    SendToClient(Client, 514, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Notify)

def CreateRoomTimer(Room:RoomNode, Period:int, Func:callable):
    def f():
        time.sleep(Period/1000)
        Func(Room)
    threading.Thread(target=f, daemon=True).start()
    

def OnCountDown3(Room:RoomNode):
    for RoomClient in Room.YieldAllClients():
        NotifyGameOver(RoomClient,0,[])
def OnCountDown2(Room:RoomNode):
    for RoomClient in Room.YieldAllClients():
        NotifyRaceOver(RoomClient)
    CreateRoomTimer(Room, GetSelfDefinedConfig().AwardPeriod, OnCountDown3)
def OnCountDown(Room:RoomNode):
    for RoomClient in Room.YieldAllClients():
        NotifyRaceShow(RoomClient)
    CreateRoomTimer(Room, GetSelfDefinedConfig().Over2AwardDelay, OnCountDown2)

def OnBegin(Room:RoomNode):
    for RoomClient in Room.YieldAllClients():
        NotifyRaceBegin(RoomClient)

    
def NotifyCountDown(Client:ClientNode, WinnerUin:int, WinnerNewRecord:bool, FinTime:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, GetSelfDefinedConfig().CountDownAfterFirstFinish)
    Write32(p, WinnerUin)
    Write8(p, int(WinnerNewRecord))
    Write32(p, FinTime)
    SendToClient(Client, 512, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Notify)

def RequestReportCurrentInfo(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)

    CurrentState = Read32(Body)

    # m_aiCurrentPosition[3]
    Read32(Body)
    Read32(Body)
    Read32(Body)

    IsFinish = False
    PassedCheckPointNum = Read8(Body)
    for i in range(PassedCheckPointNum):
        PassedCheckPointID = Read16(Body)
        if Client.Loop:
            if Client.EndCheckPoint != 0 and PassedCheckPointID > Client.EndCheckPoint: # 大于终点的则可能在走近道
                continue
            if PassedCheckPointID == 0 and Client.PassedCheckPoint > 4:
                Client.Round+=1
                if Client.Round >= Client.TotalRound:
                    IsFinish = True
            elif Client.PassedCheckPoint == 0 and PassedCheckPointID > 4:
                Client.Round-=1
        else:
            if PassedCheckPointID == Client.EndCheckPoint:
                Client.Round+=1
                if Client.Round >= Client.TotalRound:
                    IsFinish = True
        Client.PassedCheckPoint = PassedCheckPointID
    LapTime = Read32(Body)
    AccVerifyDataNum = Read8(Body)
    for i in range(AccVerifyDataNum):
        length = Get16(Body.data, Body.start)
        Body.start += length
    MsgSequence = Read8(Body)
    ExtraDataNum = Read8(Body)
    for i in range(ExtraDataNum):
        length = Get16(Body.data, Body.start)
        Body.start += length
    N2OChangeEventNum = Read8(Body)
    for i in range(N2OChangeEventNum):
        length = Get16(Body.data, Body.start)
        Body.start += length

    Flag = Read32(Body)
    HasCrashModeData = Read8(Body)
    if HasCrashModeData:
        Body.start += Get16(Body.data, Body.start)

    HasPointChallengeData = Read8(Body)
    if HasPointChallengeData:
        Body.start += Get16(Body.data, Body.start)

    SkateCoinNum = Read32(Body)
    for i in range(SkateCoinNum):
        Body.start += Get16(Body.data, Body.start)

    SkateComboAwardCoinNum = Read32(Body)
    for i in range(SkateComboAwardCoinNum):
        Body.start += Get16(Body.data, Body.start)

    SkateDoubleJumpCount = Read32(Body)
    CurrMapID = Read32(Body)
    HasGameDetailRecord = Read8(Body)
    if HasGameDetailRecord:
        Body.start += Get16(Body.data, Body.start)

    CurrentInfoFlag = Read8(Body)
    TotalAccelerateFuel = Read32(Body)
    DstNPCID = Read32(Body)
    DistanceToEnd = Read32(Body)
    GansterProcess = Read32(Body)
    TotalGangsterPKCount = Read32(Body)
    HasTowerChallengeData = Read8(Body)
    if HasTowerChallengeData:
        Body.start += Get16(Body.data, Body.start)
    CurrentSelfRank = Read8(Body)
    CurrentTeammateRank = Read8(Body)
    Client.CurrentSelfRank = CurrentSelfRank
    HasP2PStatusData = Read8(Body)
    if HasP2PStatusData:
        Body.start += Get16(Body.data, Body.start)
    DistanceToFirstRacer = Read32(Body)
    TimerChallengeRecoverNum = Read32(Body)
    CoinNum = Read32(Body)

    ClientPlayerNum = Read8(Body)
    for i in range(ClientPlayerNum):
        Body.start += Get16(Body.data, Body.start)

    RankedMatchSpeedKingBuffer = Read8(Body)
    DistanceTotal = Read32(Body)
    IsHitRecordContion = Read8(Body)
    HangSpan = Read16(Body)
    CurRound = Read8(Body)
    IncRound = Read8(Body)

    if Client.MapCompatibilityMode:
        IsFinish = False
        if DistanceToEnd == 0:
            IsFinish = True

    if IsFinish:
        if Client.Room and Client.FinishTime == 0:
            Client.FinishTime = LapTime * 10
            NewRecord = get_Player().UpdateRecord(Client.Uin, Client.MapID, Client.FinishTime)
            # NotifyPlayerFinishRace(Client, NewRecord, Client.FinishTime)
            Room = Client.Room
            if not Room: return
            PlayerNum = 0
            for RoomClient in Room.YieldAllClients():
                PlayerNum+=1
                NotifyCountDown(RoomClient, Client.Uin, NewRecord, Client.FinishTime)
            
            if not Room.HasFirstFinished:
                Room.HasFirstFinished = True
                if PlayerNum > 1:
                    CreateRoomTimer(Room, GetSelfDefinedConfig().CountDownAfterFirstFinish, OnCountDown)
                else:
                    if NewRecord:
                        CreateRoomTimer(Room, 3000, OnCountDown)
                    else:
                        CreateRoomTimer(Room, 1, OnCountDown)



def NotifyRaceBegin(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write32(p, GetSelfDefinedConfig().CountDownTime) # CountDownTime
    Write16(p, 0) # DelayTime
    Write8(p, 0) # StageIndex
    Write32(p, 0) # RaceCountDownTime
    Write32(p, 0) # RaceCountDownDis
    Write8(p, GetSelfDefinedConfig().UseNewCountDownTime) # UseNewCountDownTime
    Write32(p, GetSelfDefinedConfig().NewCountDownTime) # NewCountDownTime
    Write32(p, 0) # ServerSecond
    Write32(p, 0) # ServerMicroSecond
    SendToClient(Client, 511, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Notify) 


def RequestPrepareReady(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uint = Read32(Body)
    Time = Read32(Body)
    if Client.Room:
        Client.MapLoadOver = True
        AllReady = True
        ClientCount = 0
        for RoomClient in Client.Room.YieldAllClients():
            if RoomClient.MapLoadOver==False:
                AllReady = False
                ClientCount += 1
                break
        if AllReady:
            StartDancePeriod = GetSelfDefinedConfig().StartDancePeriod
            if ClientCount == 1: StartDancePeriod = 0
            CreateRoomTimer(Client.Room, StartDancePeriod, OnBegin)

        

def NotifyOtherKartStoneInfo(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()
    kart = get_Karts().GetKart(Client.KartID)
    stones:list[TypeStone] = kart.Stone
    Write32(p, 1) # OtherStoneKartNum
    if True: # KartStoneGrooveInfo
        paKartStoneGrooveInfo = p.detach()
        Write16(paKartStoneGrooveInfo, 0) # len
        Write32(paKartStoneGrooveInfo, Client.Uin) # Uin
        if True: # KartStoneGrooveInfo
            pKartStoneGrooveInfo = paKartStoneGrooveInfo.detach()
            Write16(pKartStoneGrooveInfo, 0) # len
            Write32(pKartStoneGrooveInfo, Client.KartID) # KartID
            Write32(pKartStoneGrooveInfo, len(stones)) # StoneNum
            for stone in stones:
                pStoneGrooveInfo = pKartStoneGrooveInfo.detach()
                Write16(pStoneGrooveInfo, 0) # len
                Write32(pStoneGrooveInfo, stone.StoneUseOccaType)
                Write32(pStoneGrooveInfo, stone.SkillStoneID)
                UpdateLen16(pKartStoneGrooveInfo, pStoneGrooveInfo)
            UpdateLen16(paKartStoneGrooveInfo, pKartStoneGrooveInfo)
        UpdateLen16(p, paKartStoneGrooveInfo)
    SendToClient(Client, 907, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifyKartPhysParam(Client:ClientNode, Players:list[ClientNode]):
    buf = get_buf()
    p = buf.detach()
    if not Players: Players = [Client]
    Write16(p, len(Players))
    for player in Players:
        ConvertedSuitID = get_Player().GetConvertedSuit(player.Uin, player.KartID)
        WriteKartPhysParam(p, player.Uin, ConvertedSuitID)
    Write16(p, GetSelfDefinedConfig().Car_SuperN2ORate)
    SendToClient(Client, 551, buf, p-buf, Client.GameID, FE.PLAYER, Client.ConnID, MsgType.Notify)

    
def NotifyGameBegin(Client: ClientNode, Players: list[ClientNode]):
    buf = get_buf()
    p = buf.detach()
    Write32(p, GetSelfDefinedConfig().Car_NormalLoadTime)
    Write32(p, Client.MapID)
    WriteStringWithFixedLength(p, "", 32)
    Write32(p, Client.GameID)
    Write32(p, int(time.time()))
    Write8(p, len(Players))
    aRaceTrackOrders = p.detach()
    for i in range(CONST.MAX_MUCH_SEATNUMINROOM):
        Write32(p, 0)
    index = (2,3,1,4,0,5)
    for i,player in enumerate(Players):
        Set32(aRaceTrackOrders.data, aRaceTrackOrders.start + index[i]*4, player.Uin)

    Write16(p, Client.TotalRound) # TotalMapRound
    Write32(p, 0) # PropUpdateInterval
    Write32Int(p, get_Player().GetRecord(Client.Uin, Client.MapID)) # Record
    Write8(p, 0) # NianShouTypeNum
    Write8(p, len(Players)) # SyncCarNum
    for player in Players: # SyncCar
        pSyncCar = p.detach()
        Write16(pSyncCar, 0) # len
        Write32(pSyncCar, player.Uin) # PlayerUin
        if player != Client:
            ConvertedSuidID = get_Player().GetConvertedSuit(player.Uin, player.KartID)
            Write32(pSyncCar, ConvertedSuidID)
        else:
            Write32(pSyncCar, player.KartID)
        Write8(pSyncCar, 0) # HasStoneInfo
        UpdateLen16(p, pSyncCar)
    Write8(p, 0) # ReportDataFlag
    Write8(p, 0) # CheckDataNum
    Write8(p, 0) # P2PMode
    Write8(p, 0) # TcpFrequence
    Write8(p, 50) # MultiInfoLen
    WriteStringWithFixedLength(p, "", 50)
    Write8(p, 0) # FeedBackEnabled
    Write8(p, 0) # SpeedSectionNum
    Write8(p, 0) # NormalSpeedSectionNum
    Write8(p, 0) # MemCheckInfoNum
    Write8(p, GetSelfDefinedConfig().Car_ExtraInfoInterval) # ExtraInfoInterval
    Write16Int(p, -1) # OffsetThreshold
    Write32(p, 200) # SpeedRatioThreshold1
    Write32(p, 200) # SpeedRatioThreshold2
    Write32(p, 0) # HideTaskId
    Write8(p, 0) # HideTaskType
    Write32(p, 0) # HideTaskParam1
    Write8(p, 0) # ForceReportCPNum
    Write8(p, 0) # CliReserveFlag

    EnableAntiDriftCheat = GetSelfDefinedConfig().Car_EnableAntiDriftCheat # 反卡漂
    Write8(p, EnableAntiDriftCheat) # EnableAntiDriftCheat
    if EnableAntiDriftCheat: # AntiDriftCheatPara
        pAntiDriftCheatPara = p.detach()
        Write16(pAntiDriftCheatPara, 0) # len
        Write32(pAntiDriftCheatPara, 0) # MaxDriftHistoryTime
        Write32(pAntiDriftCheatPara, 0) # MinTimeInterval
        Write32(pAntiDriftCheatPara, 0) # MaxTimeInterval
        Write32(pAntiDriftCheatPara, 220) # NormalThreshold
        Write32(pAntiDriftCheatPara, 15) # JetThreshold
        Write32(pAntiDriftCheatPara, 0) # JetInterval
        Write32(pAntiDriftCheatPara, 0) # OneSideSlidingInterval
        UpdateLen16(p, pAntiDriftCheatPara)
    Write8(p, 0) # HasCrashModePara
    Write32(p, 0) # FizzStarTaskId
    Write8(p, 0) # FizzStarTaskType
    Write32(p, 0) # FizzStarTaskParam1
    Write32(p, 0) # LDMRecordID
    Write32(p, 0) # GameSeq
    Write8(p, 1) # PlayerNums
    if True: # GameBeginPlayerInfo
        pGameBeginPlayerInfo = p.detach()
        Write16(pGameBeginPlayerInfo, 0) # len
        Write32(pGameBeginPlayerInfo, Client.Uin) # Uin
        Write32(pGameBeginPlayerInfo, 0) # ChumCircleID
        Write8(pGameBeginPlayerInfo, 0) # SkillNums
        Write32(pGameBeginPlayerInfo, 0) # WorldEscapeTaskID
        if True: # ProfessionLicenseInfo
            pProfessionLicenseInfo = pGameBeginPlayerInfo.detach()
            Write16(pProfessionLicenseInfo, 0) # len
            Write8(pProfessionLicenseInfo, GetSelfDefinedConfig().Car_ProfessionLicenseBigLevel) # BigLevel
            Write8(pProfessionLicenseInfo, GetSelfDefinedConfig().Car_ProfessionLicenseSmallLevel) # SmallLevel
            UpdateLen16(pGameBeginPlayerInfo, pProfessionLicenseInfo)
        Write8(pGameBeginPlayerInfo, 0) # ParaNum
        Write32(pGameBeginPlayerInfo, 0) # StarsFightingStar
        Write8(pGameBeginPlayerInfo, 0) # ParaNum
        UpdateLen16(p, pGameBeginPlayerInfo)
    Write8(p, 0) # PlayeCheerNums
    Write8(p, 0) # MapNum
    Write32(p, 0) # SpecialMapId
    Write8(p, 0) # NPCNum
    Write8(p, 0) # MapNum
   
    for i in range(CONST.MAXNPCNUMINROOM):
        Write32(p, 0)
    Write8(p, 0) # PlayerNum
    Write8(p, 0) # HasTowerInfo
    Write8(p, 0) # HasWeRelayGameBeginInfo
    Write8(p, 0) # ChangeCar
    Write32(p, 12345678) # GameSeqIDHigh
    Write32(p, 87654321) # GameSeqIDLow
    Write32(p, 0) # KubiBigCoinReplaceItem
    Write32(p, 0) # TimerChallengeJumpLevel
    Write8(p, 0) # ShadowRunDelay
    Write16(p, 0) # ShadowCatchUpContinuesTime
    Write8(p, 0) # ArrestPlayerNums
    Write16(p, 0) # MonitorCheckPointBegin
    Write16(p, 0) # MonitorCheckPointEnd
    Write8(p, 0) # MonitorLapCnt
    Write8(p, 0) # GameType
    Write8(p, 0) # PointID
    Write16(p, 0) # BaseMode
    Write16(p, 0) # SubMode
    Write8(p, 0) # GameType
    Write16(p, 0) # ReportPosSpan
    Write16(p, 0) # PropID
    Write32(p, 0) # PropIndex
    Write16(p, 0) # PropNum
    Write8(p, 0) # BaseGameModeEx
    Write8(p, 0) # ParaNum
    Write8(p, 0) # MapCheckpointFileIndex
    Write8(p, 0) # HasTimerChallenge2ndGameBeginInfo
    Write8(p, 0) # HasGameStageInfo
    Write8(p, 0) # CarCollectInfoNum
    Write16(p, GetSelfDefinedConfig().Car_ReportAntiCollisionDataTime) # ReportAntiCollisionDataTime
    Write32(p, 0) # Duration
    Write32(p, 0) # BeginCDTime
    Write32(p, 0) # PropInteval
    Write32(p, 0) # MoveFreq
    Write8(p, 0) # HaveGameLogicTask
    Write16(p, 0) # RankedMatchBegainTipInfoType
    Write8(p, 0) # BegainTipLen
    Write8(p, 0) # BuffBum
    Write8(p, 0) # MapChallengeInfoNum
    Write8(p, 0) # IsChangeCar
    Write8(p, 0) # AnonymousMode
    Write8(p, 0) # IsTimeShuttleGen
    Write8(p, 0) # HalloweenDdventureInfoNum
    Write8(p, 0) # MaxPropEffectNum
    Write8(p, 0) # IsCrossNoCollision
    Write8(p, 0) # RecordCheckCondNum
    Write32(p, 0) # GameBeginSwitchFlag
    Write8(p, 0) # TriggerVeggieDogTask
    Write8(p, 0) # HasQSpeedCrystalInfo
    SendToClient(Client, 509, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Notify)

def NotifyReceiveProp(Client:ClientNode, PropID:int, SrcUin:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, SrcUin) # ID
    Write16(p, PropID) # PropID
    Write32(p, Client.Uin) # DstUin
    Write32(p, 0) # PropPosition[]
    Write32(p, 0) # PropPosition[]
    Write32(p, 0) # PropPosition[]
    Write32(p, 0) # PropIndex
    Write16(p, 0) # NewID
    Write32(p, 0) # ItemID
    Write32Int(p, -1) # StoneSkillType
    Write32(p, 0) # LapTime
    Write8(p, 0) # DstUinNum
    Write8(p, 0) # PropUseMode
    Write8(p, 0) # QueryUinNum
    Write8(p, 0) # DstType
    Write8(p, 0) # Position
    Write8(p, 0) # ParaNum
    Write8(p, 0) # Status
    Write8(p, 255) # PropPosIdx
    Write8(p, 255) # PropSecType
    Write8(p, 0) # PassedCheckPointNum
    Write16(p, 0) # SubPropID
    Write8(p, 0) # OtherPropPosNum
    SendToClient(Client, 517, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)


def RequestStartGame(Client: ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    Room = Client.Room
    if not Room: return
    if Room.Status == 0: return # 已经开始了
    if Room.BaseGameMode==4: # 舞蹈模式
        raise NotImplementedError
    Map = getMap().GetMap(Room.MapID)
    Room.StartGame()
    logger.info(f"[开始游戏] 房主: {Client.Nick}, RoomID: {Room.ID}, MapID: {Room.MapID}, GameCount: {Room.GameCount}")
    CurrentPlayers = list(Room.YieldAllClients())
    logger.info(f"[RequestStartGame] Client={Client}, CurrentPlayers={CurrentPlayers}")
    for RoomClient in CurrentPlayers:
        RoomClient.GameID = 2
        RoomClient.MapLoadOver = False
        if (Map.round == 1 and Map.end == 0):
            RoomClient.MapCompatibilityMode = True
            RoomClient.EndCheckPoint = 0
            RoomClient.TotalRound = 1
            RoomClient.Loop = False
        else:
            RoomClient.MapCompatibilityMode = True
            RoomClient.EndCheckPoint = Map.end
            RoomClient.TotalRound = Map.round
            RoomClient.Loop = Map.loop
        RoomClient.MapID = Map.id
        RoomClient.StartGame()
        NotifyGameBegin(RoomClient, CurrentPlayers)
        NotifyKartPhysParam(RoomClient, CurrentPlayers)
        NotifyOtherKartStoneInfo(RoomClient)
    OnStartGame(Client)    
        

def ResponseLeaveGame(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Client.Uin)
    Write16(p, 0) 
    SendToClient(Client, 424, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Response)

def RequestLeaveGame(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    if Client.Room:
        Client.RoomName = Client.Room.Name
    NotifyGameOver(Client, 1, [Client.MapID])
    ResponseLeaveGame(Client)

def NotifyTransferByTCP(Client:ClientNode, SrcUin:int, SrcPlayerID:int, Seq:int, Buff:Z_BYTES, BuffLen:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, SrcUin)
    Write16(p, SrcPlayerID)
    Write8(p, 0) # Ver
    Write32(p, Seq)
    Write16(p, BuffLen)
    SetBytes(p.data, p.start, Buff.data, Buff.start, BuffLen)
    p.start += BuffLen
    SendToClient(Client, 560, buf, p-buf, SrcPlayerID, FE.PLAYER, Client.ConnID, MsgType.Notify)
    
def RequestTransferByTCP(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    Ver = Read8(Body)
    Seq = Read32(Body)
    DstNum = Read8(Body)
    class DstInfo: 
        def __init__(self, PlayerID:int, Uin:int):
            self.PlayerID = PlayerID
            self.Uin = Uin
    aDstInfo:list[DstInfo] = [DstInfo(0,0) for _ in range(DstNum)]
    for i in range(DstNum):
        pDstInfo = Body.detach()
        len = Read16(pDstInfo)
        aDstInfo[i].PlayerID = Read16(pDstInfo)
        aDstInfo[i].Uin = Read32(pDstInfo)
        Body.start += len
    BuffLen = Read16(Body)
    Room = Client.Room
    if not Room: return
    # values = []
    # for i in range(Body.start, Body.start+BuffLen):
    #     value = Get8(Body.data, i)
    #     values.append(f"{i},{value}")
    # logger.info(f"[RequestTransferByTCP] Buff: {'|'.join(values)}")

    for RoomClient in Room.YieldAllClients():
        NotifyTransferByTCP(RoomClient, Client.Uin, Client.ConnID, Seq, Body, BuffLen)

def NotifyOtherSkillStoneTakeEffect(Client:ClientNode, Uin:int, StoneID:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Uin)
    Write32(p, StoneID)
    SendToClient(Client, 910, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)


def RequestReportSkillStoneTakeEffect(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    StoneID = Read32(Body)
    Room = Client.Room
    if not Room: return
    for OtherClient in Room.YieldClientExcept(Client):
        NotifyOtherSkillStoneTakeEffect(OtherClient, Uin, StoneID)
        
        
def NotifyAddPropBySkillStone(Client:ClientNode, StoneSkillType:int, PropID:int, PropIndex:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, StoneSkillType)
    Write16(p, PropID)
    Write32(p, PropIndex)
    SendToClient(Client, 908, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Notify)
    

def RequestChangeAimState(Client:ClientNode, Body:Z_BYTES, BodyLen: int):
    Uin = Read32(Body) 
    Time = Read32(Body)
    DstUin = Read32(Body)
    AimState = Read8(Body)
    DstType = Read8(Body)
    logger.info(f"[RequestChangeAimStatus] Client={Client}, Uin={Uin}, DstUin={DstUin}, AimState={AimState}, DstType={DstType}")
    
    # NotifyChangeAimState
    buf = get_buf()
    p = buf.detach()
    Write32(p, Uin)
    Write32(p, DstUin)
    Write8(p, AimState)
    Write8(p, DstType)
    TargetClient = GetClient(DstUin)
    if TargetClient:
        SendToClient(TargetClient, 519, buf, p-buf, TargetClient.ConnID, FE.PLAYER, TargetClient.ConnID, MsgType.Notify)
        

def RequestPropEffectResult(Client:ClientNode, Body:Z_BYTES, BodyLen: int):
    Uin = Read32(Body) 
    Time = Read32(Body)
    PropID = Read16(Body)
    PropIndex = Read32(Body)
    EffectResult = Read16(Body)
    ItemID = Read32(Body)
    SrcUin = Read32(Body)
    StoneSkillType = Read32(Body)
    LapTime = Read32(Body)
    RemoveOwnPropNum = Read8(Body)
    RemoveOwnPropIdx = []
    for i in range(RemoveOwnPropNum):
        RemoveOwnPropIdx.append(Read32(Body))
    DstType = Read8(Body)
    SrcUinRank = Read8(Body)
    SrcUinTeammateRank = Read8(Body)
    NPCUin = Read32(Body) 
    
    # TODO: 太复杂，重要的攻击命中提醒已经实现，其他杂七杂八的先不管
    # logger.info(f"[RequestPropEffectResult] Client={Client}, Uin={Uin}, PropID={PropID}, PropIndex={PropIndex}, EffectResult={EffectResult}, ItemID={ItemID}, SrcUin={SrcUin}, StoneSkillType={StoneSkillType}, LapTime={LapTime}, RemoveOwnPropNum={RemoveOwnPropNum}, RemoveOwnPropIdx={RemoveOwnPropIdx}, DstType={DstType}, SrcUinRank={SrcUinRank}, SrcUinTeammateRank={SrcUinTeammateRank}, NPCUin={NPCUin}")
    if EffectResult==0: # 命中
        if SrcUin != CONST.ROBOT_ID:
            TargetClient = GetClient(SrcUin)
            if TargetClient:
                # NotifyPropEffectResult
                buf = get_buf()
                p = buf.detach()
                Write32(p, Uin) 
                Write16(p, PropID) 
                Write32(p, PropIndex) 
                Write32(p, StoneSkillType) 
                Write32(p, LapTime) 
                Write8(p, RemoveOwnPropNum) 
                for v in RemoveOwnPropIdx:
                    Write32(p, v)
                Write32(p, SrcUin) 
                Write16(p, EffectResult) 
                SendToClient(TargetClient, 518, buf, p-buf, TargetClient.ConnID, FE.PLAYER, TargetClient.ConnID, MsgType.Notify)
                
                # NotifyPropPoint
                p = buf.detach()
                
                Write32(p, Client.Uin) # TODO： 自己或者队友
                Write32(p, PropID)
                Write8(p, 0)
                Write32(p, Uin) # DestUin 受害者
                Write32(p, 5) # PropPointInc
                Write32(p, 0) # PropPointDec
                Write32(p, 99) # PropPointTotal
                Write8(p, 0) # AttackNum
                Write8(p, 0) # AttackTeammateNum
                Write8(p, 0) # ProtectNum
                Write8(p, 0) # ProtectTeammatetNum
                Write8(p, 0) # ComboFlag
                SendToClient(TargetClient, 1502, buf, p-buf, TargetClient.ConnID, FE.PLAYER, TargetClient.ConnID, MsgType.Notify)

def NotifyUseProp(Client:ClientNode, Uin:int, PropID:int, DstUin:int, PropIndex:int, NewID:int, ItemID:int, StoneSkillType:int, LapTime:int, DstUins:list[int], PropUseMode:int, QueryUins:list[int], DstType:int, Position:int, Status:int, PropPosIdx:int, PropSecType:int, SubPropID:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Uin)
    Write16(p, PropID)
    Write32(p, DstUin)
    Write32(p, 0)
    Write32(p, 0)
    Write32(p, 0)
    Write32(p, PropIndex) # PropIndex
    Write16(p, NewID) # NewID
    Write32(p, ItemID) # ItemID
    Write32Int(p, StoneSkillType) # StoneSkillType
    Write32(p, LapTime) # LapTime
    Write8(p, len(DstUins)) 
    for v in DstUins:
        Write32(p, v)
    Write8(p, PropUseMode)
    Write8(p, len(QueryUins))
    for v in QueryUins:
        Write32(p, v)
    Write8(p, DstType)
    Write8(p, Position)
    Write8(p, 0) # ParamNum 
    # ParamList
    Write8(p, Status) # Status 
    Write8Int(p, PropPosIdx) # PropPosIdx
    Write8Int(p, PropSecType) # PropSecType
    Write8(p, 0) # PassedCheckPointNum
    Write16(p, SubPropID) 
    SendToClient(Client, 517, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def RequestUseProp2(Client:ClientNode, Body:Z_BYTES, BodyLen: int):
    Client.NumPropsInHand-=1
    Uin = Read32(Body) #  0 
    Time = Read32(Body) #  4
    PropID = Read16(Body) #  8
    DstUin = Read32(Body) #  10
    # m_aiCurrentPosition[3]
    PosX = Read32(Body) #  14
    PosY = Read32(Body) #  18
    PosZ = Read32(Body) #  22
    PropIndex = Read32(Body) # 26
    NewID = Read16(Body) #  30
    IsClearProp = Read8(Body) #  32
    DstType = Read8(Body) #  33
    MyUseItemID = Read32(Body) #  34
    DstUseItemID = Read32(Body) #  38
    IsConvertMode = Read8(Body) #  42  激光第一次是0，第二次是1
    StoneSkillType = Read32Int(Body) #  43
    LapTime = Read32(Body) #  47
    DstUinNum = Read8(Body) #  51
    # m_au32DstUin[]
    DstUins = []
    for i in range(DstUinNum):
        DstUins.append(Read32(Body))
    PropUseMode = Read8(Body) #  52
    QueryUinNum = Read8(Body) #  53
    # m_au32QueryUin[]
    QueryUins = []
    for i in range(QueryUinNum):
        QueryUins.append(Read32(Body))
    CurrentSelfRank = Read8(Body) #  54
    CurrentTeammateRank = Read8(Body) #  55
    Position = Read8(Body) #  56
    PropSecType = Read8Int(Body) #  57
    PropPosIdx = Read8Int(Body) #  58  激光第一次是-1， 第二次是0
    NPCUin = Read32(Body) #  59
    UsePropProtoMode = Read8(Body) #  63
    SubPropID = Read16(Body) #  64
    OtherPropPosNum = Read8(Body) #  66
    
    logger.info(f"[RequestUseProp2] Uin={Uin}, PropID={PropID}, DstUin={DstUin}, PropIndex={PropIndex}, NewID={NewID}, IsClearProp={IsClearProp}, DstType={DstType}, MyUseItemID={MyUseItemID}, DstUseItemID={DstUseItemID}, IsConvertMode={IsConvertMode}, StoneSkillType={StoneSkillType}, LapTime={LapTime}, DstUinNum={DstUinNum}, PropUseMode={PropUseMode}, QueryUinNum={QueryUinNum}, CurrentSelfRank={CurrentSelfRank}, CurrentTeammateRank={CurrentTeammateRank}, Position={Position}, PropSecType={PropSecType}, PropPosIdx={PropPosIdx}, NPCUin={NPCUin}, UsePropProtoMode={UsePropProtoMode}, SubPropID={SubPropID}, OtherPropPosNum={OtherPropPosNum}")

    
    
    
    Room = Client.Room
    if Room:
        if Room.BaseGameMode == 1: # 房间竞速赛
            if Client.N2OCountRequiredForReborn > 0:
                Client.N2OCountRequiredForReborn-=1
            else:
                import random
                if random.randint(1,1000)+GetSelfDefinedConfig().Reborn_TakeEffectProb>1000:
                    NotifyAddPropBySkillStone(Client, PropID, 1, PropIndex)
                    Client.N2OCountRequiredForReborn=GetSelfDefinedConfig().Reborn_RequiredN2OForCold
        if PropID==1 and NewID == 26: # 情侣模式给队友加气
            for TeammateClient in Room.YieldTeammates(Client):
                for Client in Room.YieldClientExcept(Client):
                    NotifyUseProp(Client, Uin, PropID, TeammateClient.Uin, PropIndex, NewID, 0, StoneSkillType, LapTime, DstUins, PropUseMode, QueryUins, DstType, Position, 0, PropPosIdx, PropSecType, SubPropID)
        elif Room.CurrentPlayerNum > 1:
            for RoomClient in Room.YieldClientExcept(Client):
                NotifyUseProp(RoomClient, Uin, PropID, DstUin, PropIndex, NewID, 0, StoneSkillType, LapTime, DstUins, PropUseMode, QueryUins, DstType, Position, 0, PropPosIdx, PropSecType, SubPropID)


def RequestGetProp(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    if Client.NumPropsInHand == 2: return
    Client.NumPropsInHand += 1
    p = Body
    Uin = Read32(p) 
    Time = Read32(p) 
    PropPositionNO = Read16(p) 
    CurrentRank = Read8(p) 
    # CurrentPosition[3]
    p.start += 12
    PreviousInterval = Read32(p)
    GetPropType = Read8(p)
    TeammateRank = Read8(p)
    PointArrayIdx = Read8(p)
    LapTime = Read32(p)
    GetPropSecType = Read8(p)
    PropPosIdx = Read8(p)
    NPCUin = Read32(p)
    ParaNum = Read8(p)
    ParaList = [Read32(p) for _ in range(ParaNum)]
    PropID = getPropModes().GetProp(Client.Room.BaseGameMode, Client.Room.SubGameMode, CurrentRank)
    PropIndex = Client.Room.AddProp(PropID)
    logger.info(f"[RequestGetProp] Client={Client}, PropPositionNO={PropPositionNO}, CurrentRank={CurrentRank}, PreviousInterval={PreviousInterval}, GetPropType={GetPropType}, TeammateRank={TeammateRank}, PointArrayIdx={PointArrayIdx}, LapTime={LapTime}, GetPropSecType={GetPropSecType}, PropPosIdx={PropPosIdx}, NPCUin={NPCUin}, ParaNum={ParaNum}, ParaList={ParaList}, PropID={PropID}")
    ResponseGetProp(Client, PropID, PropIndex) 
    for RoomClient in Client.Room.YieldTeammates(Client):
        logger.info(f"[RequestGetProp] 告知队友{RoomClient.Nick}获取了道具")
        NotifyGetProp(RoomClient, Client.Uin, PropID, PropIndex)
    
def ResponseGetProp(Client:ClientNode, PropID:int, PropIndex:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write32(p, Client.Uin) # Uin
    Write16(p, PropID) # PropID
    Write32(p, PropIndex) # PropIndex
    Write8(p, 0) # GetPropType
    Write32(p, 0) # AwardItemID
    Write8(p, 0) # ReasonLen
    Write16(p, 0) # PropPositionNO
    Write32(p, 0) # ActIDForClient
    Write8(p, 0) # GetPropSecType
    Write8(p, 0) # PropPosIdx
    Write32(p, 0) # NPCUin
    Write8(p, 0) # ParaNum
    # Write32(p, 0) # ParaList[]
    len = p - buf 
    SendToClient(Client, 124, buf, len, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response) 
    
    
# def NotifyAddProp(Client:ClientNode, Uin:int, PropID:int):
#     buf = get_buf()
#     p = buf.detach()
#     Write32(p, Uin) # Uin
#     Write16(p, PropID) # PropID
#     Write32(p, 0) # PropIdx
#     Write32(p, 0) # ItemID
#     Write32(p, 0) # StoneSkillType
#     SendToClient(Client, 526, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def NotifyGetProp(Client:ClientNode, Uin:int, PropID:int, PropIndex:int):
    buf = get_buf()
    p = buf.detach()
    
    Write32(p, Uin) # Uin
    Write16(p, PropID) # PropID
    Write32(p, PropIndex) # PropIndex
    Write16Int(p, 0) # PropPositionNO
    Write8(p, 0) # GetPropType
    Write8(p, 0) # PointArrayIdx
    Write32(p, 0) # LapTime
    Write8(p, 0) # GetPropSecType
    Write32(p, 0) # SrcUin
    Write8(p, 0) # ParaNum
    # Write32(p, 0) # ParaList[]
    SendToClient(Client, 516, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)
    

def ResponseSuperJetInc(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write16(p, 0) # PropID
    Write32(p, 0) # PropIndex
    Write32(p, 0) # CurrentAccelerateFuel
    Write8(p, 0) # ReasonLen
    Write32(p, GetSelfDefinedConfig().Special_YuqinlinIncrementalJetFuelPerN2O) # SuperJetKartFuelInc
    SendToClient(Client, 119, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
def ResponseReportDrift(Client:ClientNode, PropID:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write16(p, PropID) # PropID
    Write32(p, 0) # PropIndex
    Write32(p, 0) # CurrentAccelerateFuel
    Write8(p, 0) # ReasonLen
    Write32(p, GetSelfDefinedConfig().Special_YuqinlinIncrementalJetFuelPerN2O) # SuperJetKartFuelInc
    SendToClient(Client, 119, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
    
def RequestReportDrift(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    DriftFlag = Read32(Body)
    AccelerateFuelInc = Read32(Body)
    OnlyAccelSelfFue = Read8(Body)
    StartLapTime = Read32(Body)
    CurLapTime = Read32(Body)
    Client.Fuel += AccelerateFuelInc
    if Client.Fuel == CONST.MaxFuel:
        Client.Fuel = 0
        Client.CollectedN2O += 1
        JetID = 1 # 普通氮气
        if Client.CollectedN2O % GetSelfDefinedConfig().Special_YuqilinRequiredN2OPerSuperJet == 0:
            logger.info("超级氮气")
            JetID = 777
        ResponseReportDrift(Client, JetID)
        
    elif Client.Fuel > CONST.MaxFuel:
        logger.warn(f"[RequestReportDrift] 用户{Client.Nick}的氮气条{Client.Fuel}超过了最大值{CONST.MaxFuel}")