from common import *
from network import SendToClient

class ServerType:
    Game=0
    Dance=1
    Relax=2
class DirServerInfo:
    def __init__(self):
        self.ServerID = 0
        self.LocationID = 0
        self.ServerIP = 0
        self.ServerPort:list[int] = []
        self.MultiIPInfo: list[str] = []

class WorldBaseInfo:
    def __init__(self):
        self.WorldID = 0
        self.Name:str = ""
        self.DirNum = 0
        self.Dir: list[DirServerInfo] = []

g_WorldBaseInfo:WorldBaseInfo = WorldBaseInfo()

class GameServerInfo:
    def __init__(self):
        self.ServerID = 0
        self.ServerIP = 0
        self.TcpPort = 0
        self.UdpPort = 0
        self.MaxPlayerNum = 0
        self.CurrentPlayerNum = 0
        self.RandomKey = 0
        self.IsDisabledLogin = 0
        self.MultiIPInfo: list[str] = []

class IDCServerInfo:
    def __init__(self):
        self.LocationID = 0
        self.GameServerNum = 0
        self.GameServer: list[GameServerInfo] = []

class ChannelInfo:
    def __init__(self):
        self.ChannelID = 0
        self.IDCNum = 0
        self.IDC:list[IDCServerInfo] = []

class CountryInfo:
    def __init__(self):
        self.CountryID = 0
        self.ChannelNum = 0
        self.Channel:list[ChannelInfo] = []
g_CountryInfo = CountryInfo()

class ShopServerInfo:
    def __init__(self):
        self.ServerID= 0
        self.LocationID=0
        self.ServerIP = 0
        self.ServerPort = 0    
g_ShopServerInfo = ShopServerInfo()

class BorderServerInfo:
    def __init__(self):
        self.ServerInfo = GameServerInfo()
        self.LocationID = 0
g_BorderServerInfo = BorderServerInfo()
g_MatchServerInfo = BorderServerInfo()
g_RelaxServerInfo = BorderServerInfo()
g_TeamServerInfo = BorderServerInfo()
g_DanceServerInfo = BorderServerInfo()
g_SlideServerInfo = BorderServerInfo()
g_SkatingServerInfo = BorderServerInfo()

def InitDirServer(Name:str, IP:int, TcpPort:int , UdpPort:int):
    g_WorldBaseInfo.WorldID = 1
    g_WorldBaseInfo.Name = Name
    g_WorldBaseInfo.DirNum = 1
    g_WorldBaseInfo.Dir = [DirServerInfo()]
    pDir = g_WorldBaseInfo.Dir[0]
    pDir.ServerID = 2
    pDir.LocationID = 1
    pDir.ServerIP = IP
    pDir.ServerPort = [TcpPort, TcpPort, TcpPort]
    pDir.MultiIPInfo = None

    g_CountryInfo.CountryID = 1
    g_CountryInfo.ChannelNum = 5
    g_CountryInfo.Channel = [ChannelInfo() for i in range(g_CountryInfo.ChannelNum)]
    pChannel = g_CountryInfo.Channel[0]
    pChannel.ChannelID = 1 # 新手
    pChannel.IDCNum = 1
    pChannel.IDC = [IDCServerInfo()]
    pIDC = pChannel.IDC[0]
    pIDC.LocationID = 1
    pIDC.GameServerNum = 1
    pIDC.GameServer = [GameServerInfo()]
    pGameServer = pIDC.GameServer[0]
    pGameServer.ServerID = 110
    pGameServer.ServerIP = IP
    pGameServer.TcpPort = TcpPort
    pGameServer.UdpPort = UdpPort
    pGameServer.MaxPlayerNum = 10000
    pGameServer.CurrentPlayerNum = 1
    pGameServer.RandomKey = 0
    pGameServer.IsDisabledLogin = 0
    pGameServer.MultiIPInfo = None
    pChannel = g_CountryInfo.Channel[1]
    pChannel.ChannelID = 2 #初级
    pChannel.IDCNum = 1
    pChannel.IDC = [IDCServerInfo()]
    pIDC = pChannel.IDC[0]
    pIDC.LocationID = 1
    pIDC.GameServerNum = 1
    pIDC.GameServer = [GameServerInfo()]
    pGameServer = pIDC.GameServer[0]
    pGameServer.ServerID = 111
    pGameServer.ServerIP = IP
    pGameServer.TcpPort = TcpPort
    pGameServer.UdpPort = UdpPort
    pGameServer.MaxPlayerNum = 10000
    pGameServer.CurrentPlayerNum = 1
    pGameServer.RandomKey = 0
    pGameServer.IsDisabledLogin = 0
    pGameServer.MultiIPInfo = None
    pChannel = g_CountryInfo.Channel[2]
    pChannel.ChannelID = 3 #中级
    pChannel.IDCNum = 1
    pChannel.IDC = [IDCServerInfo()]
    pIDC = pChannel.IDC[0]
    pIDC.LocationID = 1
    pIDC.GameServerNum = 1
    pIDC.GameServer = [GameServerInfo()]
    pGameServer = pIDC.GameServer[0]
    pGameServer.ServerID = 112
    pGameServer.ServerIP = IP
    pGameServer.TcpPort = TcpPort
    pGameServer.UdpPort = UdpPort
    pGameServer.MaxPlayerNum = 10000
    pGameServer.CurrentPlayerNum = 1
    pGameServer.RandomKey = 0
    pGameServer.IsDisabledLogin = 0
    pGameServer.MultiIPInfo = None
    pChannel = g_CountryInfo.Channel[3]
    pChannel.ChannelID = 4 #高级
    pChannel.IDCNum = 1
    pChannel.IDC = [IDCServerInfo()]
    pIDC = pChannel.IDC[0]
    pIDC.LocationID = 1
    pIDC.GameServerNum = 1
    pIDC.GameServer = [GameServerInfo()]
    pGameServer = pIDC.GameServer[0]
    pGameServer.ServerID = 113
    pGameServer.ServerIP = IP
    pGameServer.TcpPort = TcpPort
    pGameServer.UdpPort = UdpPort
    pGameServer.MaxPlayerNum = 10000
    pGameServer.CurrentPlayerNum = 1
    pGameServer.RandomKey = 0
    pGameServer.IsDisabledLogin = 0
    pGameServer.MultiIPInfo = None
    # pChannel = g_CountryInfo.Channel[4]
    # pChannel.ChannelID = 5 #专业
    # pChannel.IDCNum = 1
    # pChannel.IDC = [IDCServerInfo()]
    # pIDC = pChannel.IDC[0]
    # pIDC.LocationID = 1
    # pIDC.GameServerNum = 1
    # pIDC.GameServer = [GameServerInfo()]
    # pGameServer = pIDC.GameServer[0]
    # pGameServer.ServerID = 114
    # pGameServer.ServerIP = IP
    # pGameServer.TcpPort = TcpPort
    # pGameServer.UdpPort = UdpPort
    # pGameServer.MaxPlayerNum = 10000
    # pGameServer.CurrentPlayerNum = 1
    # pGameServer.RandomKey = 0
    # pGameServer.IsDisabledLogin = 0
    # pGameServer.MultiIPInfo = None
    pChannel = g_CountryInfo.Channel[4]
    pChannel.ChannelID = 6 #交友
    pChannel.IDCNum = 1
    pChannel.IDC = [IDCServerInfo()]
    pIDC = pChannel.IDC[0]
    pIDC.LocationID = 1
    pIDC.GameServerNum = 1
    pIDC.GameServer = [GameServerInfo()]
    pGameServer = pIDC.GameServer[0]
    pGameServer.ServerID = 115
    pGameServer.ServerIP = IP
    pGameServer.TcpPort = TcpPort
    pGameServer.UdpPort = UdpPort
    pGameServer.MaxPlayerNum = 10000
    pGameServer.CurrentPlayerNum = 1
    pGameServer.RandomKey = 0
    pGameServer.IsDisabledLogin = 0
    pGameServer.MultiIPInfo = None
    
    g_ShopServerInfo.ServerID = 116
    g_ShopServerInfo.LocationID = 0
    g_ShopServerInfo.ServerIP = IP
    g_ShopServerInfo.ServerPort = TcpPort

    g_BorderServerInfo.ServerInfo.ServerID = 200
    g_BorderServerInfo.ServerInfo.ServerIP = IP
    g_BorderServerInfo.ServerInfo.TcpPort = TcpPort
    g_BorderServerInfo.ServerInfo.UdpPort = UdpPort
    g_BorderServerInfo.ServerInfo.MaxPlayerNum = 10000
    g_BorderServerInfo.ServerInfo.CurrentPlayerNum = 1
    g_BorderServerInfo.ServerInfo.RandomKey = 0
    g_BorderServerInfo.ServerInfo.IsDisabledLogin = 0
    g_BorderServerInfo.ServerInfo.MultiIPInfo = None
    g_BorderServerInfo.LocationID = 1

    g_MatchServerInfo.ServerInfo.ServerID = 300
    g_MatchServerInfo.ServerInfo.ServerIP = IP
    g_MatchServerInfo.ServerInfo.TcpPort = TcpPort
    g_MatchServerInfo.ServerInfo.UdpPort = UdpPort
    g_MatchServerInfo.ServerInfo.MaxPlayerNum = 10000
    g_MatchServerInfo.ServerInfo.CurrentPlayerNum = 1
    g_MatchServerInfo.ServerInfo.RandomKey = 0
    g_MatchServerInfo.ServerInfo.IsDisabledLogin = 0
    g_MatchServerInfo.ServerInfo.MultiIPInfo = None
    g_MatchServerInfo.LocationID = 1

    g_RelaxServerInfo.ServerInfo.ServerID = 400
    g_RelaxServerInfo.ServerInfo.ServerIP = IP
    g_RelaxServerInfo.ServerInfo.TcpPort = TcpPort
    g_RelaxServerInfo.ServerInfo.UdpPort = UdpPort
    g_RelaxServerInfo.ServerInfo.MaxPlayerNum = 100
    g_RelaxServerInfo.ServerInfo.CurrentPlayerNum = 1
    g_RelaxServerInfo.ServerInfo.RandomKey = 0
    g_RelaxServerInfo.ServerInfo.IsDisabledLogin = 0
    g_RelaxServerInfo.ServerInfo.MultiIPInfo = None
    g_RelaxServerInfo.LocationID = 1

    g_TeamServerInfo.ServerInfo.ServerID = 700
    g_TeamServerInfo.ServerInfo.ServerIP = IP
    g_TeamServerInfo.ServerInfo.TcpPort = TcpPort
    g_TeamServerInfo.ServerInfo.UdpPort = UdpPort
    g_TeamServerInfo.ServerInfo.MaxPlayerNum = 10000
    g_TeamServerInfo.ServerInfo.CurrentPlayerNum = 1
    g_TeamServerInfo.ServerInfo.RandomKey = 0
    g_TeamServerInfo.ServerInfo.IsDisabledLogin = 0
    g_TeamServerInfo.ServerInfo.MultiIPInfo = None
    g_TeamServerInfo.LocationID = 1

    g_DanceServerInfo.ServerInfo.ServerID = 800
    g_DanceServerInfo.ServerInfo.ServerIP = IP
    g_DanceServerInfo.ServerInfo.TcpPort = TcpPort
    g_DanceServerInfo.ServerInfo.UdpPort = UdpPort
    g_DanceServerInfo.ServerInfo.MaxPlayerNum = 10000
    g_DanceServerInfo.ServerInfo.CurrentPlayerNum = 1
    g_DanceServerInfo.ServerInfo.RandomKey = 0
    g_DanceServerInfo.ServerInfo.IsDisabledLogin = 0
    g_DanceServerInfo.ServerInfo.MultiIPInfo = None
    g_DanceServerInfo.LocationID = 1

    g_SlideServerInfo.ServerInfo.ServerID = 900
    g_SlideServerInfo.ServerInfo.ServerIP = IP
    g_SlideServerInfo.ServerInfo.TcpPort = TcpPort
    g_SlideServerInfo.ServerInfo.UdpPort = UdpPort
    g_SlideServerInfo.ServerInfo.MaxPlayerNum = 10000
    g_SlideServerInfo.ServerInfo.CurrentPlayerNum = 1
    g_SlideServerInfo.ServerInfo.RandomKey = 0
    g_SlideServerInfo.ServerInfo.IsDisabledLogin = 0
    g_SlideServerInfo.ServerInfo.MultiIPInfo = None
    g_SlideServerInfo.LocationID = 1

    g_SkatingServerInfo.ServerInfo.ServerID = 1234
    g_SkatingServerInfo.ServerInfo.ServerIP = IP
    g_SkatingServerInfo.ServerInfo.TcpPort = TcpPort
    g_SkatingServerInfo.ServerInfo.UdpPort = UdpPort
    g_SkatingServerInfo.ServerInfo.MaxPlayerNum = 10000
    g_SkatingServerInfo.ServerInfo.CurrentPlayerNum = 1
    g_SkatingServerInfo.ServerInfo.RandomKey = 0
    g_SkatingServerInfo.ServerInfo.IsDisabledLogin = 0
    g_SkatingServerInfo.ServerInfo.MultiIPInfo = None
    g_SkatingServerInfo.LocationID = 1
    
 

def ResponseGetWorldInfo(client:ClientNode, ClientVersion:int, MasterVersion:int, SlaveVersion:int):
    buf = get_buf()
    p = buf.detach()
    if not client.IsLogin:
        ResultID = 1
        Reason = "Incorrect password"
    else:
        ResultID = 0
        Reason = ""
    p.Write16(ResultID)
    p.Write32(ClientVersion)
    p.Write32(MasterVersion)
    p.Write32(4)
    p.Write8(0)
    RootDirection = "qqkart/test" # 干啥的
    WriteStringWithLength(p, RootDirection, bits_of_len=8)
    p.Write32(25)
    p.Write32(0)
    p.Write16(0)
    
    p.Write8(1) # WorldCount
    pWorldBaseInfo = p.detach()
    pWorldBaseInfo.Write16(0) # len
    pWorldBaseInfo.Write8(g_WorldBaseInfo.WorldID)
    WriteStringWithLength(pWorldBaseInfo, g_WorldBaseInfo.Name, bits_of_len=8)
    pWorldBaseInfo.Write8(g_WorldBaseInfo.DirNum)
    for i in range(g_WorldBaseInfo.DirNum):
        pDir = g_WorldBaseInfo.Dir[i]
        pDirServerInfo = pWorldBaseInfo.detach()
        pDirServerInfo.Write16(0) # len
        pDirServerInfo.Write32(pDir.ServerID)
        pDirServerInfo.Write16(pDir.LocationID)
        pDirServerInfo.Write32(pDir.ServerIP)
        for server_port in pDir.ServerPort:
            pDirServerInfo.Write16(server_port)
        pDirServerInfo.Write8(1 if pDir.MultiIPInfo else 0)
        length = pDirServerInfo - pWorldBaseInfo
        Set16(pWorldBaseInfo.data, pWorldBaseInfo.start, length)
        pWorldBaseInfo = pWorldBaseInfo[length:]
    length = pWorldBaseInfo - p
    Set16(p.data, p.start, length)
    p = p[length:]
    
    
    if client.IsLogin:
        p.Write8(1) # CountryCount
        pCountryInfo = p.detach()
        pCountryInfo.Write16(0) # len
        pCountryInfo.Write8(g_CountryInfo.CountryID)
        pCountryInfo.Write8(g_CountryInfo.ChannelNum)
        for i in range(g_CountryInfo.ChannelNum):
            pChannel = g_CountryInfo.Channel[i]
            pChannelInfo = pCountryInfo.detach()
            pChannelInfo.Write16(0) # len
            pChannelInfo.Write8(pChannel.ChannelID)
            pChannelInfo.Write8(pChannel.IDCNum)
            for pIDC in pChannel.IDC:
                pIDCServerInfo = pChannelInfo.detach()
                pIDCServerInfo.Write16(0) # len
                pIDCServerInfo.Write16(pIDC.LocationID)
                pIDCServerInfo.Write8(pIDC.GameServerNum)
                for pGameServer in pIDC.GameServer:
                    pGameServerInfo = pIDCServerInfo.detach()
                    pGameServerInfo.Write16(0) # len
                    pGameServerInfo.Write32(pGameServer.ServerID)
                    pGameServerInfo.Write32(pGameServer.ServerIP)
                    pGameServerInfo.Write16(pGameServer.TcpPort)
                    pGameServerInfo.Write16(pGameServer.UdpPort)
                    pGameServerInfo.Write16(pGameServer.MaxPlayerNum)
                    pGameServerInfo.Write16(pGameServer.CurrentPlayerNum)
                    pGameServerInfo.Write32(pGameServer.RandomKey)
                    pGameServerInfo.Write8(pGameServer.IsDisabledLogin)
                    pGameServerInfo.Write8(1 if pGameServer.MultiIPInfo else 0)
                    length = pGameServerInfo - pIDCServerInfo
                    Set16(pIDCServerInfo.data, pIDCServerInfo.start, length)
                    pIDCServerInfo = pIDCServerInfo[length:]
                length = pIDCServerInfo - pChannelInfo
                Set16(pChannelInfo.data, pChannelInfo.start, length)
                pChannelInfo = pChannelInfo[length:]
            length = pChannelInfo - pCountryInfo
            Set16(pCountryInfo.data, pCountryInfo.start, length)
            pCountryInfo = pCountryInfo[length:]
        length = pCountryInfo - p
        Set16(p.data, p.start, length)
        p = p[length:]
    else:
        p.Write8(0)
    
    
    p.Write8(1) # ShopServerCount
    pShopServerInfo = p.detach()
    pShopServerInfo.Write16(0) # len
    pShopServerInfo.Write32(g_ShopServerInfo.ServerID)
    pShopServerInfo.Write16(g_ShopServerInfo.LocationID)
    pShopServerInfo.Write32(g_ShopServerInfo.ServerIP)
    pShopServerInfo.Write16(g_ShopServerInfo.ServerPort)
    length = pShopServerInfo - p
    Set16(p.data, p.start, length)
    p = p[length:]
    
    p.Write8(1) # BorderServerCount
    pBorderServerInfo = p.detach()
    pBorderServerInfo.Write16(0) # len
    pServerInfo = pBorderServerInfo.detach()
    pServerInfo.Write16(0) # len
    pServerInfo.Write32(g_BorderServerInfo.ServerInfo.ServerID)
    pServerInfo.Write32(g_BorderServerInfo.ServerInfo.ServerIP)
    pServerInfo.Write16(g_BorderServerInfo.ServerInfo.TcpPort)
    pServerInfo.Write16(g_BorderServerInfo.ServerInfo.UdpPort)
    pServerInfo.Write16(g_BorderServerInfo.ServerInfo.MaxPlayerNum)
    pServerInfo.Write16(g_BorderServerInfo.ServerInfo.CurrentPlayerNum)
    pServerInfo.Write32(g_BorderServerInfo.ServerInfo.RandomKey)
    pServerInfo.Write8(g_BorderServerInfo.ServerInfo.IsDisabledLogin)
    pServerInfo.Write8(1 if g_BorderServerInfo.ServerInfo.MultiIPInfo else 0)
    length = pServerInfo - pBorderServerInfo
    Set16(pBorderServerInfo.data, pBorderServerInfo.start, length)
    pBorderServerInfo = pBorderServerInfo[length:]
    pBorderServerInfo.Write16(g_BorderServerInfo.LocationID)
    length = pBorderServerInfo - p
    Set16(p.data, p.start, length)
    p = p[length:]
    
    p.Write8(1) # MatchServerCount
    pMatchServerInfo = p.detach()
    pMatchServerInfo.Write16(0) # len
    pServerInfo = pMatchServerInfo.detach()
    pServerInfo.Write16(0) # len
    pServerInfo.Write32(g_MatchServerInfo.ServerInfo.ServerID)
    pServerInfo.Write32(g_MatchServerInfo.ServerInfo.ServerIP)
    pServerInfo.Write16(g_MatchServerInfo.ServerInfo.TcpPort)
    pServerInfo.Write16(g_MatchServerInfo.ServerInfo.UdpPort)
    pServerInfo.Write16(g_MatchServerInfo.ServerInfo.MaxPlayerNum)
    pServerInfo.Write16(g_MatchServerInfo.ServerInfo.CurrentPlayerNum)
    pServerInfo.Write32(g_MatchServerInfo.ServerInfo.RandomKey)
    pServerInfo.Write8(g_MatchServerInfo.ServerInfo.IsDisabledLogin)
    pServerInfo.Write8(1 if g_MatchServerInfo.ServerInfo.MultiIPInfo else 0)
    length = pServerInfo - pMatchServerInfo
    Set16(pMatchServerInfo.data, pMatchServerInfo.start, length)
    pMatchServerInfo = pMatchServerInfo[length:]
    pMatchServerInfo.Write16(g_MatchServerInfo.LocationID)
    length = pMatchServerInfo - p
    Set16(p.data, p.start, length)
    p = p[length:]
    
    p.Write8(1) # RelaxServerCount
    pRelaxServerInfo = p.detach()
    pRelaxServerInfo.Write16(0) # len
    pServerInfo = pRelaxServerInfo.detach()
    pServerInfo.Write16(0) # len
    pServerInfo.Write32(g_RelaxServerInfo.ServerInfo.ServerID)
    pServerInfo.Write32(g_RelaxServerInfo.ServerInfo.ServerIP)
    pServerInfo.Write16(g_RelaxServerInfo.ServerInfo.TcpPort)
    pServerInfo.Write16(g_RelaxServerInfo.ServerInfo.UdpPort)
    pServerInfo.Write16(g_RelaxServerInfo.ServerInfo.MaxPlayerNum)
    pServerInfo.Write16(g_RelaxServerInfo.ServerInfo.CurrentPlayerNum)
    pServerInfo.Write32(g_RelaxServerInfo.ServerInfo.RandomKey)
    pServerInfo.Write8(g_RelaxServerInfo.ServerInfo.IsDisabledLogin)
    pServerInfo.Write8(1 if g_RelaxServerInfo.ServerInfo.MultiIPInfo else 0)
    UpdateLen16(pRelaxServerInfo, pServerInfo)

    pRelaxServerInfo.Write16(g_RelaxServerInfo.LocationID)
    UpdateLen16(p, pRelaxServerInfo)
    
    p.Write8(0) # NetAdminServerCount

    p.Write16(len(Reason))
    SetBytes(p.data, p.start, Reason.encode(), 0, len(Reason))
    p = p[len(Reason):]
    
    p.Write8(0) # DownloadServerNum
    
    p.Write8(1) # TeamServerCount
    pTeamServerInfo = p.detach()
    pTeamServerInfo.Write16(0) # len
    pServerInfo = pTeamServerInfo.detach()
    pServerInfo.Write16(0) # len
    pServerInfo.Write32(g_TeamServerInfo.ServerInfo.ServerID)
    pServerInfo.Write32(g_TeamServerInfo.ServerInfo.ServerIP)
    pServerInfo.Write16(g_TeamServerInfo.ServerInfo.TcpPort)
    pServerInfo.Write16(g_TeamServerInfo.ServerInfo.UdpPort)
    pServerInfo.Write16(g_TeamServerInfo.ServerInfo.MaxPlayerNum)
    pServerInfo.Write16(g_TeamServerInfo.ServerInfo.CurrentPlayerNum)
    pServerInfo.Write32(g_TeamServerInfo.ServerInfo.RandomKey)
    pServerInfo.Write8(g_TeamServerInfo.ServerInfo.IsDisabledLogin)
    pServerInfo.Write8(1 if g_TeamServerInfo.ServerInfo.MultiIPInfo else 0)
    length = pServerInfo - pTeamServerInfo
    Set16(pTeamServerInfo.data, pTeamServerInfo.start, length)
    pTeamServerInfo = pTeamServerInfo[length:]
    pTeamServerInfo.Write16(g_TeamServerInfo.LocationID)
    length = pTeamServerInfo - p
    Set16(p.data, p.start, length)
    p = p[length:]
    
    p.Write8(1) # DanceServerCount
    pDanceServerInfo = p.detach()
    pDanceServerInfo.Write16(0) # len
    pServerInfo = pDanceServerInfo.detach()
    pServerInfo.Write16(0) # len
    logger.info(f"g_DanceServerInfo.ServerInfo.ServerID={g_DanceServerInfo.ServerInfo.ServerID}")
    pServerInfo.Write32(g_DanceServerInfo.ServerInfo.ServerID)
    pServerInfo.Write32(g_DanceServerInfo.ServerInfo.ServerIP)
    pServerInfo.Write16(g_DanceServerInfo.ServerInfo.TcpPort)
    pServerInfo.Write16(g_DanceServerInfo.ServerInfo.UdpPort)
    pServerInfo.Write16(g_DanceServerInfo.ServerInfo.MaxPlayerNum)
    pServerInfo.Write16(g_DanceServerInfo.ServerInfo.CurrentPlayerNum)
    pServerInfo.Write32(g_DanceServerInfo.ServerInfo.RandomKey)
    pServerInfo.Write8(g_DanceServerInfo.ServerInfo.IsDisabledLogin)
    pServerInfo.Write8(1 if g_DanceServerInfo.ServerInfo.MultiIPInfo else 0)
    length = pServerInfo - pDanceServerInfo
    Set16(pDanceServerInfo.data, pDanceServerInfo.start, length)
    pDanceServerInfo = pDanceServerInfo[length:]
    pDanceServerInfo.Write16(g_DanceServerInfo.LocationID)
    length = pDanceServerInfo - p
    Set16(p.data, p.start, length)
    p = p[length:]
    
    p.Write8(1) # SlideServerCount
    pSlideServerInfo = p.detach()
    pSlideServerInfo.Write16(0) # len
    pServerInfo = pSlideServerInfo.detach()
    pServerInfo.Write16(0) # len
    pServerInfo.Write32(g_SlideServerInfo.ServerInfo.ServerID)
    pServerInfo.Write32(g_SlideServerInfo.ServerInfo.ServerIP)
    pServerInfo.Write16(g_SlideServerInfo.ServerInfo.TcpPort)
    pServerInfo.Write16(g_SlideServerInfo.ServerInfo.UdpPort)
    pServerInfo.Write16(g_SlideServerInfo.ServerInfo.MaxPlayerNum)
    pServerInfo.Write16(g_SlideServerInfo.ServerInfo.CurrentPlayerNum)
    pServerInfo.Write32(g_SlideServerInfo.ServerInfo.RandomKey)
    pServerInfo.Write8(g_SlideServerInfo.ServerInfo.IsDisabledLogin)
    pServerInfo.Write8(1 if g_SlideServerInfo.ServerInfo.MultiIPInfo else 0)
    length = pServerInfo - pSlideServerInfo
    Set16(pSlideServerInfo.data, pSlideServerInfo.start, length)
    pSlideServerInfo = pSlideServerInfo[length:]
    pSlideServerInfo.Write16(g_SlideServerInfo.LocationID)
    length = pSlideServerInfo - p
    Set16(p.data, p.start, length)
    p = p[length:]
    
    p.Write32(0) # UpdateType
    p.Write8(0) # OpenOtherIDCFlag
    p.Write16(0) # OtherIDCID
    p.Write8(0) # BugReportServerCount
    p.Write8(0) # IsDynamicDownloadPermitted
    p.Write8(0) # DynamicDownloadResourceIdNum
    p.Write8(0) # EnableRandMapMusicPreKnown
    p.Write16(0) # MinPlayerNumForRand
    p.Write16(0) # PlayerNumDeltaForRand
    p.Write8(0) # FBServerCount

    WebCGIDomain = "localhost"
    p.Write8(len(WebCGIDomain)) # WebCGIDomainLen
    SetBytes(p.data, p.start, WebCGIDomain.encode(), 0, len(WebCGIDomain))
    p = p[len(WebCGIDomain):]

    p.Write16(8000) # WebCGIServerPort
    p.Write8(0) # WlMatchSvrCount
    
    p.Write8(1) # SkateServerCount
    pSkateServerInfo = p.detach()
    pSkateServerInfo.Write16(0)  # len
    pServerInfo = pSkateServerInfo.detach()
    pServerInfo.Write16(0)  # len
    pServerInfo.Write32(g_SkatingServerInfo.ServerInfo.ServerID)
    pServerInfo.Write32(g_SkatingServerInfo.ServerInfo.ServerIP)
    pServerInfo.Write16(g_SkatingServerInfo.ServerInfo.TcpPort)
    pServerInfo.Write16(g_SkatingServerInfo.ServerInfo.UdpPort)
    pServerInfo.Write16(g_SkatingServerInfo.ServerInfo.MaxPlayerNum)
    pServerInfo.Write16(g_SkatingServerInfo.ServerInfo.CurrentPlayerNum)
    pServerInfo.Write32(g_SkatingServerInfo.ServerInfo.RandomKey)
    pServerInfo.Write8(g_SkatingServerInfo.ServerInfo.IsDisabledLogin)
    pServerInfo.Write8(1 if g_SkatingServerInfo.ServerInfo.MultiIPInfo else 0)
    length = pServerInfo - pSkateServerInfo
    Set16(pSkateServerInfo.data, pSkateServerInfo.start, length)
    pSkateServerInfo = pSkateServerInfo[length:]
    pSkateServerInfo.Write16(g_SkatingServerInfo.LocationID)
    length = pSkateServerInfo - p
    Set16(p.data, p.start, length)
    p = p[length:]
    
    p.Write8(0) # VersionCount
    # VersionList[]

    p.Write32(0) # IsEnableBETA
    p.Write32(0) # AreaID
    p.Write8(0) # PreVersionCount
    # PreVersionList[]
    p.Write8(0) # IsEnableMapTester
    p.Write8(0) # DisableRandomDanceSvr
    p.Write8(0) # DisableRandomSkateSvr
    # m_abyClientSwitch[16]
    SetBytes(p.data, p.start, b'\x00'*16, 0, 16)
    p = p[16:]
    p.Write16(0) # PreResoveDomainNum
    p.Write8(0) # MRServerCount
    p.Write16(0) # MinPlayerNumForRandForGsvrd6
    p.Write8(0) # NpcServerCount
    p.Write8(0) # PatchCount
    p.Write8(0) # UrlCount
    p.Write16(0) # LoginBuffLen
    p.Write16(0) # WebURLLen
    
    length = p - buf
    logger.debug(f"[ResponseGetWorldInfo], length={length}")
    SendToClient(client, 90, buf, length,0, FE.DIRSVRD, 0, MsgType.Response)
    
def GetServerType(ServerID:int)->int:
    if ServerID == g_RelaxServerInfo.ServerInfo.ServerID:
        return ServerType.Relax
    if ServerID == g_DanceServerInfo.ServerInfo.ServerID:
        return ServerType.Dance
    return ServerType.Game