import random
from car import *
class ItemType:
    EAIT_Unknown = 0
    EAIT_CAR = 1
    EAIT_SUIT = 2 # 赛车皮肤
class FamousMan: # 红人
    def __init__(self, ID:int, Name:str, ValueDesc:str, TitleName:str, IsEnableSelfRank:bool):
        self.ID = ID
        self.Name = Name
        self.ValueDesc = ValueDesc
        self.TitleName = TitleName
        self.IsEnableSelfRank = IsEnableSelfRank
class SingleStoneSkillConfig:
    def __init__(self, StoneID:int, ActiveCondVal1:int, UseCountUpperlimit:int, ActiveSuccessProb:int, CoolTime:int, GenResultVal1:int):
        self.StoneID, self.ActiveCondVal1, self.UseCountUpperlimit, self.ActiveSuccessProb, self.CoolTime, self.GenResultVal1 = StoneID, ActiveCondVal1, UseCountUpperlimit, ActiveSuccessProb, CoolTime, GenResultVal1
class MAP:
    def __init__(self, id:int, head:int, end:int, loop:bool, round:int, name:str):
        self.id, self.head, self.end, self.loop, self.round, self.name = id, head, end, loop, round, name
    def __repr__(self):
        return f"{type(self).__name__}(id={self.id}, head={self.head}, end={self.end}, loop={self.loop}, round={self.round}, name={self.name})"
class ITEM:
    def __init__(self, ID:int, Type):
        if isinstance(Type, str):
            Type = getattr(ItemType, Type)
        self.ID:int = ID
        self.Type:int = Type
class GIFT:
    def __init__(self, ItemID, ItemNum, AvailPeriod):
        self.ItemID = ItemID
        self.ItemNum = ItemNum
        self.AvailPeriod = AvailPeriod
class ShapeSuitKart:
    def __init__(self, KartID, ShapeSuitID):
        self.KartID = KartID
        self.ShapeSuitID = ShapeSuitID
class ServerInfo:
    def __init__(self):
        self.update()
    def update(self):
        with open("config/config.yml", 'r', encoding='utf-8') as f:
            self.data = yaml.load(f)
        
class Item:
    def __init__(self):
        self.update()
    def update(self):
        with open("config/item.yml", 'r', encoding='utf-8') as f:
            data = yaml.load(f)
        self.items:dict[int, ITEM] = {}
        for v in data:
            item = ITEM(v['ID'], v['Type'])
            self.items[v['ID']] = item
    def GetItemType(self, ID:int)->int:
        if ID in self.items:
            return self.items[ID].Type
        return ItemType.EAIT_Unknown
    
class ShapeRefitLegend: # 传奇皮肤
    def __init__(self):
        self.update()
    def update(self):
        self.shapeRefitKarts:list[ShapeSuitKart] = []
        with open("config/ShapeRefitCfg.yml", 'r', encoding='utf-8') as f:
            data = yaml.load(f)
            for d in data["ShapeRefitLegend"]:
                KartID = d["KartID"]
                ShapeSuitID = d["ShapeSuitID"]
                self.shapeRefitKarts.append(ShapeSuitKart(KartID, ShapeSuitID))


class TopListDesc:
    def __init__(self):
        self.update()
    def update(self):
        self.famousColumn = []
        with open("config/TopListDesc-ZingSpeed.yml", 'r', encoding='gbk') as f:
            data = yaml.load(f)
            for v in data:
                self.famousColumn.append(FamousMan(v["ID"], v["Name"], v["ValueDesc"], v["TitleName"], v["IsEnableSelfRank"]))

class SingleSkillStoneCfg:
    def __init__(self):
        self.update()
    def update(self):
        self.stoneConfigs:list[SingleStoneSkillConfig] = []
        with open("config/SingleSkillStoneCfg.yml", 'r', encoding='utf-8') as f:
            data = yaml.load(f)
            for v in data:
                self.stoneConfigs.append(SingleStoneSkillConfig(v["StoneID"], v["ActiveCondVal1"], v["UseCountUpperlimit"], v["ActiveSuccessProb"], v["CoolTime"], v["GenResultVal1"]))

class Maps:
    def __init__(self):
        self.update()
    def update(self):
        with open("Map/map.yml", 'r') as f:
            data = yaml.load(f)
            self.maps:dict[int, MAP] = {}
            for v in data:
                self.maps[v['ID']] = MAP(v['ID'], v['Head'], v['End'], v['Loop'], v['Round'], v['Name'])
        with open("Map/RandomMaps.yml", 'r') as f:
            data = yaml.load(f)
            self.random_maps:dict[int,list[int]] = {}
            for d in data:
                self.random_maps[d['ID']] = d['Maps']
    
    def GetMap(self, ID:int)->MAP:
        if ID < 100:
            return self.maps[random.choice(self.random_maps[ID])]
        if ID in self.maps:
            return self.maps[ID]
        else:
            return MAP(ID, 0, 0, False, 1, f"未配置地图(ID={ID})")

class SelfDefinedConfig:
    def __init__(self):
        self.update()
    def update(self):
        with open("config/SelfDefinedConfig.yml", 'r', encoding='utf-8') as f:
            data = yaml.load(f)
            self.PropDelayMin = data["Brush"]["PropDelayMin"]
            self.PropDelayMax = data["Brush"]["PropDelayMax"]
            if self.PropDelayMin < 1 or self.PropDelayMin > self.PropDelayMax:
                raise Exception("PropDelayMin < 1 or PropDelayMin > PropDelayMax")
            self.PropIDs = [v for v in data["Brush"]["PropIDs"]]
            self.GivenPropIDs = [v for v in data["Brush"]["GivenPropIDs"]]
            
            self.GiftForRegister:list[GIFT] = [GIFT(v["ItemID"], v["ItemNum"], v["AvailPeriod"]) for v in data["GiftForRegister"]]
            
            self.StartDancePeriod = data["Room"]["StartDancePeriod"]
            self.Over2AwardDelay = data["Room"]["Over2AwardDelay"]
            self.AwardPeriod = data["Room"]["AwardPeriod"]
            self.CountDownTime = data["Room"]["CountDownTime"]
            self.UseNewCountDownTime = data["Room"]["UseNewCountDownTime"]
            self.NewCountDownTime = data["Room"]["NewCountDownTime"]
            self.CountDownAfterFirstFinish = data["Room"]["CountDownAfterFirstFinish"]
            self.DefaultMapID = data["Room"]["DefaultMapID"]

            self.Reborn_TakeEffectProb = data["Reborn"]["TakeEffectProb"]
            self.Reborn_RequiredN2OForCold = data["Reborn"]["RequiredN2OForCold"]

            self.Map_Season = data["Map"]["Season"]
            self.Map_Timeslot = data["Map"]["Timeslot"]
            self.Map_Weather = data["Map"]["Weather"]

            self.Car_EnableAntiDriftCheat = data["Car"]["EnableAntiDriftCheat"]
            self.Car_ProfessionLicenseBigLevel = data["Car"]["ProfessionLicenseBigLevel"]
            self.Car_ProfessionLicenseSmallLevel = data["Car"]["ProfessionLicenseSmallLevel"]
            self.Car_ReportAntiCollisionDataTime = data["Car"]["ReportAntiCollisionDataTime"]
            self.Car_ExtraInfoInterval = data["Car"]["ExtraInfoInterval"]
            self.Car_NormalLoadTime = data["Car"]["NormalLoadTime"]
            self.Car_SuperN2ORate = data["Car"]["SuperN2ORate"]
            self.Special_YuqilinRequiredN2OPerSuperJet = data["Special"]["YuqilinRequiredN2OPerSuperJet"]
            self.Special_YuqinlinIncrementalJetFuelPerN2O = (1000+1)//self.Special_YuqilinRequiredN2OPerSuperJet # TODO: 1000这个值是随便估计的，可能不对
            
class PropModes:
    KeyType = int # CurrentRank, may be others...
    ValueType = tuple[int] # list of PropIDs. 用重复数量来控制概率
    ModesType = tuple[int,int] # BaseMode, SubMode
    Key2Props = dict[KeyType, ValueType]
    Modes2Props = dict[ModesType, Key2Props]
    def __init__(self):
        self.update()
    def update(self):
        self.modes2props:PropModes.Modes2Props = {}
        dir = f"config/PropMode"
        for file in os.listdir(dir):
            if file.endswith(".yml"):
                try:
                    modes = file[:-4].split('-')
                    BaseMode = int(modes[0])
                    SubMode = int(modes[1])
                    tmpKey2Props = {}
                    with open(f"{dir}/{file}", 'r', encoding='utf-8') as f:
                        data = yaml.load(f)
                        for d in data:
                            CurrentRank = d['CurrentRank']
                            Props = d['Props']
                            tmpKey2Props[CurrentRank] = list(Props)
                    self.modes2props[(BaseMode, SubMode)] = tmpKey2Props
                except:
                    import traceback
                    logger.warn(f"[PropModes] {file} is not a valid PropMode file, ErrorInfo: {traceback.format_exc()}")
    def GetProp(self, BaseMode:int, SubMode:int, CurrentRank:int)->int:
        Modes = (BaseMode, SubMode)
        key2Props = self.modes2props[Modes] if Modes in self.modes2props else self.modes2props[(0, 0)]
        return random.choice(key2Props[CurrentRank])



                            
_propModes_ = PropModes()
_item_ = Item()
_serverInfo_ = ServerInfo()
_topListDesc_ = TopListDesc()
_singleSkillStoneCfg_ = SingleSkillStoneCfg()
_shapeRefitLegend_ = ShapeRefitLegend()
_maps_ = Maps()
_selfDefinedConfig_ = SelfDefinedConfig()

def getDebugArgByIndex(Index:int):
    with open("config/DebugArgs.yml", 'r', encoding='utf-8') as f:
        data = yaml.load(f)
        return data[Index]
def isCar(ItemID:int)->bool:
    return _item_.GetItemType(ItemID) == ItemType.EAIT_CAR
def getItem()->Item:
    return _item_
def getServerInfo()->dict:
    return _serverInfo_.data
def getTopListDesc()->list[FamousMan]:
    return _topListDesc_.famousColumn
def getSingleStoneSkillStoneCfg()->list[SingleSkillStoneCfg]:
    return _singleSkillStoneCfg_.stoneConfigs
def getShapeRefitLegend()->list[ShapeSuitKart]:
    return _shapeRefitLegend_.shapeRefitKarts
def getMap()->Maps:
    return _maps_
def getPropModes()->PropModes:
    return _propModes_
def GetSelfDefinedConfig()->SelfDefinedConfig:
    return _selfDefinedConfig_
def update_all():
    _item_.update()
    _serverInfo_.update()
    _topListDesc_.update()
    _singleSkillStoneCfg_.update()
    _shapeRefitLegend_.update()
    _maps_.update()
    _selfDefinedConfig_.update()
    _propModes_.update()
    get_Karts().id2kart.clear()
    car_clear_cache()

if __name__ == '__main__':
    print(_item_.data)
    print(_item_.GetItemType(10205))
    print(_item_.GetItemType(10207))
    print(_topListDesc_.data)
    print(getSingleStoneSkillStoneCfg())
    print(_maps_.GetMap(2))
    print(_maps_.GetMap(2))