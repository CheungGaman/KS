from common import *
   
def RequestChangeOBState(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    OBState = Read8(Body)
    pass

def ResponseChangeOBState(Client:ClientNode, OBState:int):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)
    Write8(p, OBState)
    Write8(p, 0)
    SendToClient(Client, 134, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)
        
def NotifyChangeOBState(Client:ClientNode, Uin:int, OBState:int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, Uin)
    Write8(p, OBState)
    SendToClient(Client, 609, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def ResponseChangeMap(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Room = Client.Room
    Write16(p, 0) # ResultID
    Write32(p, Room.MapID) # NewMapID
    Write8(p, 0) # ReasonLen
    Write8(p, 0) # UnLockMapCondDescNum
    # m_astUnLockMapCondDesc[].m_bDescLen

    if True: # STDynamicInfo
        pSTDynamicInfo = p.detach()
        Write16(pSTDynamicInfo, 0) # len
        Write8(pSTDynamicInfo, Room.Weather.Season)
        Write8(pSTDynamicInfo, Room.Weather.Timeslot)
        Write8(pSTDynamicInfo, Room.Weather.Weather)
        UpdateLen16(p, pSTDynamicInfo)
    Write32(p, 0) # PreKnowMapID
    Write32(p, 0) # MapSubID
    Write8(p, 0) # FirstlyTipMap
    SendToClient(Client, 121, buf, p-buf, Client.GameID, FE.GAMELOGIC, Client.ConnID, MsgType.Response)

def NotifyChangeMap(Client:ClientNode, Uin:int):
    buf = get_buf()
    p = buf.detach()
    Room = Client.Room
    Write32(p, Uin) # Uin
    Write32(p, Room.MapID) # NewMapID
    if True: # STDynamicInfo
        pSTDynamicInfo = p.detach()
        Write16(pSTDynamicInfo, 0) # len
        Write8(pSTDynamicInfo, Room.Weather.Season)
        Write8(pSTDynamicInfo, Room.Weather.Timeslot)
        Write8(pSTDynamicInfo, Room.Weather.Weather)
        UpdateLen16(p, pSTDynamicInfo)

    Write32(p, 0) # PreKnowMapID
    Write32(p, 0) # MapSubID
    Write8(p, 0) # FirstlyTipMap
    SendToClient(Client, 520, buf, p-buf, Client.Room.ID, FE.ROOM, Client.ConnID, MsgType.Notify)


def RequestChangeMap(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    NewMapID = Read32(Body)
    logger.info(f"[RequestChangeMap] 用户{Client.Nick} 更换了新地图 {getMap().GetMap(NewMapID).name}")
    pSTDynamicInfo = Body.detach()
    length = Read16(pSTDynamicInfo)
    Season = Read8(pSTDynamicInfo)
    Timeslot = Read8(pSTDynamicInfo)
    Weather = Read8(pSTDynamicInfo)
    Body.start += length
    Room = Client.Room
    if not Room: return
    Room.MapID = NewMapID
    Room.Weather = STDynamicInfo(Season, Timeslot, Weather)
    ResponseChangeMap(Client)
    for RoomClient in Room.YieldClientExcept(Client):
        NotifyChangeMap(RoomClient, Client.Uin)
