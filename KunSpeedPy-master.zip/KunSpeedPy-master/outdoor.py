from common import *
from DirectoryServer import *

def InitChatRoom():
    for i in range(CONST.MaxChatRoomNum):
        ChatRoom = ChatRoomNode()
        ChatRoom.Name = f"琳琅湾{ChatRoom.ID}"
        ChatRoom.CurPlayerNum = 0
        ChatRoom.MaxPlayerNum = 99
        ChatRoom.RoomType = 0
        ChatRoom.SceneID = 109
        ChatRoom.x = -20000
        ChatRoom.y = -60000
        ChatRoom.z = -3330
        ChatRooms[ChatRoom.ID] = ChatRoom
    assert(len(ChatRooms) == CONST.MaxChatRoomNum), "聊天室数量不对，检查是否重复初始化"


def RequestGetChatRoomList(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    StartRoomIdx = Read16(Body)
    GetRoomNum = Read16(Body)
    GetRoomType = Read16(Body)
    ResponseGetChatRoomList(Client, GetRoomType)


def ResponseGetChatRoomList(Client: ClientNode, GetRoomType: ChatRoomNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0)  # ResultID
    Write8(p, 0)  # ReasonLen
    Write16(p, 1)  # CurTotalRoomNum
    Write16(p, 0)  # StartRoomIdx
    Write16(p, CONST.MaxChatRoomNum)  # MaxChatRoomNum
    for i in ChatRooms:
        pChatRoomInfo = p.detach()
        Write16(pChatRoomInfo, 0) # len
        Write32(pChatRoomInfo, g_RelaxServerInfo.ServerInfo.ServerID) # ServerID
        Write32(pChatRoomInfo, ChatRooms[i].ID) # ChatRoomID
        WriteStringWithLength(pChatRoomInfo, ChatRooms[i].Name, bits_of_len=8) # RoomName
        Write16(pChatRoomInfo, ChatRooms[i].CurPlayerNum) 
        Write16(pChatRoomInfo, ChatRooms[i].MaxPlayerNum)
        Write32(pChatRoomInfo, ChatRooms[i].RoomType)
        Write16(pChatRoomInfo, ChatRooms[i].SceneID)
        Write16(pChatRoomInfo, 0)
        UpdateLen16(p, pChatRoomInfo)
    Write16(p, GetRoomType)
    SendToClient(Client, 91, buf, p - buf, 0, FE.DIRSVRD, 0, MsgType.Response)

def GetChatRoom(ChatRoomID:int):
    return ChatRooms.get(ChatRoomID, None)

def ResponseLeaveOutdoor(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 0) # ResultID
    Write8(p, 0) # ReasonLen
    SendToClient(Client, 353, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Response)


def NotifyLeaveOutdoor(Client:ClientNode, LeaveUin: int):
    buf = get_buf()
    p = buf.detach()
    Write32(p, LeaveUin)
    Write32(p, int(time.time())) # Time
    SendToClient(Client, 853, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)


def LeaveOutdoor(Client:ClientNode):
    ChatRoom = Client.ChatRoom
    if not ChatRoom: return
    ResponseLeaveOutdoor(Client)
    ChatRoom.Player.pop(Client.Uin)
    Client.ChatRoom = None
    ChatRoom.CurPlayerNum -= 1
    for Player in ChatRoom.YieldClientExcept(Client):
        NotifyLeaveOutdoor(Player, Client.Uin)
    
def NotifyNPCInfo(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    Write16(p, 4) # NPCCfgVer
    Write8(p, 0) # NPCNum
    SendToClient(Client, 863, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)


def NotifyEnterOutdoor(Client:ClientNode, ChatRoom:ChatRoomNode, RoomClient:ClientNode):
    buf = get_buf()
    p = buf.detach()

    Write16(p, ChatRoom.ID) # ChatRoomID
    Write16(p, ChatRoom.SceneID) # SceneID
    Write32(p, int(time.time())) # Time
    if True: # HeroInfo
        pHeroInfo = p.detach()
        Write16(pHeroInfo, 0) # len
        if True: # HeroMoveInfo
            pHeroMoveInfo = pHeroInfo.detach()
            Write16(pHeroMoveInfo, 0) # len
            Write32(pHeroMoveInfo, RoomClient.Uin) # Uin
            Write8(pHeroMoveInfo, 0) # WalkStatue
            Write32Int(pHeroMoveInfo, ChatRoom.x) # Posion[3]
            Write32Int(pHeroMoveInfo, ChatRoom.y)
            Write32Int(pHeroMoveInfo, ChatRoom.z)
            Write32(pHeroMoveInfo, 1000) # Ori[9]
            Write32(pHeroMoveInfo, 0)
            Write32(pHeroMoveInfo, 0)
            Write32(pHeroMoveInfo, 0)
            Write32(pHeroMoveInfo, 1000)
            Write32(pHeroMoveInfo, 0)
            Write32(pHeroMoveInfo, 0)
            Write32(pHeroMoveInfo, 0)
            Write32(pHeroMoveInfo, 1000)
            Write32(pHeroMoveInfo, 0) # AttachUin
            Write32(pHeroMoveInfo, 0) # WalkExtState
            UpdateLen16(pHeroInfo, pHeroMoveInfo)
        Write32(pHeroInfo, 0) # NextPoint
        Write16(pHeroInfo, 0) # PathLen
        # m_astHeroInfo[].m_aiPath[]
        WriteRoomVisibleInfo(pHeroInfo, RoomClient) # HeroVisbleInfo
        Write16(pHeroInfo, 0) # HeroEnterDelayTime
        UpdateLen16(p, pHeroInfo)   
    if True: # PlayerRelationInfo
        pPlayerRelationInfo = p.detach()
        Write16(pPlayerRelationInfo, 0) # len
        Write32(pPlayerRelationInfo, RoomClient.Uin) # SrcUin
        Write32(pPlayerRelationInfo, 0) # RelationFlag
        Write32(pPlayerRelationInfo, 0) # RelationUin
        WriteStringWithFixedLength(pPlayerRelationInfo, "测试伴侣名字", CONST.MaxNickName) # RelationNickname
        Write32(pPlayerRelationInfo, 0) # EngageTime
        Write32(pPlayerRelationInfo, 0) # NextCanBookingTimeLimit
        Write32(pPlayerRelationInfo, 0) # BeginHoneyMoonTime
        Write32(pPlayerRelationInfo, 0) # EndHoneyMoonTime
        Write8(pPlayerRelationInfo, 0) # EngageFlag
        UpdateLen16(p, pPlayerRelationInfo)
    Write16(p, 0) # KartNum
    if True: # StealPig
        pStealPig = p.detach()
        Write16(pStealPig, 0) # len
        Write8(pStealPig, 0) # Status
        Write8(pStealPig, 0) # PigPos
        Write32(pStealPig, 0) # ItemID
        UpdateLen16(p, pStealPig)
    SendToClient(Client, 852, buf, p-buf, ChatRoom.ID, FE.OUTDOORSVRD, Client.ConnID, MsgType.Notify)

def NotifyGuildRoomMoreInfo(Client: ClientNode):
    buf = get_buf()
    p = buf.detach()

    Write32(p, 0) # GuildID
    Write8(p, 0) # GuildRoomID

    pHeroCount = p.detach()
    ChatRoom = Client.ChatRoom
    if not ChatRoom: return 
    Write16(p, len(ChatRoom.Player)-1) # HeroCount, 要去掉自己  
    for Player in ChatRoom.YieldClientExcept(Client):
        if True: # HeroInfo
            pHeroInfo = p.detach()
            Write16(pHeroInfo, 0) # len
            if True: # HeroMoveInfo
                pHeroMoveInfo = pHeroInfo.detach()
                Write16(pHeroMoveInfo, 0) # len
                Write32(pHeroMoveInfo, Player.Uin) # Uin
                Write8(pHeroMoveInfo, 0) # WalkStatue
                Write32Int(pHeroMoveInfo, ChatRoom.x) # Posion[3]
                Write32Int(pHeroMoveInfo, ChatRoom.y)
                Write32Int(pHeroMoveInfo, ChatRoom.z)
                Write32(pHeroMoveInfo, 1000) # Ori[9]
                Write32(pHeroMoveInfo, 0)
                Write32(pHeroMoveInfo, 0)
                Write32(pHeroMoveInfo, 0)
                Write32(pHeroMoveInfo, 1000)
                Write32(pHeroMoveInfo, 0)
                Write32(pHeroMoveInfo, 0)
                Write32(pHeroMoveInfo, 0)
                Write32(pHeroMoveInfo, 1000)
                Write32(pHeroMoveInfo, 0) # AttachUin
                Write32(pHeroMoveInfo, 0) # WalkExtState
                UpdateLen16(pHeroInfo, pHeroMoveInfo)
            Write32(pHeroInfo, 0) # NextPoint
            Write16(pHeroInfo, 0) # PathLen
            # m_astHeroInfo[].m_aiPath[]
            WriteRoomVisibleInfo(pHeroInfo, Player) # HeroVisbleInfo
            Write16(pHeroInfo, 0) # HeroEnterDelayTime
            UpdateLen16(p, pHeroInfo)
    Write16(p, 0) # RelationHeroCount
    Write16(p, 0) # KartNum
    Write16(p, 0) # HammerCount
    Write16(p, 0) # StealPigCount
    Write8(p, 0) # HaveNext
    Write8(p, 0) # HaveAppellation
    SendToClient(Client, 11019, buf, p-buf, Client.ChatRoom.ID, FE.OUTDOORSVRD, Client.ConnID, MsgType.Notify)


def ResponseEnterOutdoor(Client:ClientNode, SceneID:int, Point3D:tuple[int,int,int]):
    buf = get_buf()
    p = buf.detach()
    Write16(p, Client.ChatRoom.ID) # ChatRoomID
    Write16(p, SceneID) # SceneID
    if True: # HeroMoveInfo
        pHeroMoveInfo = p.detach()
        Write16(pHeroMoveInfo, 0) # len
        Write32(pHeroMoveInfo, 0) # Uin
        Write8(pHeroMoveInfo, 0) # WalkStatue
        Write32Int(pHeroMoveInfo, Point3D[0]) # Posion[3]
        Write32Int(pHeroMoveInfo, Point3D[1])
        Write32Int(pHeroMoveInfo, Point3D[2])
        Write32(pHeroMoveInfo, 1000) # Ori[9]
        Write32(pHeroMoveInfo, 0)
        Write32(pHeroMoveInfo, 0)
        Write32(pHeroMoveInfo, 0)
        Write32(pHeroMoveInfo, 1000)
        Write32(pHeroMoveInfo, 0)
        Write32(pHeroMoveInfo, 0)
        Write32(pHeroMoveInfo, 0)
        Write32(pHeroMoveInfo, 1000)
        Write32(pHeroMoveInfo, 0) # AttachUin
        Write32(pHeroMoveInfo, 0) # WalkExtState
        UpdateLen16(p, pHeroMoveInfo)
    Write16(p, 0) # ResultID
    WriteStringWithLength(p, "聊天房名", bits_of_len=8) # RoomName
    Write16(p, 0) # HeroCount
    Write16(p, 0) # RelationHeroCount
    Write16(p, 0) # KartNum
    Write16(p, 0) # HammerCount
    Write16(p, 0) # StealPigCount
    Write16(p, 0) # MaxHeroNumInRoom
    SendToClient(Client, 352, buf, p-buf, Client.ChatRoom.ID, FE.OUTDOORSVRD, Client.ConnID, MsgType.Response)


def NotifyChairInfo(Client:ClientNode):
    buf = get_buf()
    p = buf.detach()
    for i in range(CONST.MAX_CHAIR_NUM):
        pChairInfo = p.detach()
        Write16(pChairInfo, 0) # len
        for j in range(CONST.MAX_NUM_IN_EACHCHAIR):
            Write32(pChairInfo, 0)
        UpdateLen16(p, pChairInfo)
    SendToClient(Client, 864, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)  


def RequestEnterOutdoor(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    Uin = Read32(Body)
    Time = Read32(Body)
    SceneID = Read16(Body)
    ChatRoomID = Read16(Body)
    NPCCfgVer = Read16(Body)
    LeaveOutdoor(Client)
    ChatRoom = GetChatRoom(ChatRoomID)
    if not ChatRoom: return
    if len(ChatRoom.Player) >= ChatRoom.MaxPlayerNum: return 
    Client.ChatRoom = ChatRoom
    ChatRoom.Player[Client.Uin] = Client
    ChatRoom.CurPlayerNum += 1
    SceneID = ChatRoom.SceneID
    NotifyNPCInfo(Client)
    ResponseEnterOutdoor(Client, SceneID, (ChatRoom.x, ChatRoom.y, ChatRoom.z))
    NotifyGuildRoomMoreInfo(Client)
    NotifyChairInfo(Client)
    for Player in ChatRoom.YieldClientExcept(Client):
        NotifyEnterOutdoor(Player, ChatRoom, Client)

class MoveInfo:
    def __init__(self):
        self.Uin = 0
        self.WalkStatus = 0
        self.Point3D:list[int,int,int] = [0 for _ in range(3)]
        self.Ori:list[int,int,int,int,int,int,int,int,int] = [0 for _ in range(9)]
        self.AttachUin = 0
        self.WalkExtState = 0

def NotifyHeroMove(Client:ClientNode, HeroMoveInfo: MoveInfo):
    buf = get_buf()
    p = buf.detach()
    pHeroMoveInfo = p.detach()
    Write16(pHeroMoveInfo, 0) # len
    Write32(pHeroMoveInfo, HeroMoveInfo.Uin) # Uin
    Write8(pHeroMoveInfo, HeroMoveInfo.WalkStatus) # WalkStatue
    for v in HeroMoveInfo.Point3D: Write32Int(pHeroMoveInfo, v) # Posion[3]
    for v in HeroMoveInfo.Ori: Write32Int(pHeroMoveInfo, v) # Ori[9]
    Write32(pHeroMoveInfo, HeroMoveInfo.AttachUin) # AttachUin
    Write32(pHeroMoveInfo, HeroMoveInfo.WalkExtState) # WalkExtState
    UpdateLen16(p, pHeroMoveInfo)
    Write32(p, 0) # NextPoint
    Write16(p, 0) # PathLen
    # Path[]
    Write32(p, 0) # Time
    SendToClient(Client, 851, buf, p-buf, Client.ConnID, FE.PLAYER, Client.ConnID, MsgType.Notify)

def RequestLeaveOutdoor(Client: ClientNode, Body: Z_BYTES, BodyLen: int):
    LeaveOutdoor(Client)

def RequestHeroMove(Client:ClientNode, Body:Z_BYTES, BodyLen:int):
    Uin = Read32(Body)
    Time = Read32(Body)
    HeroMoveInfo = MoveInfo()

    pHeroMoveInfo = Body.detach()
    length = Read16(pHeroMoveInfo)
    Body.start+=length
    HeroMoveInfo.Uin = Read32(pHeroMoveInfo)
    HeroMoveInfo.WalkStatus = Read8(pHeroMoveInfo)
    for i in range(3):
        HeroMoveInfo.Point3D[i] = Read32Int(pHeroMoveInfo)
    for i in range(9):
        HeroMoveInfo.Ori[i] = Read32Int(pHeroMoveInfo)
    HeroMoveInfo.AttachUin = Read32(pHeroMoveInfo)
    HeroMoveInfo.WalkExtState = Read32(pHeroMoveInfo)

    # 补齐这块可以修复休闲区中的人物移动
    # NextPoint = Read32(Body)
    # PathLen= Read16(Body)
    # # Path[]
    # CurCellID = Read32(Body)
    ChatRoom = Client.ChatRoom
    if not ChatRoom: return
    for Player in ChatRoom.YieldClientExcept(Client):
        NotifyHeroMove(Player, HeroMoveInfo)
