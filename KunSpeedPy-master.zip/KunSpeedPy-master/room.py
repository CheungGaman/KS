
from data_structure import *

# MOVED TO data_structure.py
# Rooms:dict[int, 'RoomNode'] = {}
# _RoomID_ = 0
# def GetRoomID()->int:
# class RoomNode:
      
def GetRoom(RoomID:int)->RoomNode:
    return Rooms.get(RoomID, None)

def GetAllRooms()->dict[int, RoomNode]:
    return Rooms

def YieldOtherClientsInRoom(Client:ClientNode)->list[ClientNode]:
    Room = Client.Room
    if not Room: return []
    for i in range(CONST.MAX_SEAT_IN_ROOM):
        if Room.Player[i] and Room.Player[i].ConnID != Client.ConnID:
            yield Room.Player[i]
            
        
        
def PlayerEnterRoom(Client:ClientNode, Room:RoomNode, SeatID:int):
    if Room.Player[SeatID]: 
        logger.error(f"[PlayerEnterRoom] SeatID={SeatID} is not empty")
        raise Exception
    if Client.Room:
        logger.error(f"[PlayerEnterRoom] Client.Room is not None")
        raise Exception
    Room.Player[SeatID] = Client
    Room.CurrentPlayerNum += 1
    if Room.CurrentPlayerNum == 1:
        Room.RoomOwnerID = Client.ConnID
    Client.Room = Room
    Client.SeatID = SeatID
    Client.ReadyState = 0
    Client.TeamID = 0
    Client.IsLoverProp = 0
    

def PlayerLeaveRoom(Client:ClientNode, Room:RoomNode):
    if Client.Room != Room or Room.Player[Client.SeatID]!=Client:
        logger.error(f"[PlayerLeaveRoom] Client.Room is not Room or Room.Player[Client.SeatID]!=Client")
        raise Exception
    Room.Player[Client.SeatID] = None
    Room.CurrentPlayerNum -= 1
    if Room.CurrentPlayerNum > 0 and Room.RoomOwnerID == Client.ConnID:
        for i in range(CONST.MAX_SEAT_IN_ROOM):
            if Room.Player[i]:
                Room.RoomOwnerID = Room.Player[i].ConnID
                break
    Client.Room = None
    Client.SeatID = 0

def DeleteRoom(Room:RoomNode):
    del Rooms[Room.ID]
        
