import sqlite3
import threading
from process_config import getItem, ItemType, isCar


class User:
    def __init__(self):
        self.conn = sqlite3.connect('db/User.db')
        self.cursor = self.conn.cursor()
    def GetUin(self, Username:str)->int:
        sql = "SELECT Uin  FROM User  WHERE Name=?;"
        self.cursor.execute(sql, (Username,))
        result = self.cursor.fetchone()
        if result:
            return 10000+result[0]
        return 0
    def GetAllUsernames(self)->list[str]:
        sql = "SELECT Name FROM User;"
        self.cursor.execute(sql)
        result = self.cursor.fetchall()
        return [t[0] for t in result]
    def DeleteAccount(self, Username:str)->bool:
        sql = "DELETE FROM User WHERE Name=?;"
        try:
            result = self.cursor.execute(sql, (Username,))
            self.conn.commit()
            return True
        except:
            return False
    def Register(self, Username:str, Password:str):
        sql = "INSERT INTO User (Name, Password) VALUES (?, ?);"
        try:
            result = self.cursor.execute(sql, (Username, Password))
            self.conn.commit()
            return True
        except:
            return False

class Player:
    def __init__(self):
        self.conn = sqlite3.connect('db/Player.db')
        self.conn.text_factory = bytes
        self.cursor = self.conn.cursor()
        # self.cursor.execute("PRAGMA encoding='GBK';")
        
    def Register_Player(self, Uin:int, VipFlag:int, IsInTopList:int):
        sql = "INSERT INTO Player (Uin, VipFlag, IsInTopList) VALUES (?, ?, ?);"
        try:
            result = self.cursor.execute(sql, (Uin, VipFlag, IsInTopList))
            self.conn.commit()
            return True
        except:
            return False
    def Register_BaseInfo(self, Uin:int, NickName:str, Gender:int, Country:int):
        sql = "INSERT INTO BaseInfo (Uin,NickName,Gender,Country,Experience) VALUES (?,?,?,?,?);"
        try:
            result = self.cursor.execute(sql, (Uin, NickName.encode('gbk'), Gender, Country, 2**30))
            self.conn.commit()
            return True
        except:
            return False
    def SetGender(self, Uin:int, Gender:int):
        sql = "UPDATE BaseInfo SET Gender=?  WHERE Uin=? ;"
        try:
            result = self.cursor.execute(sql, (Gender, Uin))
            self.conn.commit()
            return True
        except:
            return False

    
    def AddItem(self, Uin:int, ItemID:int, ItemNum:int, AvailPeriod:int, Status:bool):
        sql = "INSERT INTO Item (Uin, ItemID, ItemNum, AvailPeriod, Status) VALUES (?, ?, ?, ?, ?);"
        try:
            result = self.cursor.execute(sql, (Uin, ItemID, ItemNum, AvailPeriod, Status))
            self.conn.commit()
        except:
            return False
        if isCar(ItemID):
            pass
        return True
    
    def AddItems(self, Uin:int, Items:list[tuple[int,int,int,bool]]):
        sql = "INSERT INTO Item (Uin, ItemID, ItemNum, AvailPeriod, Status) VALUES (?, ?, ?, ?, ?);"
        try:
            for item in Items:
                result = self.cursor.execute(sql, (Uin, item[0], item[1], item[2], item[3]))
            self.conn.commit()
        except:
            return False
        return True
            
    def DeleteAccount(self, Uin:int):
        try:
            sql = "DELETE FROM Player WHERE Uin=?;"
            self.cursor.execute(sql, (Uin,))
            sql = "DELETE FROM BaseInfo WHERE Uin=?;"
            self.cursor.execute(sql, (Uin,))
            sql = "DELETE FROM EquippedSuit WHERE Uin=?;"
            self.cursor.execute(sql, (Uin,))
            sql = "DELETE FROM Item WHERE Uin=?;"
            self.cursor.execute(sql, (Uin,))
            sql = "DELETE FROM MapRecord WHERE Uin=?;"
            self.cursor.execute(sql, (Uin,))
            self.conn.commit()
        except:
            return False
        return True
        
        
    def GetNick(self, Uin:int)->str:
        sql = "SELECT NickName From BaseInfo Where Uin=?;"
        self.cursor.execute(sql, (Uin,))
        result = self.cursor.fetchone()
        if result:
            return result[0].decode('gbk')
        return f"未知昵称[Uin={Uin}]"
    
    def UpdateItemStatus(self, Uin:int, ItemID:int, Status:int):
        sql = "UPDATE Item SET Status=? WHERE Uin=? AND ItemID=?;"
        self.cursor.execute(sql, (Status, Uin, ItemID))
        self.conn.commit()
        
    def GetRecord(self, Uin:int, MapID:int):
        sql = "SELECT Record FROM MapRecord WHERE Uin=? AND MapID=?;"
        self.cursor.execute(sql, (Uin, MapID))
        result = self.cursor.fetchone()
        if result:
            return result[0]
        return -1
    
    def UpdateRecord(self, Uin:int, MapID:int, Record:int)->bool:
        prev_record = self.GetRecord(Uin, MapID)
        if prev_record >= 0:
            if prev_record < Record:
                return False # 没有刷新纪录
            else:
                sql = "UPDATE MapRecord SET Record=? WHERE Uin=? AND MapID=?;"
                self.cursor.execute(sql, (Record, Uin, MapID))
                self.conn.commit()
                return True # 刷新纪录
        else: # 没有原纪录
            sql = "INSERT INTO MapRecord (Uin, MapID, Record) VALUES (?, ?, ?);"
            self.cursor.execute(sql, (Uin, MapID, Record))
            self.conn.commit()
            return True # 刷新纪录
        
    def GetSuitFromKart(self, Uin:int, KartID:int):
        sql = "SELECT SuitID FROM EquippedSuit WHERE Uin=? AND KartID=?;"
        self.cursor.execute(sql, (Uin, KartID))
        result = self.cursor.fetchone()
        if result:
            return result[0]
        return -1
    
    def GetConvertedSuit(self, Uin:int, KartID:int):
        suit = self.GetSuitFromKart(Uin, KartID)
        if suit > 0: return suit
        return KartID
    
    def GetEquippedSuit(self, Uin:int):
        return self.GetConvertedSuit(Uin, self.GetEquippedCar(Uin))
    
    def UpdateEquippedSuit(self, Uin:int, KartID:int, SuitID:int):
        prev_suit = self.GetSuitFromKart(Uin, KartID)
        if prev_suit >= 0:
            sql = "UPDATE EquippedSuit SET SuitID=? WHERE Uin=? AND KartID=?;"
            self.cursor.execute(sql, (SuitID, Uin, KartID))
            self.conn.commit()
            return True
        else:
            sql = "INSERT INTO EquippedSuit (Uin, KartID, SuitID) VALUES (?, ?, ?);"
            self.cursor.execute(sql, (Uin, KartID, SuitID))
            self.conn.commit()
            return True
    
    def GetItems(self, Uin:int)->list[tuple[int,int,int,int,int,int]]:
        sql = "SELECT ItemID,ItemNum,AvailPeriod,Status,ObtainTime,OtherAttribute  FROM Item WHERE Uin = ?;"
        self.cursor.execute(sql, (Uin,))
        result = self.cursor.fetchall()
        return result
    
    def GetEquippedItems(self, Uin:int)->list[tuple[int,int,int,int,int,int]]:
        sql = "SELECT ItemID,ItemNum,AvailPeriod,Status,ObtainTime,OtherAttribute  FROM Item WHERE Uin = ? AND Status=1;"
        self.cursor.execute(sql, (Uin,))
        result = self.cursor.fetchall()
        return result
    
    def GetEquippedCar(self, Uin:int)->int:
        sql = "SELECT ItemID FROM Item WHERE Uin = ? AND Status=1;"
        ret = self.cursor.execute(sql, (Uin,)).fetchall()
        for t in ret:
            itemID = t[0]
            if getItem().GetItemType(itemID) == ItemType.EAIT_CAR:
                return itemID
        return 0
    
    def GetSuitConfig(self, Uin:int)->list[tuple[int,int]]:
        sql = "SELECT KartID,SuitID FROM EquippedSuit WHERE Uin = ?;"
        ret = self.cursor.execute(sql, (Uin,)).fetchall()
        return ret
    
    def GetCars(self, Uin:int)->list[int]:
        sql = "SELECT ItemID FROM Item WHERE Uin = ?;"
        ret = self.cursor.execute(sql, (Uin,)).fetchall()
        cars = []
        for item in ret:
            ItemID = item[0]
            if getItem().GetItemType(ItemID) == ItemType.EAIT_CAR:
                cars.append(ItemID)
        return cars
    
    def GetVIPInfo(self, Uin)->tuple[int,int]:
        sql = "SELECT VipFlag,IsInTopList  FROM Player  WHERE Uin=?;"
        result = self.cursor.execute(sql, (Uin,)).fetchone()
        return result
    
    def GetDBBaseInfo(self, Uin):
        sql = "SELECT NickName,Gender,Country,License,Experience,SuperMoney,Money,WinNum,SecondNum,ThirdNum,TotalNum,CurHonor,TotalHonor,TodayHonor,RelaxTime,MonthDurationBefor,MonthDurationCur,Charm,DurationGame,DanceExp,Coupons,Admiration,LuckMoney,TeamWorkExp,AchievePoint,RegTime,Signature  FROM BaseInfo  WHERE Uin=?;"
        result = self.cursor.execute(sql, (Uin,)).fetchone()
        if result:
            NickName,Gender,Country,License,Experience,SuperMoney,Money,WinNum,SecondNum,ThirdNum,TotalNum,CurHonor,TotalHonor,TodayHonor,RelaxTime,MonthDurationBefor,MonthDurationCur,Charm,DurationGame,DanceExp,Coupons,Admiration,LuckMoney,TeamWorkExp,AchievePoint,RegTime,Signature = result
            NickName = NickName.decode('gbk')
            Signature = Signature.decode('gbk')
            Gender = int(Gender)
            Country = int(Country)
        else:
            Gender=Country=License=Experience=SuperMoney=Money=WinNum=SecondNum=ThirdNum=TotalNum=CurHonor=TotalHonor=TodayHonor=RelaxTime=MonthDurationBefor=MonthDurationCur=Charm=DurationGame=DanceExp=Coupons=Admiration=LuckMoney=TeamWorkExp=AchievePoint=RegTime=0
            NickName=Signature=''
        return NickName,Gender,Country,License,Experience,SuperMoney,Money,WinNum,SecondNum,ThirdNum,TotalNum,CurHonor,TotalHonor,TodayHonor,RelaxTime,MonthDurationBefor,MonthDurationCur,Charm,DurationGame,DanceExp,Coupons,Admiration,LuckMoney,TeamWorkExp,AchievePoint,RegTime,Signature 
    
    def GetMapInfo(self, Uin)->list[tuple[int,int]]:
        sql = "SELECT MapID,Record  FROM MapRecord WHERE Uin = ?;"
        return self.cursor.execute(sql, (Uin,)).fetchall()
        
_Users_:dict[int, User] = {}
_Players_:dict[int, Player] = {}
        
def get_User()->User: # thread safe
    tid = threading.get_ident()
    if tid not in _Users_:
        _Users_[tid] = User()
    return _Users_[tid]
def get_Player()->Player: # thread safe
    tid = threading.get_ident()
    if tid not in _Players_:
        _Players_[tid] = Player()
    return _Players_[tid]
    

if __name__ == '__main__':
    ret = get_Player().GetNick(10009)
    print(f"Nick: {ret}")
    ret = get_Player().GetItems(10009)
    print(ret)
    ret = get_Player().GetCars(10009)
    print(ret)
    ret = get_Player().GetEquippedCar(10009)
    print(ret)
    ret = get_User().GetUin("jj")
    print(ret)
    ret = get_Player().Register_BaseInfo(10037, "zz", 0, 0)
    print(ret)
    # ret = get_User().Register("11","22")
    # print(ret)
    # print(len(ret))
    # ret = get_Player().GetVIPInfo(10009)
    # print(ret)
    # ret = get_Player().GetMapInfo(10009)
    # print(ret)
    # ret = get_Player().GetDBBaseInfo(10009)
    # print(ret)