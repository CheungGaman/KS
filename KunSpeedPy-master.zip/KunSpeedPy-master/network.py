from z_bytes import *
from data_structure import *
import socket

def SendToClient(client: ClientNode, MsgID:int, Data: Z_BYTES, Length:int, SrcID:int, SrcFE:int, DstID:int, MsgType: int, Encrypt:int=1):
    MsgLen = MSGHEAD.size + Length
    buf = Z_BYTES(bytes(MsgLen))
    MsgHead = MSGHEAD(buf)
    MsgHead.write_MsgID(MsgID)
    MsgHead.write_MsgType(MsgType)
    # MsgHead.write_MsgSeq(-1)
    MsgHead.write_MsgSeq(0xFFFFFFFF)
    MsgHead.write_SrcFE(SrcFE)
    MsgHead.write_DstFE(FE.CLIENT)
    MsgHead.write_SrcID(SrcID)
    MsgHead.write_DstID(DstID)
    MsgHead.write_BodyLen(2+Length) # + sizeof(USHORT)
    MsgBody = buf[MSGHEAD.size:]
    SetBytes(MsgBody.data, MsgBody.start, Data.data, Data.start, Length)
    if Encrypt:
        EncryptLen = encrypt_len(MsgLen)
        TotalLen = CSHEAD.size + EncryptLen
        ProtocalHead = Z_BYTES(bytes(TotalLen))
        ret = encrypt(buf.data, 0, MsgLen, getServerInfo()["Server"]["Key"], ProtocalHead.data, CSHEAD.size)
        assert ret == EncryptLen
        TotalLength = CSHEAD.size + EncryptLen
    else:
        raise NotImplementedError
    CSHead = CSHEAD(ProtocalHead)
    CSHead.write_TotalLength(TotalLength)
    CSHead.write_Ver(116)
    CSHead.write_DialogID(SrcID)
    CSHead.write_Seq(0xFFFFFFFF)
    CSHead.write_Uin(client.Uin)
    CSHead.write_BodyFlag(Encrypt)
    CSHead.write_OptLength(0)
    # logger.debug(f"ProtocalHead = {ProtocalHead}")
    client.Server.Send(client.Sender, client.ConnID, ProtocalHead.data)
    
def IP2INT(ip:str)->int:
    return int.from_bytes(socket.inet_aton(ip), byteorder="little", signed=False)
    import struct
    packed_ip_address = socket.inet_aton(ip)
    return struct.unpack("!L", packed_ip_address)[0]

if __name__ == '__main__':
    print(IP2INT("192.0.2.1"))