def OnEnterRoom(*args, **kwargs): return
def OnStartGame(*args, **kwargs): return
def OnCreateRoom(*args, **kwargs): return