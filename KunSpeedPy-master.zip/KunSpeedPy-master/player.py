from z_bytes import *
from data_structure import *
from database import *
from process_config import *

def WriteEquipedItem(p:Z_BYTES, Uin:int)->Z_BYTES:
    EquippedItems = get_Player().GetEquippedItems(Uin)
    Write16(p, len(EquippedItems))
    for EquippedItem in EquippedItems:
        ItemID, ItemNum, AvailPeriod, Status, ObtainTime, OtherAttribute = EquippedItem
        if isCar(ItemID):
            ItemID = get_Player().GetConvertedSuit(Uin, ItemID)
        # logger.debug(f"[WriteEquippedItem] Client: {get_Player().GetNick(Uin)}, ItemID: {ItemID} (IsCar:{isCar(ItemID)}), ItemNum: {ItemNum}, AvailPeriod: {AvailPeriod}, Status: {Status}, ObtainTime: {ObtainTime}, OtherAttribute: {OtherAttribute}")
        pItemInfo = p.detach()
        Write16(pItemInfo, 0) # len
        Write32(pItemInfo, ItemID)
        Write32(pItemInfo, ItemNum)
        Write32Int(pItemInfo, AvailPeriod)
        Write8(pItemInfo, Status)
        Write32(pItemInfo, ObtainTime)
        Write32(pItemInfo, ObtainTime)
        Write16(pItemInfo, 0) # ItemType
        UpdateLen16(p, pItemInfo)
    return p
        

def WritePlayerGuildInfo(p:Z_BYTES, Uin: int)->Z_BYTES:
    pPlayerGuildInfo = p.detach()
    Write16(pPlayerGuildInfo, 0) # len
    WriteStringWithFixedLength(pPlayerGuildInfo, "", CONST.MaxNickName, encoding='gbk') # GuildName
    Write16(pPlayerGuildInfo, 0) # Duty
    Write32(pPlayerGuildInfo, 0) # GuildID
    Write32(pPlayerGuildInfo, 0) # Right
    Write32(pPlayerGuildInfo, 0) # Medal
    Write32(pPlayerGuildInfo, 0) # Contribute
    WriteStringWithFixedLength(pPlayerGuildInfo, "", 9)
    UpdateLen16(p, pPlayerGuildInfo)
    return p
    
def WritePlayerDBBaseInfo(p:Z_BYTES, Uin:int)->Z_BYTES:
    pPlayerDBBaseInfo = p.detach()
    DBBaseInfo = get_Player().GetDBBaseInfo(Uin)
    if DBBaseInfo:
        NickName, Gender, Country, License, Experience, SuperMoney, Money, WinNum, SecondNum, ThirdNum, TotalNum, CurHonor, TotalHonor, TodayHonor, RelaxTime, MonthDurationBefor, MonthDurationCur, Charm, DurationGame, DanceExp, Coupons, Admiration, LuckMoney, TeamWorkExp, AchievePoint, RegTime, Signature = DBBaseInfo
    else:
        Gender=Country=License=Experience=SuperMoney=Money=WinNum=SecondNum=ThirdNum=TotalNum=CurHonor=TotalHonor=TodayHonor=RelaxTime=MonthDurationBefor=MonthDurationCur=Charm=DurationGame=DanceExp=Coupons=Admiration=LuckMoney=TeamWorkExp=AchievePoint=RegTime=0
        NickName=Signature=""
    Write16(pPlayerDBBaseInfo, 0) # len
    WriteStringWithFixedLength(pPlayerDBBaseInfo, NickName, CONST.MaxNickName, encoding='gbk')
    Write8(pPlayerDBBaseInfo, Gender|0x48)
    Write8(pPlayerDBBaseInfo, Country)
    Write32(pPlayerDBBaseInfo, License)
    Write32(pPlayerDBBaseInfo, Experience)
    Write32(pPlayerDBBaseInfo, SuperMoney)
    Write32(pPlayerDBBaseInfo, Money)
    Write32(pPlayerDBBaseInfo, WinNum)
    Write32(pPlayerDBBaseInfo, SecondNum)
    Write32(pPlayerDBBaseInfo, ThirdNum)
    Write32(pPlayerDBBaseInfo, TotalNum)
    Write32(pPlayerDBBaseInfo, CurHonor)
    Write32(pPlayerDBBaseInfo, TotalHonor)
    Write32(pPlayerDBBaseInfo, TodayHonor)
    Write32(pPlayerDBBaseInfo, RelaxTime)
    Write32(pPlayerDBBaseInfo, MonthDurationBefor)
    Write32(pPlayerDBBaseInfo, MonthDurationCur)
    Write32(pPlayerDBBaseInfo, Charm)
    Write32(pPlayerDBBaseInfo, DurationGame)
    Write32(pPlayerDBBaseInfo, DanceExp)
    Write32(pPlayerDBBaseInfo, Coupons)
    Write32(pPlayerDBBaseInfo, Admiration)
    Write32(pPlayerDBBaseInfo, LuckMoney)
    Write32(pPlayerDBBaseInfo, TeamWorkExp)
    Write32(pPlayerDBBaseInfo, AchievePoint)
    Write32(pPlayerDBBaseInfo, RegTime)

    WriteStringWithFixedLength(pPlayerDBBaseInfo, Signature, CONST.MaxSignature, encoding='gbk')
    
    Write32(pPlayerDBBaseInfo, 0) # LuckyMatchPoint
    Write32(pPlayerDBBaseInfo, 0) # LuckyMatchNum
    Write16(pPlayerDBBaseInfo, 0) # LuckyMatchFirstNum
    Write8(pPlayerDBBaseInfo, 0) # LuckyMatchBestRand
    Write32(pPlayerDBBaseInfo, 0) # LuckyMatchWinNum
    Write32(pPlayerDBBaseInfo, 0) # FizzPointTotal
    Write16(pPlayerDBBaseInfo, 0) # FizzPointDaily
    Write16(pPlayerDBBaseInfo, 0) # FizzPointWeekly
    Write16(pPlayerDBBaseInfo, 0) # FizzPointLastWeek
    Write8(pPlayerDBBaseInfo, 0) # FizzLotteryStatus
    Write32(pPlayerDBBaseInfo, 0) # FizzLastUpdateTime
    Write32(pPlayerDBBaseInfo, 0) # SNSLocaleCode
    Write32(pPlayerDBBaseInfo, 0) # AuctionRightUnlockTime
    Write8(pPlayerDBBaseInfo, 0) # ReserveFlag
    Write32(pPlayerDBBaseInfo, 0) # CurConsumeScore
    Write32(pPlayerDBBaseInfo, 0) # HistoryConsumeScore
    Write8(pPlayerDBBaseInfo, 0) # CrashModeSponsorID
    Write32(pPlayerDBBaseInfo, 0) # Popularity
    Write32(pPlayerDBBaseInfo, 0) # LadderMatchAchievePoint
    Write32(pPlayerDBBaseInfo, 0) # Cash
    Write32(pPlayerDBBaseInfo, 0) # PlayerGPMIdentity
    Write32(pPlayerDBBaseInfo, 0) # PointTotalScore
    Write32(pPlayerDBBaseInfo, 0) # totalMapMedalNum
    Write32(pPlayerDBBaseInfo, 0) # lastMapMedalNum
    Write32(pPlayerDBBaseInfo, 0) # curMapMedalNum
    Write32(pPlayerDBBaseInfo, 0) # curMapMedalSeasonId
    Write32(pPlayerDBBaseInfo, 0) # lastClearMapMedalTime
    Write32(pPlayerDBBaseInfo, 0) # max2048Score
    Write32(pPlayerDBBaseInfo, 0) # curPlay2048LeftNum
    Write32(pPlayerDBBaseInfo, 0) # CheerValue
    Write16(pPlayerDBBaseInfo, 0) # SeasonID
    Write32(pPlayerDBBaseInfo, 0) # LastCheerValue
    Write32(pPlayerDBBaseInfo, 0) # SpeedBean
    Write32(pPlayerDBBaseInfo, 0) # SpeedCoin

    Write16(p, pPlayerDBBaseInfo-p)
    p = pPlayerDBBaseInfo
    return p

def WriteRoomVisibleInfo(p:Z_BYTES, Client:ClientNode)->Z_BYTES:
    Identity = ID_IDENTIFY.QQLEVEL1 | ID_IDENTIFY.QQLEVEL2 | ID_IDENTIFY.QQLEVEL3 | ID_IDENTIFY.SPEEDMEMBER | ID_IDENTIFY.QQFLAG | ID_IDENTIFY.HAVEWORD | ID_IDENTIFY.FINISHQQFLAG 

    pPlayerRoomVisibleInfo = p.detach()
    Write16(pPlayerRoomVisibleInfo, 0) # len
    Write32(pPlayerRoomVisibleInfo, Client.Uin) # Uin
    Write32(pPlayerRoomVisibleInfo, Identity) # Identity
    Write8(pPlayerRoomVisibleInfo, Client.SeatID) # SeatID
    Write8(pPlayerRoomVisibleInfo, Client.TeamID) # TeamID
    Write16(pPlayerRoomVisibleInfo, Client.ConnID) 
    Write8(pPlayerRoomVisibleInfo, Client.ReadyState) # Status 

    pPlayerRoomVisibleInfo = WritePlayerDBBaseInfo(pPlayerRoomVisibleInfo, Client.Uin) 
    pPlayerRoomVisibleInfo = WritePlayerGuildInfo(pPlayerRoomVisibleInfo, Client.Uin) 
    pPlayerRoomVisibleInfo = WriteEquipedItem(pPlayerRoomVisibleInfo, Client.Uin) 

    Write16(pPlayerRoomVisibleInfo, 0) # PetNum

    if True: # PlayerGuildMatchInfo
        pPlayerGuildMatchInfo = pPlayerRoomVisibleInfo.detach()
        Write16(pPlayerGuildMatchInfo, 0) # len
        Write32(pPlayerGuildMatchInfo, 0) # SelfPoint
        Write32(pPlayerGuildMatchInfo, 0) # WinNum
        Write32(pPlayerGuildMatchInfo, 0) # TotalNum
        UpdateLen16(pPlayerRoomVisibleInfo, pPlayerGuildMatchInfo)


    Write8(pPlayerRoomVisibleInfo, 0) # IsInTopList
    Write8(pPlayerRoomVisibleInfo, Client.IsLoverProp) # LoverRaceOrPro
    Write8(pPlayerRoomVisibleInfo, 0) # TmpEffectNum
    Write8(pPlayerRoomVisibleInfo, 0) # OBState
    Write8(pPlayerRoomVisibleInfo, 0) # DebutOrX5
    Write8(pPlayerRoomVisibleInfo, 0) # RandKeyFlag
    Write16(pPlayerRoomVisibleInfo, CONST.VipFlag) # VipFlag
    Write8(pPlayerRoomVisibleInfo, 0) # HaveAppellation

    if True: # NobleInfo
        pNobleInfo = pPlayerRoomVisibleInfo.detach()
        Write16(pNobleInfo, 0) # len
        Write32(pNobleInfo, Client.Uin) # NobleID
        Write8(pNobleInfo, 6) # NobleLevel
        Write32(pNobleInfo, 1) # NoblePoint
        Write32(pNobleInfo, 30) # NobleLeftDays
        UpdateLen16(pPlayerRoomVisibleInfo, pNobleInfo)

    Write8(pPlayerRoomVisibleInfo, 0) # HasCarryWizard
    if True: # GuildVipBaseInfo
        pGuildVipBaseInfo = pPlayerRoomVisibleInfo.detach()
        Write16(pGuildVipBaseInfo, 0) # len
        Write8(pGuildVipBaseInfo, 0) # GuildVipLevel
        Write32(pGuildVipBaseInfo, 0) # GuildVipPoint
        UpdateLen16(pPlayerRoomVisibleInfo, pGuildVipBaseInfo)

    Write32(pPlayerRoomVisibleInfo, 0) # ExFlag
    Write8(pPlayerRoomVisibleInfo, 0) # HaveLDMBaseInfo
    Write8(pPlayerRoomVisibleInfo, 0) # HasWl
    Write8(pPlayerRoomVisibleInfo, 0) # HasLoverVip
    Write8(pPlayerRoomVisibleInfo, 0) # HasBattleModeSkillInfoList

    UpdateLen16(p, pPlayerRoomVisibleInfo)
    return p