# ForBeginner

## 环境

- python3.9+
- Vscode
- Git

## 过程

```bash
# 克隆KunSpeedPy至本地
git clone https://github.com/KunSpeed/KunSpeedPy.git
# 切换至encrypt_tea目录
cd KunSpeedPy\build_encrypt_tea\encrypt_tea
# 编译TEA
python setup.py build
# 安装TEA
python setup.py install
# 切换至KunSpeedPy目录
cd ../..
# 修改DB目录
mv example_db db
# 部署项目依赖
pip install -r requirements.txt
# 运行服务端
python main.py
```

如果你在这一编译步骤遇到困难，可以尝试我们编译好的whl包，目前仅提供python3.9+Win32 (64bit)版本，其他版本请自行编译。
```bash
# 克隆KunSpeedPy至本地
git clone https://github.com/KunSpeed/KunSpeedPy.git
# 进入KunSpeedPy目录
cd KunSpeedPy\
# 安装whl包
pip install build_encrypt_tea/encrypt_tea/compiled-whl/encrypt_tea-0.0.1-cp39-cp39-win_amd64.whl
# 修改DB目录
mv example_db db
# 部署项目依赖
pip install -r requirements.txt
# 运行服务端
python main.py
```

### 运行服务端

![启动服务器成功](./images/启动服务器成功.png)

### 运行启动器

**服务端还未校验用户密码，可在Message.py 第243行实现功能**

![登陆器登录](./images/登陆器登录.png)

## Tips

### 服务端与启动器密钥需匹配

- data_structure.py 第60行

![image-20230531233612064](./images/密钥位置.png)

### 账户密码校验函数

- Message.py 第243行

![image-20230531234006899](./images/image-20230531234006899.png)

### 修复10阶皮肤特效（未完成）

- Message.py 第1444行

![image-20230531234316757](./images/image-20230531234316757.png)

### 修复逻辑以用户准备状态为例

```
KunSpeedPy/refer/PacketStruct 20221108.cpp
```

![修复逻辑](./images/修复逻辑.png)