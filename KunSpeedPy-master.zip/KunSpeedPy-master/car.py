import os
from z_bytes import *
from collections import namedtuple
TypePhysInfo = namedtuple("TypePhysInfo", ["PID", "AffectID", "Param", "LifeTime"])
TypeCompensateParam = namedtuple("CompensateParam", ["Percent", "Value"])
TypeCollisionBoxParam = namedtuple("CollisionBoxParam", ["BoxLength", "BoxWidth", "BoxHeight", "AdjustOffset", "AdjustPickGap", "AdjustRemoteOffset", "AdjustBevelOffset", "ControllerOffset"])
TypeCarToCarCollisionParam = namedtuple("CarToCarCollisionParam", ["CollisionRadius", "CollisionLength", "CollisionWidth", "CollisionHeight", "CollisionLostCtrlTime"])
TypeAccel = namedtuple("Accel", ["Key", "Value"])
TypeStone = namedtuple("Stone", ["StoneUseOccaType", "SkillStoneID"])
from ruamel.yaml import YAML
yaml = YAML(typ='safe')
ENABLE_CACHE_KART=True

class KartConfig:
    def __init__(self, data:dict):
        self.KartID = data['KartID']
        self.PhysInfo:list[TypePhysInfo] = []
        for v in data["PhysInfo"]:
            self.PhysInfo.append(TypePhysInfo(v["PID"], v["AffectID"], v["Param"], v["LifeTime"]))
        self.CrashCompensateRate:float = data["CrashCompensateRate"]
        self.CompensateRate:float = data["CompensateRate"]
        self.CompensateParam:list[TypeCompensateParam] = []
        for v in data["CompensateParam"]:
            self.CompensateParam.append(TypeCompensateParam(v["Percent"], v["Value"]))
        v = data["CollisionBoxParam"]
        self.CollisionBoxParam = TypeCollisionBoxParam(v["BoxLength"], v["BoxWidth"], v["BoxHeight"], v["AdjustOffset"], v["AdjustPickGap"], v["AdjustRemoteOffset"], v["AdjustBevelOffset"], v["ControllerOffset"])
        v = data["CarToCarCollisionParam"]
        self.CarToCarCollisionParam = TypeCarToCarCollisionParam(v["CollisionRadius"], v["CollisionLength"], v["CollisionWidth"], v["CollisionHeight"], v["CollisionLostCtrlTime"])
        self.BaseTurnRate = data["BaseTurnRate"]
        self.VolatileTurnRate = data["VolatileTurnRate"]
        self.MaxTurnSpeed = data["MaxTurnSpeed"]
        self.MinTurnSpeed = data["MinTurnSpeed"]
        self.MaxAccuTime = data["MaxAccuTime"]
        self.BaseAccuRate = data["BaseAccuRate"]
        self.MaxAffectSpeed = data["MaxAffectSpeed"]
        self.Gravity = data["Gravity"]
        self.AdditionalLocalZSpeed = data["AdditionalLocalZSpeed"]
        self.StartVec = data["StartVec"]
        self.EndVecFist = data["EndVecFist"]
        self.EndVecSecon = data["EndVecSecon"]
        self.DirKeyForce = data["DirKeyForce"]
        self.DirKeyTwist = data["DirKeyTwist"]
        self.BannerTwist = data["BannerTwist"]
        self.BannerKeyTwist = data["BannerKeyTwist"]
        self.BannerVecForce = data["BannerVecForce"]
        self.BannerHeadForce = data["BannerHeadForce"]
        self.SlidFricForce = data["SlidFricForce"]
        self.RollFricForce = data["RollFricForce"]
        self.StartWec = data["StartWec"]
        self.MaxWec = data["MaxWec"]
        self.SuaiJianTwist = data["SuaiJianTwist"]
        self.DirUpKeyForce = data["DirUpKeyForce"]
        v = data["AccelStatus"]
        self.AccelStatus:list[int] = [value for value in v]
        self.ForwardAccel:list[TypeAccel] = []
        for v in data["ForwardAccel"]:
            self.ForwardAccel.append(TypeAccel(v["Key"], v["Value"]))
        self.ForwardDecel:list[TypeAccel] = []
        for v in data["ForwardDecel"]:
            self.ForwardDecel.append(TypeAccel(v["Key"], v["Value"]))
        self.BackwardAccel:list[TypeAccel] = []
        for v in data["BackwardAccel"]:
            self.BackwardAccel.append(TypeAccel(v["Key"], v["Value"]))
        self.BackwardDecel:list[TypeAccel] = []
        for v in data["BackwardDecel"]:
            self.BackwardDecel.append(TypeAccel(v["Key"], v["Value"]))
        self.DefenseRate = data["DefenseRate"]
        self.SpeedupCardGenRate = data["SpeedupCardGenRate"]
        self.ExtraFuncFlag = data["ExtraFuncFlag"]
        self.EnergyConvert = data["EnergyConvert"]
        self.SuperN2ORate = data["SuperN2ORate"]
        self.CollisionLoseRate = data["CollisionLoseRate"]
        self.NotInterruptDrift = data["NotInterruptDrift"]
        self.DirUpKeyForceParamA = data["DirUpKeyForceParamA"]
        self.DirUpKeyForceParamB = data["DirUpKeyForceParamB"]
        self.RefitCout = data["RefitCout"]
        self.MaxFlags = data["MaxFlags"]
        self.WWeight = data["WWeight"]
        self.SpeedWeight = data["SpeedWeight"]
        self.JetWeight = data["JetWeight"]
        self.SJetWeight = data["SJetWeight"]
        self.AccuWeight = data["AccuWeight"]
        self.ShapeRefitCount = data["ShapeRefitCount"]
        self.KartHeadRefitItemID = data["KartHeadRefitItemID"]
        self.KartTailRefitItemID = data["KartTailRefitItemID"]
        self.KartFlankRefitItemID = data["KartFlankRefitItemID"]
        self.KartTireRefitItemID = data["KartTireRefitItemID"]
        self.Stone:list[TypeStone] = []
        if "Stone" in data and data["Stone"] is not None:
            for v in data["Stone"]:
                self.Stone.append(TypeStone(v["StoneUseOccaType"], v["SkillStoneID"]))

def KartID2Path(KartID:int)->str:
    return f"Kart/{KartID}.yml"

_path2yml_:dict[int,dict] = {}

def KartID2Path(KartID:int)->str:
    return f"Kart/{KartID}.yml"

def LoadKartYml(KartID:int)->dict:
    if KartID in _path2yml_: return _path2yml_[KartID]
    if KartID == 0:
        with open(KartID2Path(KartID), 'r', encoding='utf-8') as f:
            _path2yml_[KartID] = yaml.load(f)
    else:
        baseYml = LoadKartYml(0).copy()
        filepath = KartID2Path(KartID)
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                incrementYml = yaml.load(f)
            baseYml.update(incrementYml)
        _path2yml_[KartID] = baseYml
    return _path2yml_[KartID]
        

class Karts:
    def __init__(self):
        self.default_kart = KartConfig(LoadKartYml(0))
        self.id2kart:dict[int,dict] = {}
        self.id2kart[0] = self.default_kart

    def GetKart(self, KartID:int)->KartConfig:
        if KartID in self.id2kart: return self.id2kart[KartID]
        filepath = KartID2Path(KartID)
        if not os.path.exists(filepath):
            return self.default_kart
        self.id2kart[KartID] = KartConfig(LoadKartYml(KartID))
        return self.id2kart[KartID]

_karts_ = Karts()
def get_Karts()->Karts:
    return _karts_

def car_clear_cache():
    _karts_.id2kart.clear()
    _path2yml_.clear()

def WriteKartStoneGrooveInfo(p:Z_BYTES, Uin:int, KartID:int)->Z_BYTES:
    # 宝石信息
    kart = get_Karts().GetKart(KartID)
    stones:list[TypeStone] = kart.Stone
    pKartStoneGrooveInfo = p.detach()
    Write16(pKartStoneGrooveInfo, 0) # len
    Write32(pKartStoneGrooveInfo, KartID)
    Write32(pKartStoneGrooveInfo, len(stones))
    for stone in stones:
        pStoneGrooveInfo = pKartStoneGrooveInfo.detach()
        Write16(pStoneGrooveInfo, 0) # len
        Write32(pStoneGrooveInfo, stone.StoneUseOccaType)
        Write32(pStoneGrooveInfo, stone.SkillStoneID)
        length = pStoneGrooveInfo - pKartStoneGrooveInfo
        Write16(pKartStoneGrooveInfo, length)
        pKartStoneGrooveInfo = pStoneGrooveInfo
    length = pKartStoneGrooveInfo - p
    Write16(p, length)
    p = pKartStoneGrooveInfo
    return p
    
def WriteKartPhysParam(p:Z_BYTES, Uin:int, KartID:int)->Z_BYTES:
    pKartPhysParam = p.detach()
    Write16(pKartPhysParam, 0) # len
    karts = get_Karts()
    kart = karts.GetKart(KartID)
    RefitCout = kart.RefitCout
    MaxFlags = kart.MaxFlags
    WWeight = kart.WWeight
    SpeedWeight = kart.SpeedWeight
    JetWeight = kart.JetWeight
    SJetWeight = kart.SJetWeight
    AccuWeight = kart.AccuWeight
    ShapeRefitCount = kart.ShapeRefitCount
    KartHeadRefitItemID = kart.KartHeadRefitItemID
    KartTailRefitItemID = kart.KartTailRefitItemID
    KartFlankRefitItemID = kart.KartFlankRefitItemID
    KartTireRefitItemID = kart.KartTireRefitItemID
    Write32(pKartPhysParam, KartID)
    PhysInfo:list[TypePhysInfo] = kart.PhysInfo
    Write8(pKartPhysParam, len(PhysInfo))
    for d in PhysInfo:
        pPhysInfo = pKartPhysParam.detach()
        Write16(pPhysInfo, 0) # len
        PID = d.PID
        AffectID = d.AffectID
        Param = d.Param
        LifeTime = d.LifeTime
        if PID == 1: # 燃料
            Param += 10*JetWeight
            LifeTime += 8*JetWeight
        elif PID == 2001: # 点火
            Param += 10*SJetWeight
            LifeTime += 8*SJetWeight
        elif PID == 99999: # 进气
            Param += 300 * AccuWeight
        elif PID == 777: # 玉麒麟超级氮气
            Param += 10*JetWeight
            LifeTime += 8*JetWeight
        else:
            pass
        Write32(pPhysInfo, PID)
        Write32(pPhysInfo, AffectID)
        Write32(pPhysInfo, Param)
        Write32(pPhysInfo, LifeTime)
        length = pPhysInfo - pKartPhysParam
        Write16(pKartPhysParam, length)
        pKartPhysParam = pPhysInfo
    # 落后补偿
    CompensateParam:list[CompensateParam] = kart.CompensateParam
    CompensateRate:float = kart.CompensateRate
    Write8(pKartPhysParam, len(CompensateParam))
    for d in CompensateParam:
        pCompensateParam = pKartPhysParam.detach()
        Write16(pCompensateParam, 0) # len
        Write32(pCompensateParam, d.Percent)
        value = d.Value
        value = int((value-1000)*CompensateRate/100+1000)
        Write32(pCompensateParam, value)
        Write16(pKartPhysParam, pCompensateParam-pKartPhysParam)
        pKartPhysParam = pCompensateParam
    
    
    if True: # CollisionBoxParam
        CollisionBoxParam:TypeCollisionBoxParam = kart.CollisionBoxParam
        pCollisionBoxParam = pKartPhysParam.detach()
        Write16(pCollisionBoxParam, 0) # len
        Write32(pCollisionBoxParam, CollisionBoxParam.BoxLength)
        Write32(pCollisionBoxParam, CollisionBoxParam.BoxWidth)
        Write32(pCollisionBoxParam, CollisionBoxParam.BoxHeight)
        Write32(pCollisionBoxParam, CollisionBoxParam.AdjustOffset)
        Write32(pCollisionBoxParam, CollisionBoxParam.AdjustPickGap)
        Write32(pCollisionBoxParam, CollisionBoxParam.AdjustRemoteOffset)
        Write32(pCollisionBoxParam, CollisionBoxParam.AdjustBevelOffset)
        Write32Int(pCollisionBoxParam, CollisionBoxParam.ControllerOffset)

        length = pCollisionBoxParam - pKartPhysParam
        Write16(pKartPhysParam, length)
        pKartPhysParam = pCollisionBoxParam

    if True: # CarToCarCollisionParam
        CarToCarCollisionParam:TypeCarToCarCollisionParam = kart.CarToCarCollisionParam
        pCarToCarCollisionParam = pKartPhysParam.detach()
        Write16(pCarToCarCollisionParam, 0) # len
        Write32(pCarToCarCollisionParam, CarToCarCollisionParam.CollisionRadius)
        Write32(pCarToCarCollisionParam, CarToCarCollisionParam.CollisionLength)
        Write32(pCarToCarCollisionParam, CarToCarCollisionParam.CollisionWidth)
        Write32(pCarToCarCollisionParam, CarToCarCollisionParam.CollisionHeight)
        Write32(pCarToCarCollisionParam, CarToCarCollisionParam.CollisionLostCtrlTime)
        length = pCarToCarCollisionParam - pKartPhysParam
        Write16(pKartPhysParam, length)
        pKartPhysParam = pCarToCarCollisionParam

    Write32(pKartPhysParam, kart.BaseTurnRate)
    Write32(pKartPhysParam, kart.VolatileTurnRate)
    Write32(pKartPhysParam, kart.MaxTurnSpeed)
    Write32(pKartPhysParam, kart.MinTurnSpeed)
    Write32(pKartPhysParam, kart.MaxAccuTime)
    Write32(pKartPhysParam, kart.BaseAccuRate)
    Write32(pKartPhysParam, kart.MaxAffectSpeed)
    Write32Int(pKartPhysParam, kart.Gravity + (10 * WWeight)) # TODO: 悬挂 未限制最大值!
    Write32Int(pKartPhysParam, kart.AdditionalLocalZSpeed)
    Write32(pKartPhysParam, kart.StartVec)
    Write32(pKartPhysParam, kart.EndVecFist)
    Write32(pKartPhysParam, kart.EndVecSecon)
    Write32(pKartPhysParam, kart.DirKeyForce)
    Write32(pKartPhysParam, kart.DirKeyTwist)
    Write32(pKartPhysParam, kart.BannerTwist)
    Write32(pKartPhysParam, kart.BannerKeyTwist)
    Write32(pKartPhysParam, kart.BannerVecForce)
    Write32(pKartPhysParam, kart.BannerHeadForce)
    Write32(pKartPhysParam, kart.SlidFricForce)
    Write32(pKartPhysParam, kart.RollFricForce)
    Write32(pKartPhysParam, kart.StartWec)
    Write32(pKartPhysParam, kart.MaxWec)
    Write32(pKartPhysParam, kart.SuaiJianTwist)
    Write32(pKartPhysParam, kart.DirUpKeyForce)

    AccelStatus:list[int] = kart.AccelStatus
    Write8(pKartPhysParam, len(AccelStatus)) # AccelStatusCount
    for v in AccelStatus:
        Write32(pKartPhysParam, v)

    ForwardAccel = kart.ForwardAccel
    Write8(pKartPhysParam, len(ForwardAccel)) # ForwardAccelNum
    for i,d in enumerate(ForwardAccel):
        pForwardAccel = pKartPhysParam.detach()
        Write16(pForwardAccel, 0) # len
        Key = d.Key
        Value = d.Value
        if 7<=i<=9:
            # TODO: 引擎 未限制最大值!
            Value += 35 * SpeedWeight
        Write32(pForwardAccel, Key)
        Write32(pForwardAccel, Value)
        length = pForwardAccel - pKartPhysParam
        Write16(pKartPhysParam, length)
        pKartPhysParam = pForwardAccel

    ForwardDecel = kart.ForwardDecel
    Write8(pKartPhysParam, len(ForwardDecel)) # ForwardDecelNum
    for d in ForwardDecel:
        pForwardDecel = pKartPhysParam.detach()
        Write16(pForwardDecel, 0) # len
        Write32(pForwardDecel, d.Key)
        Write32Int(pForwardDecel, d.Value)
        length = pForwardDecel - pKartPhysParam
        Write16(pKartPhysParam, length)
        pKartPhysParam = pForwardDecel

    BackwardAccel = kart.BackwardAccel
    Write8(pKartPhysParam, len(BackwardAccel)) # BackwardAccelNum
    for d in BackwardAccel:
        pBackwardAccel = pKartPhysParam.detach()
        Write16(pBackwardAccel, 0) # len
        Write32(pBackwardAccel, d.Key)
        Write32Int(pBackwardAccel, d.Value)
        length = pBackwardAccel - pKartPhysParam
        Write16(pKartPhysParam, length)
        pKartPhysParam = pBackwardAccel

    BackwardDecel = kart.BackwardDecel
    Write8(pKartPhysParam, len(BackwardDecel)) # BackwardDecelNum
    for d in BackwardDecel:
        pBackwardDecel = pKartPhysParam.detach()
        Write16(pBackwardDecel, 0) # len

        Write32(pBackwardDecel, d.Key)
        Write32Int(pBackwardDecel, d.Value)

        length = pBackwardDecel - pKartPhysParam
        Write16(pKartPhysParam, length)
        pKartPhysParam = pBackwardDecel

    Write32(pKartPhysParam, int(kart.CrashCompensateRate*10)) # CrashCompensatePower 氮气保护
    Write32(pKartPhysParam, kart.DefenseRate) # DefenseRate
    Write32(pKartPhysParam, Uin) # Uin
    Write32(pKartPhysParam, kart.SpeedupCardGenRate) # SpeedupCardGenRate
    Write32(pKartPhysParam, kart.ExtraFuncFlag) # ExtraFuncFlag

    #轮滑属性 start
    Write8(pKartPhysParam, 1) # HasSkatePara
    phasSkatePara = pKartPhysParam.detach();
    Write16(phasSkatePara, 0);
    Write32(phasSkatePara, 250000); # TrackSpeed // 轨道墙壁速度
    Write32(phasSkatePara, 0); # SkateSpeedCoef_AirBigJet
    Write32(phasSkatePara, 0); # SkateSpeedCoef_Jump
    Write32(phasSkatePara, 0); # SkateSpeedCoef_AirJetPoint
    Write32(phasSkatePara, 0); # SkateSpeedCoef_MaxForce
    Write32(phasSkatePara, 350000); # OntrackAccRef // 轨道集气
    Write32(phasSkatePara, 350000); # TrackAccRef // 墙壁
    Write32(phasSkatePara, 100000); # DashSkill
    # 轮滑属性 end
    Write8(pKartPhysParam, 0) # HasBattleModeSkillInfoList

    Write32(pKartPhysParam, kart.EnergyConvert) # EnergyConvert
    Write16(pKartPhysParam, kart.SuperN2ORate) # SuperN2ORate
    Write16(pKartPhysParam, kart.CollisionLoseRate) # CollisionLoseRate
    Write8(pKartPhysParam, kart.NotInterruptDrift) # NotInterruptDrift
    Write8(pKartPhysParam, 0) # AddWeightNum
    Write8(pKartPhysParam, 0) # WeightNum
    Write8(pKartPhysParam, 0) # HasAntiCollisionCfg
    Write8(pKartPhysParam, 0) # HasBoatParam
    Write8(pKartPhysParam, 0) # BoatForwardAccelNum
    Write32(pKartPhysParam, kart.DirUpKeyForceParamA) # DirUpKeyForceParamA
    Write32(pKartPhysParam, kart.DirUpKeyForceParamB) # DirUpKeyForceParamB
    UpdateLen16(p, pKartPhysParam)
    return p

def WriteKartRefitInfo(p:Z_BYTES, Uin:int, KartID:int)->Z_BYTES:
    cfg = get_Karts().GetKart(KartID)
    pKartRefitInfo = p.detach()
    Write16(pKartRefitInfo, 0) # length
    Write32(pKartRefitInfo, Uin)
    Write32(pKartRefitInfo, KartID) 
    Write32(pKartRefitInfo, cfg.RefitCout) # 改装次数
    Write16(pKartRefitInfo, cfg.MaxFlags)  # MaxFlags
    Write16(pKartRefitInfo, cfg.WWeight)  # WWeight
    Write16(pKartRefitInfo, cfg.SpeedWeight)  # SpeedWeight
    Write16(pKartRefitInfo, cfg.JetWeight)  # JetWeight
    Write16(pKartRefitInfo, cfg.SJetWeight)  # SJetWeight
    Write16(pKartRefitInfo, cfg.AccuWeight)  # AccuWeight
    Write32(pKartRefitInfo, cfg.ShapeRefitCount)  # ShapeRefitCount
    Write32(pKartRefitInfo, cfg.KartHeadRefitItemID)  # KartHeadRefitItemID
    Write32(pKartRefitInfo, cfg.KartTailRefitItemID)  # KartTailRefitItemID
    Write32(pKartRefitInfo, cfg.KartFlankRefitItemID)  # KartFlankRefitItemID
    Write32(pKartRefitInfo, cfg.KartTireRefitItemID)  # KartTireRefitItemID
    if True: # KartRefitExInfo
        pKartRefitExInfo = pKartRefitInfo.detach()
        Write16(pKartRefitExInfo, 0) # len
        Write8(pKartRefitExInfo, 0) # SpeedRefitStar
        Write8(pKartRefitExInfo, 0) # JetRefitStar
        Write8(pKartRefitExInfo, 0) # SJetRefitStar
        Write8(pKartRefitExInfo, 0) # AccuRefitStar
        Write8(pKartRefitExInfo, 0) # SpeedAddRatio
        Write8(pKartRefitExInfo, 0) # JetAddRatio
        Write8(pKartRefitExInfo, 0) # SJetAddRatio
        Write8(pKartRefitExInfo, 0) # AccuAddRatio
        Write16(pKartRefitInfo, pKartRefitExInfo-pKartRefitInfo)
        pKartRefitInfo = pKartRefitExInfo
    Write32(pKartRefitInfo, 0) # SecondRefitCount
    Write16(pKartRefitInfo, 0) # Speed2Weight
    Write16(pKartRefitInfo, 0) # DriftVecWeight
    Write16(pKartRefitInfo, 0) # AdditionalZSpeedWeight
    Write16(pKartRefitInfo, 0) # AntiCollisionWeight
    Write16(pKartRefitInfo, 0) # LuckyValue
    Write16(pKartRefitInfo, 0) # RefitLuckyValueMaxWeight
    Write32(pKartRefitInfo, 0) # ShapeSuitID
    Write8(pKartRefitInfo, 0) # LegendSuitLevel
    Write32(pKartRefitInfo, 0) # LegendSuitLevelChoice
    Write32(pKartRefitInfo, 0) # ShapeLegendSuitID
    Write16(p, pKartRefitInfo - p)
    p = pKartRefitInfo
    return p

if __name__ == '__main__':
    pass
        