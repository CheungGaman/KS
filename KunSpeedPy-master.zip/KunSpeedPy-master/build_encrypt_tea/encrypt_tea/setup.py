import os, sys
from distutils.core import setup, Extension
from distutils import sysconfig

os.environ['CL'] = '/DWIN32 /DWIN64 /D_WIN32 /arch:IA32'

ext_modules = [
    Extension(
        'encrypt_tea',
        ['tea.cpp'],
        include_dir=["pybind11/include"],
        language="c++",
        extra_compile_args=['/arch:IA32'],
        extra_link_args=['/arch:IA32'],
    )
]

setup(
    name="encrypt_tea",
    version="0.0.1",
    # packages=["api"],
    ext_modules=ext_modules,
    python_requires=">=3.8"
)